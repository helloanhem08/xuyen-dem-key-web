<?php
declare(strict_types=1);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

$privateDir = dirname(__DIR__) . '/private';
if (!is_dir($privateDir)) {
    $privateDir = __DIR__ . '/private';
}
$configPath = $privateDir . '/config.php';
if (!is_file($configPath)) {
    http_response_code(503);
    exit('Not installed');
}
$cfg = require $configPath;

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

try {
    $pdo = new PDO(
        sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $cfg['db']['host'], (int)$cfg['db']['port'], $cfg['db']['name']),
        $cfg['db']['user'],
        $cfg['db']['pass'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );
} catch (Throwable $e) {
    exit('DB error');
}

// Auth: session uid must be admin
$uid = $_SESSION['uid'] ?? null;
$token = null;
if (preg_match('/^Bearer\s+(.+)$/i', $_SERVER['HTTP_AUTHORIZATION'] ?? '', $m)) {
    $token = hash('sha256', trim($m[1]));
}
$ok = false;
if ($uid) {
    $s = $pdo->prepare("SELECT r.name rn FROM `User` u JOIN `Role` r ON r.id=u.roleId WHERE u.id=? AND u.status='ACTIVE'");
    $s->execute([$uid]);
    $rn = $s->fetchColumn();
    $ok = in_array($rn, ['SUPER_ADMIN', 'ADMIN', 'STAFF'], true);
}
if (!$ok && $token) {
    $s = $pdo->prepare(
        "SELECT r.name rn FROM AccessToken t JOIN `User` u ON u.id=t.userId JOIN `Role` r ON r.id=u.roleId
         WHERE t.tokenHash=? AND t.revokedAt IS NULL AND t.expiresAt > NOW() AND u.status='ACTIVE'"
    );
    $s->execute([$token]);
    $rn = $s->fetchColumn();
    $ok = in_array($rn, ['SUPER_ADMIN', 'ADMIN', 'STAFF'], true);
}
if (!$ok) {
    // allow query ?token= from localStorage bridge
    $qtoken = $_GET['token'] ?? '';
    if ($qtoken !== '') {
        $s = $pdo->prepare(
            "SELECT r.name rn FROM AccessToken t JOIN `User` u ON u.id=t.userId JOIN `Role` r ON r.id=u.roleId
             WHERE t.tokenHash=? AND t.revokedAt IS NULL AND t.expiresAt > NOW() AND u.status='ACTIVE'"
        );
        $s->execute([hash('sha256', $qtoken)]);
        $rn = $s->fetchColumn();
        $ok = in_array($rn, ['SUPER_ADMIN', 'ADMIN', 'STAFF'], true);
    }
}
if (!$ok) {
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><meta charset="utf-8"><title>Client logs</title>';
    echo '<p style="font:16px system-ui;padding:2rem">Cần đăng nhập admin. Mở <a href="/login">/login</a> trước, rồi quay lại trang này.</p>';
    echo '<script>var t=localStorage.getItem("accessToken");if(t)location.replace("/client-logs.php?token="+encodeURIComponent(t));</script>';
    exit;
}

$pdo->exec(
    "CREATE TABLE IF NOT EXISTS `ClientRequestLog` (
      `id` VARCHAR(191) NOT NULL,
      `endpoint` VARCHAR(64) NOT NULL,
      `bundleId` VARCHAR(191) NULL,
      `udid` VARCHAR(191) NULL,
      `deviceCode` VARCHAR(191) NULL,
      `licenseKey` VARCHAR(191) NULL,
      `statusCode` INT NOT NULL,
      `resultCode` INT NULL,
      `latencyMs` INT NOT NULL,
      `ipAddress` VARCHAR(64) NOT NULL,
      `userAgent` VARCHAR(255) NULL,
      `requestJson` TEXT NULL,
      `responseSummary` VARCHAR(255) NULL,
      `errorMessage` TEXT NULL,
      `createdAt` DATETIME(3) NOT NULL,
      PRIMARY KEY (`id`),
      KEY `idx_crl_created` (`createdAt`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
);

$ep = trim((string)($_GET['endpoint'] ?? ''));
$args = [];
$where = '';
if ($ep !== '') {
    $where = 'WHERE endpoint = ?';
    $args[] = $ep;
}
$s = $pdo->prepare("SELECT * FROM `ClientRequestLog` $where ORDER BY createdAt DESC LIMIT 100");
$s->execute($args);
$rows = $s->fetchAll();
$total = (int)$pdo->query("SELECT COUNT(*) FROM `ClientRequestLog`")->fetchColumn();

header('Content-Type: text/html; charset=utf-8');
?>
<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Game API Logs — DTA</title>
<style>
  :root { color-scheme: dark; }
  body { margin:0; font:14px/1.45 system-ui,sans-serif; background:#0b1020; color:#e8eefc; }
  header { padding:16px 20px; border-bottom:1px solid #1e293b; display:flex; flex-wrap:wrap; gap:12px; align-items:center; justify-content:space-between; }
  h1 { margin:0; font-size:1.15rem; }
  a { color:#7dd3fc; }
  .filters a { margin-right:10px; text-decoration:none; padding:6px 10px; border-radius:8px; background:#1e293b; }
  .filters a.on { background:#4f46e5; color:#fff; }
  table { width:100%; border-collapse:collapse; }
  th, td { padding:10px 12px; border-bottom:1px solid #1e293b; text-align:left; vertical-align:top; }
  th { font-size:12px; color:#94a3b8; position:sticky; top:0; background:#0b1020; }
  tr:hover td { background:#111827; }
  .ok { color:#34d399; }
  .err { color:#f87171; }
  .mono { font-family:ui-monospace,monospace; font-size:12px; word-break:break-all; }
  .badge { display:inline-block; padding:2px 8px; border-radius:999px; font-size:11px; background:#1e293b; }
  details { margin-top:4px; }
  summary { cursor:pointer; color:#94a3b8; font-size:12px; }
  pre { margin:6px 0 0; padding:8px; background:#020617; border-radius:8px; overflow:auto; max-height:200px; font-size:11px; }
  .meta { color:#64748b; font-size:12px; }
</style>
</head>
<body>
<header>
  <div>
    <h1>Game / App API requests</h1>
    <p class="meta"><?= (int)$total ?> requests · package-v3 · credential-v3 · key-v3</p>
  </div>
  <div class="filters">
    <a href="?" class="<?= $ep===''?'on':'' ?>">All</a>
    <a href="?endpoint=package-v3" class="<?= $ep==='package-v3'?'on':'' ?>">package-v3</a>
    <a href="?endpoint=credential-v3" class="<?= $ep==='credential-v3'?'on':'' ?>">credential-v3</a>
    <a href="?endpoint=key-v3" class="<?= $ep==='key-v3'?'on':'' ?>">key-v3</a>
    <a href="/">← Console</a>
  </div>
</header>
<div style="overflow:auto">
<table>
  <thead>
    <tr>
      <th>Time</th>
      <th>Endpoint</th>
      <th>HTTP</th>
      <th>Code</th>
      <th>Bundle / UDID / Key</th>
      <th>Summary</th>
      <th>IP · ms</th>
    </tr>
  </thead>
  <tbody>
  <?php if (!$rows): ?>
    <tr><td colspan="7" class="meta">Chưa có request từ game. Mở app và thử lại.</td></tr>
  <?php endif; ?>
  <?php foreach ($rows as $r):
    $req = $r['requestJson'] ? json_decode($r['requestJson'], true) : null;
    $httpOk = (int)$r['statusCode'] < 400;
  ?>
    <tr>
      <td class="mono"><?= htmlspecialchars($r['createdAt']) ?></td>
      <td><span class="badge"><?= htmlspecialchars($r['endpoint']) ?></span></td>
      <td class="<?= $httpOk ? 'ok' : 'err' ?>"><?= (int)$r['statusCode'] ?></td>
      <td class="mono"><?= $r['resultCode'] !== null ? (int)$r['resultCode'] : '—' ?></td>
      <td class="mono">
        <?= htmlspecialchars((string)($r['bundleId'] ?: '—')) ?><br>
        <span class="meta">udid:</span> <?= htmlspecialchars((string)($r['udid'] ?: '—')) ?><br>
        <span class="meta">key:</span> <?= htmlspecialchars((string)($r['licenseKey'] ?: '—')) ?>
        <?php if ($r['deviceCode']): ?><br><span class="meta">device:</span> <?= htmlspecialchars($r['deviceCode']) ?><?php endif; ?>
      </td>
      <td>
        <?= htmlspecialchars((string)($r['responseSummary'] ?: $r['errorMessage'] ?: '—')) ?>
        <?php if (is_array($req)): ?>
          <details><summary>Request body</summary><pre><?= htmlspecialchars(json_encode($req, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) ?></pre></details>
        <?php endif; ?>
        <?php if ($r['errorMessage'] && $r['responseSummary'] !== $r['errorMessage']): ?>
          <details><summary>Error</summary><pre><?= htmlspecialchars($r['errorMessage']) ?></pre></details>
        <?php endif; ?>
      </td>
      <td class="mono"><?= htmlspecialchars($r['ipAddress']) ?><br><?= (int)$r['latencyMs'] ?> ms</td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<script>setTimeout(function(){ location.reload(); }, 15000);</script>
</body>
</html>
