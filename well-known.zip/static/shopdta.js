(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const app = document.getElementById("app");
  const TOKEN_KEY = "shopdta.accessToken";
  const state = {
    token: localStorage.getItem(TOKEN_KEY) || "",
    me: null,
    menu: false,
    page: location.pathname || "/",
    err: "",
    shop: [],
    bundle: "all",
    order: null,
    keys: [],
    packages: [],
    licenses: [],
    devices: [],
    enrollments: [],
    requireEnrolled: false,
    orders: [],
    logs: [],
    bans: [],
    people: [],
    openLog: null,
    sepay: { bankCode: "VCB", accountNumber: "", accountName: "", webhookToken: "" },
    dash: null,
    tab: "Package",
    form: {},
  };

  const vnd = (n) =>
    new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND", maximumFractionDigits: 0 }).format(Number(n) || 0);

  function qrUrl(o) {
    const bank = encodeURIComponent(o.bankCode || state.sepay.bankCode || "VCB");
    const acc = encodeURIComponent(o.accountNumber || state.sepay.accountNumber || "");
    const amt = Number(o.amountVnd || o.totalCents || 0) || 0;
    const info = encodeURIComponent(o.content || o.reference || "");
    const name = encodeURIComponent(o.accountName || state.sepay.accountName || "");
    return `https://img.vietqr.io/image/${bank}-${acc}-compact2.png?amount=${amt}&addInfo=${info}&accountName=${name}`;
  }

  function remainLabel(expiresAt) {
    const end = new Date(expiresAt).getTime();
    if (!end) return "—";
    const ms = end - Date.now();
    if (ms <= 0) return "Hết hạn";
    const d = Math.floor(ms / 86400000);
    const h = Math.floor((ms % 86400000) / 3600000);
    const m = Math.floor((ms % 3600000) / 60000);
    const s = Math.floor((ms % 60000) / 1000);
    return d > 0
      ? `${d}n ${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`
      : `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  }

  function apiWarn(code, msg) {
    const map = {
      200: ["ok", "Package OK", "Bundle khớp gói."],
      6200: ["ok", "Đã login", "UDID đang gắn key còn hạn."],
      4200: ["ok", "Kích hoạt OK", "Key hợp lệ, đã gắn UDID."],
      4000: ["err", "Key sai / bundle lệch", "Key không tồn tại hoặc bundle_id không khớp."],
      4001: ["err", "Key hết hạn", "Gia hạn hoặc cấp key mới."],
      4002: ["warn", "Đủ thiết bị", "Gỡ máy cũ hoặc tăng maxDevices."],
      6403: ["err", "Đã ban", "UDID/IP trong BanTarget."],
      6405: ["warn", "Chưa lấy UDID", "Cài mobileconfig rồi quay lại app."],
      401: ["err", "Không có quyền", "Token/webhook sai."],
      403: ["err", "Cấm", "Member gọi API admin."],
      429: ["warn", "Hết lượt đổi máy", "1 lần/tuần."],
    };
    const h = map[code] || ["err", "Mã " + code, msg || "Xem JSON."];
    return `<div class="panel" style="margin-top:12px"><strong>${h[0] === "ok" ? "OK" : h[0] === "warn" ? "Cảnh báo" : "Lỗi"} · ${code} · ${esc(h[1])}</strong><p class="muted">${esc(h[2])}${msg ? " · " + esc(String(msg)) : ""}</p></div>`;
  }

  function go(path) {
    if (path !== location.pathname) history.pushState({}, "", path);
    state.page = path;
    state.menu = false;
    render();
    loadPage();
  }

  async function api(path, opts = {}) {
    const headers = { Accept: "application/json", ...(opts.body ? { "Content-Type": "application/json" } : {}), ...opts.headers };
    if (state.token) headers.Authorization = "Bearer " + state.token;
    const res = await fetch("/api" + path, { ...opts, headers, credentials: "include", body: opts.body ? JSON.stringify(opts.body) : undefined });
    const data = await res.json().catch(() => null);
    if (!res.ok) {
      const err = new Error((data && (data.error || data.message)) || res.statusText);
      err.status = res.status;
      throw err;
    }
    return data;
  }

  function icon(name) {
    const p = {
      menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
      x: '<path d="M6 6l12 12M18 6L6 18"/>',
      grid: '<rect x="4" y="4" width="6" height="6"/><rect x="14" y="4" width="6" height="6"/><rect x="4" y="14" width="6" height="6"/><rect x="14" y="14" width="6" height="6"/>',
      bag: '<path d="M6 8h12l-1 12H7L6 8z"/><path d="M9 8V7a3 3 0 016 0v1"/>',
      key: '<circle cx="8" cy="15" r="3"/><path d="M11 15h9v3M17 15v3"/>',
      clock: '<circle cx="12" cy="12" r="8"/><path d="M12 8v5l3 2"/>',
      gauge: '<path d="M4 16a8 8 0 1116 0"/><path d="M12 16l4-5"/>',
      out: '<path d="M10 6H6v12h4M14 16l4-4-4-4M10 12h8"/>',
    };
    return `<svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round">${p[name] || ""}</svg>`;
  }

  function navItems() {
    const items = [
      { to: "/", label: "Dashboard", icon: "grid" },
      { to: "/shop", label: "Mua key", icon: "bag" },
      { to: "/keys", label: "Key & máy", icon: "key" },
      { to: "/history", label: "Lịch sử", icon: "clock" },
    ];
    if (state.me && (state.me.roleName === "SUPER_ADMIN" || state.me.roleName === "RESELLER")) {
      items.push({ to: "/partner", label: "Đại lý", icon: "clock" });
    }
    if (state.me && state.me.roleName === "SUPER_ADMIN") items.push({ to: "/console", label: "Điều hành", icon: "gauge" });
    return items;
  }

  function shell(inner) {
    const items = navItems()
      .map(
        (n) =>
          `<a href="${n.to}" class="${state.page === n.to ? "on" : ""}" data-go="${n.to}">${icon(n.icon)}<span>${n.label}</span></a>`,
      )
      .join("");
    return `
      <header class="top">
        <button class="icon-btn" data-act="menu" aria-label="Mở menu">${icon("menu")}</button>
        <div class="who"><b>ShopDTA</b><span>${esc(state.me?.email || "")}</span></div>
        <span class="pill">${state.me?.roleName === "SUPER_ADMIN" ? "Admin" : "User"}</span>
      </header>
      ${
        state.menu
          ? `<div class="drawer-bg" data-act="close">
              <aside class="drawer ${state.menuEnter ? "enter" : ""}">
                <header>Menu <button type="button" class="icon-btn" data-act="close">${icon("x")}</button></header>
                <nav class="nav">
                  ${items}
                </nav>
                <div class="drawer-foot">
                  <button type="button" class="logout-btn" data-act="logout">${icon("out")}<span>Đăng xuất</span></button>
                </div>
              </aside>
            </div>`
          : ""
      }
      <main class="wrap">${inner}</main>`;
  }

  function loginView() {
    const up = state.form.mode === "up";
    return `
      <div class="login">
        <section class="login-hero">
          <p class="mark">ShopDTA</p>
          <div>
            <h1>Atelier <em>cho từng bundle.</em></h1>
            <p>User mua key theo package. Admin quản lý key, máy và thanh toán.</p>
          </div>
          <p class="kicker">cPanel · RSA mới · SePay webhook</p>
        </section>
        <section class="login-form">
          <form class="card-form" data-form="login">
            <p class="mark">ShopDTA</p>
            <h2>${up ? "Tạo tài khoản" : "Đăng nhập"}</h2>
            <p class="muted">Giữ phiên trên thiết bị này.</p>
            ${up ? field("name", "Tên", state.form.name || "") : ""}
            ${field("email", "Email", state.form.email || "", "email")}
            ${field("password", "Mật khẩu", state.form.password || "", "password")}
            ${up ? field("confirmPassword", "Nhập lại mật khẩu", state.form.confirmPassword || "", "password") : ""}
            ${state.err ? `<p class="err">${esc(state.err)}</p>` : ""}
            <div style="height:16px"></div>
            <button class="btn" type="submit">${up ? "Đăng ký" : "Vào dashboard"}</button>
            <button class="linkish" type="button" data-act="toggle-auth">${up ? "Đã có tài khoản? Đăng nhập" : "Chưa có tài khoản? Đăng ký"}</button>
          </form>
        </section>
      </div>`;
  }

  function field(name, label, value, type = "text") {
    if (type === "password") {
      return `<label class="field"><span>${label}</span>
        <span class="pass-wrap">
          <input name="${name}" type="password" value="${esc(value)}" autocomplete="current-password" />
          <button type="button" class="pass-eye" data-act="toggle-pass" aria-label="Hiện mật khẩu">Hiện</button>
        </span>
      </label>`;
    }
    return `<label class="field"><span>${label}</span><input name="${name}" type="${type}" value="${esc(value)}" autocomplete="${name}" /></label>`;
  }

  function homeView() {
    const d = state.dash?.stats || {};
    const isAdmin = state.me?.roleName === "SUPER_ADMIN";
    const stats = isAdmin
      ? [
          ["Doanh thu", vnd(d.totalRevenueCents || 0)],
          ["User", String(d.totalUsers ?? 0)],
          ["Key active", String(d.activeLicenses ?? 0)],
          ["API", String(d.totalApiRequests ?? 0)],
        ]
      : [
          ["Key của tôi", String(state.keys.length)],
          ["Đơn của tôi", String((state.orders || []).length)],
          ["Package", String(state.shop.length)],
          ["App", String(new Set(state.shop.map((p) => p.bundleId)).size)],
        ];
    return `
      <p class="kicker">Dashboard</p>
      <h1 class="page">${isAdmin ? "Bàn điều hành" : "Xin chào"}, ${esc((state.me?.name || "bạn").split(" ")[0])}</h1>
      <p class="lead">${isAdmin ? "Doanh thu SePay, key active và nhịp API." : "Mua key theo package. Lịch sử chỉ của tài khoản này."}</p>
      <div class="stats">${stats.map(([k, v]) => `<div class="stat"><span class="kicker">${k}</span><b>${v}</b></div>`).join("")}</div>
      <div class="grid2" style="margin-top:16px">
        <a class="panel" href="/shop" data-go="/shop"><h3 class="page" style="font-size:28px">Mua key</h3><p class="muted">Xác nhận mật khẩu rồi quét QR.</p></a>
        <a class="panel" href="${isAdmin ? "/console" : "/history"}" data-go="${isAdmin ? "/console" : "/history"}"><h3 class="page" style="font-size:28px">${isAdmin ? "Điều hành" : "Lịch sử của tôi"}</h3><p class="muted">${isAdmin ? "Package · Key · SePay · API" : "Chỉ giao dịch của bạn."}</p></a>
      </div>`;
  }

  function shopView() {
    const bundles = [...new Set(state.shop.map((p) => p.bundleId).filter(Boolean))];
    const list = state.shop.filter((p) => state.bundle === "all" || p.bundleId === state.bundle);
    const groups = new Map();
    list.forEach((p) => {
      const k = p.bundleId || "khác";
      if (!groups.has(k)) groups.set(k, []);
      groups.get(k).push(p);
    });
    const chips = [`<button class="chip ${state.bundle === "all" ? "on" : ""}" data-bundle="all">Tất cả app</button>`]
      .concat(bundles.map((b) => `<button class="chip ${state.bundle === b ? "on" : ""}" data-bundle="${esc(b)}">${esc(b)}</button>`))
      .join("");
    let body = "";
    for (const [bid, pkgs] of groups) {
      body += `<section style="margin-top:22px"><p class="mono subtle">${esc(bid)}</p><div class="grid3" style="margin-top:10px">${pkgs
        .map(
          (p) => `<article class="pkg">
            <h3>${esc(p.name)}</h3>
            <p class="muted">${esc(p.description || "")}</p>
            <p class="price">${vnd(p.priceCents || p.priceVnd || 0)}</p>
            <p class="subtle">${p.durationDays || 0} ngày · ${p.maxDevices || 1} thiết bị</p>
            <button class="btn" style="margin-top:14px" data-buy="${p.id}">Mua</button>
          </article>`,
        )
        .join("")}</div></section>`;
    }
    return `<p class="kicker">Cửa hàng</p><h1 class="page">Mua key theo package</h1><p class="lead">Bấm Mua → trang thanh toán VietQR. Webhook xong tự về lịch sử lấy key.</p><div class="chips">${chips}</div>${body || `<p class="empty">Chưa có package.</p>`}`;
  }

  function payView() {
    const o = state.order || {};
    const qr = (o.accountNumber || state.sepay.accountNumber) ? qrUrl(o) : "";
    const paid = o.status === "PAID";
    const ref = o.content || o.reference || "";
    return `<div class="pay">
      <div class="pay-top"><button type="button" class="icon-btn" data-go="/shop">‹</button><b>ShopDTA Pay</b></div>
      <p class="kicker">SePay · VietQR</p>
      <p class="amount">${vnd(o.amountVnd || o.totalCents || 0)}</p>
      <p class="subtle">${esc(o.accountName || state.sepay.accountName || "")} · ${esc(o.bankCode || state.sepay.bankCode || "")} ${esc(o.accountNumber || state.sepay.accountNumber || "")}</p>
      <div class="box">
        <p class="muted">Nội dung chuyển khoản</p>
        <p class="mono" style="font-size:22px;margin:6px 0">${esc(ref)}</p>
        ${qr ? `<a class="qr-link" href="${esc(qr)}" target="_blank" rel="noopener"><img class="qr" alt="QR" src="${esc(qr)}" /></a>
          <a class="btn" href="${esc(qr)}" target="_blank" rel="noopener">Mở QR</a>
          <button type="button" class="btn ghost" style="margin-top:8px" data-act="copy-ref">Sao chép nội dung CK</button>` : `<p class="err">Chưa cấu hình SePay.</p>`}
      </div>
      <div class="pay-status">${paid ? `<span style="color:var(--ok)">Đã nhận tiền · về lịch sử…</span>` : `<div class="spinner"></div><span>Đang chờ thanh toán…</span>`}</div>
      <button type="button" class="btn ghost" style="margin-top:18px" data-go="/history">Xem lịch sử</button>
    </div>`;
  }

  function historyView() {
    const buys = (state.orders || []).filter((o) => o.status === "PAID");
    const buyRows = buys.length
      ? buys
          .map((o) => {
            const item = (o.items && o.items[0]) || {};
            const key = (o.license && o.license.key) || "";
            return `<article class="panel hist-card" style="margin-bottom:8px;cursor:pointer" data-go="/keys">
              <p class="page" style="font-size:26px;margin:0">${esc(item.packageName || "Package")}</p>
              <p class="mono" style="color:var(--line)">${esc(key || "Đang cấp key…")}</p>
              <p class="subtle">${vnd(o.totalCents || o.amountVnd || 0)} · ${esc(o.paidAt || o.createdAt || "")}</p>
              ${key ? `<button type="button" class="btn sm" style="margin-top:10px" data-act="copy-key" data-key="${esc(key)}">Sao chép key</button>` : ""}
            </article>`;
          })
          .join("")
      : `<p class="empty">Chưa mua key.</p>`;
    const payRows = (state.orders || []).length
      ? `<div class="table-wrap"><table><thead><tr><th>Mã</th><th>Tiền</th><th>Status</th><th></th></tr></thead><tbody>${state.orders
          .map((o) => `<tr data-open-order="${esc(o.id)}" style="cursor:pointer">
            <td class="mono">${esc(o.reference || o.id)}</td>
            <td class="mono">${vnd(o.totalCents || o.amountVnd || 0)}</td>
            <td>${esc(o.status)}</td>
            <td>${o.status === "PENDING" ? "QR" : "Xem"}</td>
          </tr>`)
          .join("")}</tbody></table></div>`
      : `<p class="empty">Chưa có giao dịch.</p>`;
    return `<p class="kicker">Tài khoản</p><h1 class="page">Lịch sử</h1><p class="lead">Mua key và thanh toán SePay. Bấm đơn để xem QR / key.</p><h3 class="page" style="font-size:28px">Mua key</h3>${buyRows}<h3 class="page" style="font-size:28px;margin-top:28px">Thanh toán</h3>${payRows}`;
  }

  function keysView() {
    const rows = state.keys.length
      ? state.keys
          .map((l) => {
            const acts = (l.activations || []).filter((a) => Number(a.active) === 1);
            const dead = remainLabel(l.expiresAt) === "Hết hạn" || l.status !== "ACTIVE";
            return `<article class="panel" style="margin-bottom:12px">
              <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap">
                <div>
                  <p class="mono">${esc(l.key)}</p>
                  <p class="muted">${esc(l.package?.name || l.packageName || "")} · ${esc(l.bundleId || l.packageBundleId || "")}</p>
                  <p class="subtle">${esc(l.status)} · ${acts.length}/${l.maxDevices || 1} máy</p>
                </div>
                <div style="text-align:right">
                  <p class="subtle">Còn lại</p>
                  <p class="page remain" data-remain="${esc(l.expiresAt || "")}" style="font-size:32px;margin:0;color:${dead ? "var(--danger)" : "var(--line)"}">${remainLabel(l.expiresAt)}</p>
                </div>
              </div>
              <p class="subtle" style="margin-top:12px">Thiết bị</p>
              ${
                acts.length
                  ? acts
                      .map(
                        (a) => `<div style="display:flex;justify-content:space-between;gap:8px;padding:8px 0;border-top:1px solid var(--border)">
                          <span class="mono subtle">${esc(a.deviceId || a.udid || "")} · ${esc(a.deviceName || "")}</span>
                          <button class="linkish" style="margin:0;width:auto" data-unbind="${a.id}">Gỡ máy</button>
                        </div>`,
                      )
                      .join("")
                  : `<p class="muted">Chưa gắn máy.</p>`
              }
            </article>`;
          })
          .join("")
      : `<p class="empty">Chưa có key.</p>`;
    return `<p class="kicker">License</p><h1 class="page">Key & máy</h1><p class="lead">Timer đếm ngược. Gỡ UDID khi đổi máy.</p>${rows}`;
  }

  function consoleView() {
    const tabs = (state.me?.roleName === "SUPER_ADMIN"
      ? ["Package", "Key", "Thiết bị", "Thanh toán", "Ban", "Đại lý", "Thử API", "API"]
      : ["Key", "Thiết bị", "Thanh toán"])
      .map((t) => `<button type="button" class="tab ${state.tab === t ? "on" : ""}" data-tab="${t}">${t}</button>`)
      .join("");
    let pane = "";
    if (state.tab === "Package") {
      pane = `
        <div class="panel">
          <h3 class="page" style="font-size:26px">Tạo / sửa package</h3>
          <div class="grid2">
            ${field("name", "Tên (hiện trên menu key)", state.form.name || "")}
            ${field("version", "Version", state.form.version || "1.0.0")}
            ${field("bundleId", "Bundle ID", state.form.bundleId || "")}
            ${field("priceCents", "Giá VND", state.form.priceCents || "99000")}
            ${field("durationDays", "Số ngày", state.form.durationDays || "30")}
            ${field("maxDevices", "Max devices", state.form.maxDevices || "1")}
            ${field("description", "Mô tả", state.form.description || "")}
          </div>
          <label class="switch-row">
            <span><b>Bật package</b><small>Hiện trên cửa hàng / app</small></span>
            <input type="checkbox" name="isActive" ${state.form.isActive === false || state.form.isActive === 0 || state.form.isActive === "0" ? "" : "checked"} />
          </label>
          <label class="switch-row">
            <span><b>Xác thực UDID</b><small>Tắt = chỉ nhập key, không lấy UDID</small></span>
            <input type="checkbox" name="requireUdid" ${state.form.requireUdid === false || state.form.requireUdid === 0 || state.form.requireUdid === "0" ? "" : "checked"} />
          </label>
          <div style="display:flex;gap:8px;margin-top:14px;flex-wrap:wrap">
            <button type="button" class="btn sm" data-act="save-pkg">Lưu</button>
            <button type="button" class="btn ghost sm" data-act="reset-pkg">Tạo mới</button>
          </div>
        </div>
        <div class="table-wrap" style="margin-top:16px">
          <table><thead><tr><th>Package</th><th>Bundle</th><th>Ver</th><th>Gói</th><th>UDID</th><th>Giá</th><th></th></tr></thead>
          <tbody>${state.packages
            .map((p) => {
              const on = !(p.isActive === false || p.isActive === 0);
              const ud = !(p.requireUdid === false || p.requireUdid === 0);
              return `<tr>
                <td>${esc(p.name)}</td><td class="mono">${esc(p.bundleId || "")}</td>
                <td class="mono">${esc(p.version || "1.0.0")}</td>
                <td><button type="button" class="chip ${on ? "on" : ""}" data-toggle-pkg="${p.id}" data-field="isActive" data-value="${on ? 0 : 1}">${on ? "Bật" : "Tắt"}</button></td>
                <td><button type="button" class="chip ${ud ? "on" : ""}" data-toggle-pkg="${p.id}" data-field="requireUdid" data-value="${ud ? 0 : 1}">${ud ? "Bật" : "Tắt"}</button></td>
                <td class="mono">${vnd(p.priceCents || 0)}</td>
                <td style="white-space:nowrap">
                  <button type="button" class="linkish" style="margin:0;width:auto" data-edit-pkg="${p.id}">Sửa</button>
                  <button type="button" class="linkish" style="margin:0;width:auto;color:var(--danger)" data-del-pkg="${p.id}">Xóa</button>
                </td>
              </tr>`;
            })
            .join("")}</tbody></table>
        </div>`;
    } else if (state.tab === "Key") {
      pane = `
        <div class="panel">
          <h3 class="page" style="font-size:26px">Phát hành key</h3>
          <div class="grid2">
            <label class="field"><span>Package</span>
              <select name="packageId">${state.packages.map((p) => `<option value="${p.id}">${esc(p.name)}</option>`).join("")}</select>
            </label>
            ${field("count", "Số lượng", "1")}
          </div>
          <button class="btn sm" style="margin-top:14px" data-act="issue">Phát hành</button>
          ${state.form.made ? `<pre class="mono muted">${esc(state.form.made)}</pre>` : ""}
        </div>
        <div class="table-wrap" style="margin-top:16px">
          <table><thead><tr><th>Key</th><th>Timer</th><th>Máy</th><th>Status</th><th></th></tr></thead>
          <tbody>${state.licenses
            .map((l) => `<tr>
              <td class="mono">${esc(l.key)}</td>
              <td class="mono remain" data-remain="${esc(l.expiresAt || "")}">${remainLabel(l.expiresAt)}</td>
              <td class="mono">${l.activeDevices ?? (l.activations || []).filter((a) => Number(a.active) === 1).length}/${l.maxDevices || 1}</td>
              <td>${esc(l.status)}</td>
              <td><button class="linkish" style="margin:0;width:auto" data-extend="${l.id}">+7 ngày</button></td>
            </tr>`)
            .join("")}</tbody></table>
        </div>`;
    } else if (state.tab === "Thiết bị") {
      pane = `
        <div class="panel">
          <h3 class="page" style="font-size:26px">Enroll UDID</h3>
          <p class="muted">App tải .mobileconfig → iPhone POST UDID → mới cho nhập key. Mã 6405 nếu chưa enroll.</p>
          <label class="field" style="margin-top:12px"><span>Bắt buộc enroll</span>
            <select name="requireEnrolled"><option value="1" ${state.requireEnrolled ? "selected" : ""}>Bật</option><option value="0" ${state.requireEnrolled ? "" : "selected"}>Tắt (dylib cũ)</option></select>
          </label>
          <button class="btn sm" style="margin-top:12px" data-act="udid-setting">Lưu</button>
        </div>
        <div class="table-wrap" style="margin-top:16px">
          <table><thead><tr><th>Token</th><th>Status</th><th>UDID</th><th>Máy</th><th></th></tr></thead>
          <tbody>${(state.enrollments || []).length
            ? (state.enrollments || []).map((e) => `<tr>
                <td class="mono">${esc((e.token || "").slice(0, 12))}…</td>
                <td>${esc(e.status || "")}</td>
                <td class="mono">${esc(e.udid || "—")}</td>
                <td class="mono">${esc(e.product || "")}</td>
                <td>${e.token ? `<a class="linkish" href="/udid?token=${encodeURIComponent(e.token)}">Mở trang lấy UDID</a>` : ""}</td>
              </tr>`).join("")
            : `<tr><td colspan="5" class="muted">Chưa có session. App gọi GET /udid/enroll hoặc mở /udid.</td></tr>`}</tbody>
          </table>
        </div>
        <div class="table-wrap" style="margin-top:16px">
          <table><thead><tr><th>Máy</th><th>UDID</th><th>Key</th><th>Status</th><th></th></tr></thead>
          <tbody>${(state.devices || [])
            .map(
              (d) => `<tr>
                <td>${esc(d.deviceName || "")}</td>
                <td class="mono">${esc(d.deviceId || d.udid || "")}</td>
                <td class="mono">${esc(d.licenseKey || "")}</td>
                <td>${Number(d.active) === 1 ? "Active" : "Đã gỡ"}</td>
                <td>${Number(d.active) === 1 ? `<button class="linkish" style="margin:0;width:auto" data-unbind="${d.id}">Gỡ máy</button>` : ""}</td>
              </tr>`,
            )
            .join("")}</tbody></table>
        </div>`;
    } else if (state.tab === "Thanh toán") {
      pane = `
        <div class="panel">
          <h3 class="page" style="font-size:26px">SePay</h3>
          <p class="muted">Webhook POST /api/webhooks/sepay · header Authorization: Apikey TOKEN</p>
          <div class="grid2">
            ${field("bankCode", "Mã NH (VietQR)", state.sepay.bankCode || "VCB")}
            ${field("accountNumber", "Số tài khoản", state.sepay.accountNumber || "")}
            ${field("accountName", "Chủ tài khoản", state.sepay.accountName || "")}
            ${field("webhookToken", "Webhook token", state.sepay.webhookToken === "configured" ? "" : state.sepay.webhookToken || "", "password")}
          </div>
          <button class="btn sm" style="margin-top:14px" data-act="save-sepay">Lưu SePay</button>
        </div>
        <div class="table-wrap" style="margin-top:16px">
          <table><thead><tr><th>Đơn</th><th>Tiền</th><th>Status</th></tr></thead>
          <tbody>${(state.orders || [])
            .map((o) => `<tr><td class="mono">${esc(o.reference || o.id)}</td><td class="mono">${vnd(o.totalCents || o.amountVnd || 0)}</td><td>${esc(o.status)}</td></tr>`)
            .join("")}</tbody></table>
        </div>`;
    } else if (state.tab === "Thử API") {
      const r = state.testOut;
      pane = `
        <div class="panel">
          <h3 class="page" style="font-size:26px">Công cụ thử API</h3>
          <p class="muted">POST /debug/client — package-v3 · credential-v3 · key-v3 · health</p>
          <div class="chips" style="margin-top:12px">
            ${["health","package-v3","credential-v3","key-v3"].map((e)=>`<button class="chip ${state.form.ep===e?"on":""}" data-ep="${e}">${e}</button>`).join("")}
          </div>
          <div class="grid2" style="margin-top:12px">
            ${field("bundleId", "Bundle ID", state.form.bundleId || "com.garena.game.kgvn1")}
            ${field("udid", "UDID", state.form.udid || "TEST-UDID")}
            ${field("device", "Device", state.form.device || "iPhone15,2")}
            ${field("key", "Key", state.form.key || "")}
          </div>
          <button class="btn sm" style="margin-top:14px" data-act="test-api">Gửi</button>
          <button class="btn ghost sm" style="margin-top:8px" data-act="sec-scan">Kiểm tra bảo mật</button>
        </div>
        ${state.secScan ? `<div class="panel" style="margin-top:12px"><p class="subtle">Bảo mật ${state.secScan.score || ""}</p>
          ${(state.secScan.items||[]).map((s)=>`<p class="${s.ok?"muted":"err"}">${s.ok?"OK":"LỖI"} · ${esc(s.title)} — ${esc(s.detail)}</p>`).join("")}
        </div>` : ""}
        ${r ? `${apiWarn(Number((r.response&&r.response.code)||0), (r.response&&r.response.message)||"")}
          <div class="grid2" style="margin-top:12px">
          <div class="panel"><p class="subtle">Request</p><pre class="mono" style="white-space:pre-wrap;font-size:12px">${esc(JSON.stringify(r.request, null, 2))}</pre></div>
          <div class="panel"><p class="subtle">Response</p><pre class="mono" style="white-space:pre-wrap;font-size:12px">${esc(JSON.stringify(r.response, null, 2))}</pre></div>
        </div>` : ""}`;
    } else if (state.tab === "Ban") {
      pane = `
        <div class="panel">
          <h3 class="page" style="font-size:26px">Ban UDID / IP</h3>
          <p class="muted">Client bị ban nhận mã 6403.</p>
          <div class="grid2">
            <label class="field"><span>Loại</span><select name="kind"><option value="udid">UDID</option><option value="ip">IP</option></select></label>
            ${field("value", "Giá trị", "")}
            ${field("reason", "Lý do", "share key")}
          </div>
          <button class="btn sm" style="margin-top:14px" data-act="add-ban">Ban</button>
        </div>
        <div class="table-wrap" style="margin-top:16px">
          <table><thead><tr><th>Loại</th><th>Giá trị</th><th>Lý do</th><th></th></tr></thead>
          <tbody>${(state.bans || []).map((b) => `<tr><td>${esc(b.kind)}</td><td class="mono">${esc(b.value)}</td><td>${esc(b.reason)}</td><td>${Number(b.active)===1?`<button class="linkish" data-unban="${b.id}">Gỡ</button>`:""}</td></tr>`).join("")}</tbody>
          </table>
        </div>`;
    } else if (state.tab === "Đại lý") {
      pane = `
        <div class="panel">
          <h3 class="page" style="font-size:26px">Đại lý</h3>
          <p class="muted">Hoa hồng theo mã giới thiệu.</p>
        </div>
        <div class="table-wrap" style="margin-top:12px">
          <table><thead><tr><th>User</th><th>Mã</th><th>%</th><th></th></tr></thead>
          <tbody>${(state.people || []).map((p) => `<tr>
            <td>${esc(p.email)}</td>
            <td class="mono">${esc(p.referralCode || "")}</td>
            <td>${esc(p.commissionPct || 0)}</td>
            <td>${p.roleName === "RESELLER" || p.isReseller ? "Đại lý" : `<button class="linkish" data-promote="${p.id}">Lên đại lý</button>`}</td>
          </tr>`).join("")}</tbody></table>
        </div>`;
    } else {
      pane = `<div class="table-wrap"><table><thead><tr><th>Endpoint</th><th>Code</th><th>Tóm tắt</th></tr></thead>
        <tbody>${(state.logs || [])
          .map((l) => `<tr data-log="${l.id}" style="cursor:pointer"><td class="mono">${esc(l.endpoint || l.path || "")}</td><td class="mono">${esc(l.resultCode || l.statusCode || "")}</td><td class="muted">${esc(l.summary || l.responseSummary || l.message || "")}</td></tr>`)
          .join("")}</tbody></table></div>
        ${
          state.openLog
            ? `<div class="modal-bg" data-act="close-log"><div class="modal" data-stop="1" style="max-width:640px">
                <p class="kicker">API log</p>
                <h3 class="page" style="font-size:28px">${esc(state.openLog.endpoint || "")}</h3>
                <p class="subtle">${esc(state.openLog.resultCode || "")} · ${esc(state.openLog.udid || "")} · ${esc(state.openLog.createdAt || "")}</p>
                <p class="subtle" style="margin-top:12px">Request</p>
                <pre class="mono" style="white-space:pre-wrap;font-size:11px">${esc(JSON.stringify(state.openLog.request || { bundleId: state.openLog.bundleId, udid: state.openLog.udid }, null, 2))}</pre>
                <p class="subtle" style="margin-top:12px">Full</p>
                <pre class="mono" style="white-space:pre-wrap;font-size:11px">${esc(JSON.stringify(state.openLog, null, 2))}</pre>
                <button class="btn ghost" data-act="close-log">Đóng</button>
              </div></div>`
            : ""
        }`;
    }
    return `<p class="kicker">Điều hành</p><h1 class="page">Package, key, SePay, API</h1><p class="lead">Gộp quản trị một màn. Menu trái xếp dọc.</p><div class="tabs">${tabs}</div>${pane}`;
  }

  function esc(s) {
    return String(s ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function render() {
    const y = window.scrollY;
    if (!state.me && state.page !== "/login") {
      app.innerHTML = loginView();
      bind();
      return;
    }
    if (state.page === "/login") app.innerHTML = loginView();
    else if (state.page === "/shop") app.innerHTML = shell(shopView());
    else if (state.page === "/keys") app.innerHTML = shell(keysView());
    else if (state.page === "/history") app.innerHTML = shell(historyView());
    else if (state.page === "/console") app.innerHTML = shell(consoleView());
    else if (state.page.startsWith("/pay")) app.innerHTML = payView();
    else app.innerHTML = shell(homeView());
    bind();
    state.menuEnter = false;
    if (y) window.scrollTo(0, y);
  }

  function tickRemain() {
    document.querySelectorAll("[data-remain]").forEach((el) => {
      const label = remainLabel(el.getAttribute("data-remain"));
      if (el.textContent !== label) el.textContent = label;
      if (label === "Hết hạn") el.style.color = "var(--danger)";
    });
  }

  async function onAppClick(e) {
      if (e.target.matches && e.target.matches("input,select,textarea,option")) return;
      if (e.target.classList.contains("modal-bg")) {
        const a = e.target.dataset.act;
        if (a === "close-order") { stopPoll(); state.order = null; go("/history"); return; }
        if (a === "close-log") { state.openLog = null; render(); return; }
        if (a === "close") { state.menu = false; state.menuEnter = false; render(); return; }
      }
      const t = e.target.closest("[data-go],[data-act],[data-bundle],[data-buy],[data-tab],[data-edit-pkg],[data-del-pkg],[data-unbind],[data-extend],[data-log],[data-unban],[data-promote],[data-ep],[data-open-order],[data-key],[data-toggle-pkg]");
      if (!t) return;
      if (t.closest("[data-stop]") && t.dataset.act === "close-order" && e.target.classList.contains("modal-bg") === false && t.dataset.act !== "close-order") {
        /* keep */
      }
      e.preventDefault();
      if (t.classList.contains("drawer-bg") && t.dataset.act === "close" && e.target !== t) return;
      if (t.dataset.openOrder) {
        const o = (state.orders || []).find((x) => String(x.id) === String(t.dataset.openOrder));
        if (o) {
          if (o.status === "PAID") { go("/keys"); return; }
          state.order = o;
          go("/pay/" + o.id);
        }
        return;
      }
      if (t.dataset.go) {
        e.preventDefault();
        go(t.dataset.go);
        return;
      }
      if (t.dataset.bundle) {
        state.bundle = t.dataset.bundle;
        render();
        return;
      }
      if (t.dataset.ep) {
        state.form = { ...state.form, ep: t.dataset.ep };
        render();
        return;
      }
      if (t.dataset.tab) {
        state.tab = t.dataset.tab;
        render();
        loadPage();
        return;
      }
      if (t.dataset.buy) {
        try {
          const order = await api("/shop/checkout", { method: "POST", body: { packageId: t.dataset.buy } });
          state.order = order;
          go("/pay/" + order.id);
        } catch (err) {
          alert(err.message);
        }
        return;
      }
      if (t.dataset.togglePkg) {
        try {
          const body = { [t.dataset.field]: Number(t.dataset.value) };
          await api("/packages/" + t.dataset.togglePkg, { method: "PATCH", body });
          await loadPage();
        } catch (err) { alert(err.message); }
        return;
      }
      if (t.dataset.delPkg) {
        if (!confirm("Xóa package này? Ẩn khỏi shop. Nếu chưa có key sẽ xóa hẳn.")) return;
        try {
          await api("/packages/" + t.dataset.delPkg, { method: "DELETE" });
          if (state.form.id === t.dataset.delPkg) state.form = {};
          await loadPage();
        } catch (err) { alert(err.message); }
        return;
      }
      if (t.dataset.editPkg) {
        const p = state.packages.find((x) => x.id === t.dataset.editPkg);
        if (p) {
          state.form = { ...p, priceCents: String(p.priceCents || 0) };
          render();
        }
        return;
      }
      if (t.dataset.unbind) {
        try {
          await api("/devices/" + t.dataset.unbind + "/unbind", { method: "POST" });
          await loadPage();
        } catch (err) {
          alert(err.message);
        }
        return;
      }
      if (t.dataset.log) {
        state.openLog = (state.logs || []).find((l) => String(l.id) === String(t.dataset.log)) || null;
        render();
        return;
      }
      if (t.dataset.unban) {
        try { await api("/bans/" + t.dataset.unban + "/unban", { method: "POST" }); await loadPage(); } catch (err) { alert(err.message); }
        return;
      }
      if (t.dataset.promote) {
        try { await api("/users/" + t.dataset.promote + "/promote", { method: "POST", body: { commissionPct: 20 } }); await loadPage(); } catch (err) { alert(err.message); }
        return;
      }
      if (t.dataset.extend) {
        try {
          await api("/licenses/" + t.dataset.extend + "/extend", { method: "POST", body: { days: 7 } });
          await loadPage();
        } catch (err) {
          alert(err.message);
        }
        return;
      }
      const act = t.dataset.act;
      if (act === "menu") {
        state.menu = true;
        state.menuEnter = true;
        render();
      } else if (act === "close") {
        state.menu = false;
        state.menuEnter = false;
        render();
      } else if (act === "toggle-pass") {
        const wrap = t.closest(".pass-wrap");
        const input = wrap && wrap.querySelector("input");
        if (input) {
          const show = input.type === "password";
          input.type = show ? "text" : "password";
          t.setAttribute("aria-label", show ? "Ẩn mật khẩu" : "Hiện mật khẩu");
          t.textContent = show ? "Ẩn" : "Hiện";
        }
      } else if (act === "sec-scan") {
        try {
          state.secScan = await api("/debug/security");
          render();
        } catch (err) {
          alert(err.message);
        }
      } else if (act === "udid-setting") {
        const box = t.closest(".panel") || app;
        const o = collect(box);
        try {
          const r = await api("/settings/udid", { method: "PATCH", body: { requireEnrolled: o.requireEnrolled === "1" } });
          state.requireEnrolled = !!r.requireEnrolled;
          render();
        } catch (err) { alert(err.message); }
      } else if (act === "test-api") {
        const box = t.closest("main") || app;
        const o = collect(box);
        try {
          state.testOut = await api("/debug/client", {
            method: "POST",
            body: {
              endpoint: state.form.ep || "package-v3",
              bundleId: o.bundleId,
              udid: o.udid,
              device: o.device,
              key: o.key,
            },
          });
          render();
        } catch (err) {
          alert(err.message);
        }
      } else if (act === "add-ban") {
        const box = t.closest(".panel") || app;
        const o = collect(box);
        try {
          await api("/bans", { method: "POST", body: { kind: o.kind || "udid", value: o.value, reason: o.reason } });
          await loadPage();
        } catch (err) { alert(err.message); }
      } else if (act === "copy-ref") {
        const ref = (state.order && (state.order.content || state.order.reference)) || "";
        if (ref && navigator.clipboard) navigator.clipboard.writeText(ref);
        t.textContent = "Đã sao chép nội dung CK";
      } else if (act === "copy-key") {
        const k = t.dataset.key || "";
        if (k && navigator.clipboard) navigator.clipboard.writeText(k);
        t.textContent = "Đã sao chép key";
      } else if (act === "close-order") {
        stopPoll();
        state.order = null;
        go("/history");
      } else if (act === "close-log") {
        state.openLog = null;
        render();
      } else if (act === "toggle-auth") {
        state.form.mode = state.form.mode === "up" ? "in" : "up";
        state.err = "";
        render();
      } else if (act === "logout") {
        try {
          await api("/auth/logout", { method: "POST" });
        } catch (_) {}
        state.token = "";
        state.me = null;
        localStorage.removeItem(TOKEN_KEY);
        go("/login");
      } else if (act === "save-pkg") {
        const f = collect(t.closest("main"));
        try {
          const body = {
            name: f.name,
            bundleId: f.bundleId,
            priceCents: Number(f.priceCents) || 0,
            durationDays: Number(f.durationDays) || 30,
            maxDevices: Number(f.maxDevices) || 1,
            description: f.description,
            version: f.version || "1.0.0",
            isActive: f.isActive ? 1 : 0,
            requireUdid: f.requireUdid ? 1 : 0,
          };
          if (state.form.id) await api("/packages/" + state.form.id, { method: "PATCH", body });
          else await api("/packages", { method: "POST", body });
          state.form = {};
          await loadPage();
        } catch (err) {
          alert(err.message);
        }
      } else if (act === "issue") {
        const f = collect(t.closest("main"));
        try {
          const r = await api("/licenses", { method: "POST", body: { packageId: f.packageId, count: Number(f.count) || 1 } });
          const keys = (r.items || r.keys || []).map((x) => (typeof x === "string" ? x : x.key || x)).filter(Boolean);
          if (r.key) keys.unshift(r.key);
          state.form.made = keys.join("\n") || JSON.stringify(r);
          await loadPage();
        } catch (err) {
          alert(err.message);
        }
      } else if (act === "save-sepay") {
        const f = collect(t.closest("main"));
        try {
          await api("/settings/sepay", { method: "POST", body: f });
          await loadPage();
        } catch (err) {
          alert(err.message);
        }
      } else if (act === "reset-pkg") {
        state.form = {};
        render();
      }
  }

  function bind() {
    if (!app._sdtaClick) {
      app.addEventListener("click", onAppClick, true);
      app._sdtaClick = true;
    }
    const form = $("[data-form=login]");
    if (form) {
      form.onsubmit = async (e) => {
        e.preventDefault();
        const fd = new FormData(form);
        const email = String(fd.get("email") || "");
        const password = String(fd.get("password") || "");
        const name = String(fd.get("name") || "");
        const confirmPassword = String(fd.get("confirmPassword") || "");
        try {
          const path = state.form.mode === "up" ? "/auth/register" : "/auth/login";
          const body = state.form.mode === "up" ? { email, password, name, confirmPassword } : { email, password };
          if (state.form.mode === "up" && password !== confirmPassword) {
            state.err = "Mật khẩu xác nhận không khớp.";
            render();
            return;
          }
          const r = await api(path, { method: "POST", body });
          state.token = r.accessToken;
          localStorage.setItem(TOKEN_KEY, state.token);
          state.me = await api("/users/me");
          go("/");
        } catch (err) {
          state.err = err.message === "INVALID_CREDENTIALS" ? "Email hoặc mật khẩu không đúng." : err.message;
          render();
        }
      };
    }
  }

  function collect(root) {
    const o = {};
    root.querySelectorAll("input[name], select[name], textarea[name]").forEach((el) => {
      if (el.type === "checkbox") o[el.name] = el.checked;
      else o[el.name] = el.value;
    });
    return o;
  }

  async function boot() {
    if (state.token) {
      try {
        state.me = await api("/users/me");
      } catch (_) {
        state.token = "";
        localStorage.removeItem(TOKEN_KEY);
      }
    }
    if (!state.me) {
      state.page = "/login";
      if (location.pathname !== "/login") history.replaceState({}, "", "/login");
    } else if (state.page === "/login") {
      state.page = "/";
      history.replaceState({}, "", "/");
    }
    render();
    if (state.me) loadPage();
  }

  async function loadPage() {
    try {
      if (state.page === "/" || state.page === "/shop") {
        const r = await api("/shop/packages");
        state.shop = r.items || [];
      }
      if (state.page === "/" && state.me?.roleName === "SUPER_ADMIN") {
        try {
          state.dash = await api("/dashboard");
        } catch (_) {}
      }
      if (state.page === "/" || state.page === "/keys") {
        const r = await api("/licenses?pageSize=100");
        state.keys = r.items || [];
        try {
          const d = await api("/devices");
          state.devices = d.items || [];
        } catch (_) {}
      }
      if (state.page.startsWith("/pay")) {
        const id = state.page.replace(/^\/pay\/?/, "").split("/")[0];
        if (id) {
          const o = await api("/payments/orders/" + id);
          state.order = o;
          if (o.status === "PAID") {
            setTimeout(() => go("/history"), 600);
          } else {
            startPoll(id);
          }
        }
      }
      if (state.page === "/" || state.page === "/history" || state.page === "/shop") {
        try {
          const o = await api("/payments/orders?pageSize=50");
          state.orders = o.items || [];
        } catch (_) {}
      }
      if (state.page === "/console") {
        const p = await api("/packages?pageSize=200");
        state.packages = p.items || [];
        const l = await api("/licenses?pageSize=100");
        state.licenses = l.items || [];
        try {
          const o = await api("/payments/orders?pageSize=50");
          state.orders = o.items || [];
        } catch (_) {}
        try {
          const d = await api("/devices");
          state.devices = d.items || [];
        } catch (_) {}
        try {
          const en = await api("/udid/enrollments");
          state.enrollments = en.items || [];
          if (typeof en.requireEnrolled === "boolean") state.requireEnrolled = en.requireEnrolled;
        } catch (_) {}
        try {
          state.sepay = await api("/settings/sepay");
        } catch (_) {}
        try {
          const logs = await api("/client-logs?pageSize=50");
          state.logs = logs.items || logs || [];
        } catch (_) {
          try {
            const logs = await api("/api-logs?pageSize=50");
            state.logs = logs.items || [];
          } catch (__) {}
        }
        try {
          const b = await api("/bans");
          state.bans = b.items || [];
        } catch (_) {}
        try {
          const people = await api("/users?pageSize=100");
          state.people = people.items || [];
        } catch (_) {}
      }
      render();
    } catch (e) {
      if (e.status === 401) {
        state.me = null;
        state.token = "";
        go("/login");
      }
    }
  }

  window.addEventListener("popstate", () => {
    state.page = location.pathname || "/";
    render();
    loadPage();
  });

  let pollTimer = 0;
  function stopPoll() {
    if (pollTimer) clearInterval(pollTimer);
    pollTimer = 0;
  }
  function startPoll(id) {
    stopPoll();
    pollTimer = setInterval(async () => {
      try {
        const o = await api("/payments/orders/" + id);
        state.order = { ...state.order, ...o };
        if (o.status === "PAID") {
          stopPoll();
          state.order = { ...state.order, ...o };
          render();
          setTimeout(() => {
            state.order = null;
            go("/history");
          }, 900);
        } else {
          const st = document.querySelector(".pay-status span");
          if (st) st.textContent = "Đang chờ thanh toán…";
        }
      } catch (_) {}
    }, 2000);
  }

  let eventSeq = 0;
  setInterval(async () => {
    if (!state.token) return;
    try {
      const r = await api("/events?after=" + eventSeq);
      const items = r.items || [];
      for (const e of items) {
        eventSeq = Math.max(eventSeq, Number(e.seq) || 0);
        if (e.type === "order.paid" && state.order && (e.payload.orderId === state.order.id || e.payload.reference === (state.order.reference || state.order.content))) {
          stopPoll();
          state.order = { ...state.order, status: "PAID" };
          render();
          setTimeout(() => {
            state.order = null;
            go("/history");
          }, 700);
        }
      }
    } catch (_) {}
  }, 2500);

  setInterval(tickRemain, 1000);

  try { boot(); } catch (e) { app.innerHTML = '<p style="padding:24px;color:#e08b82">Lỗi giao diện: '+String(e && e.message || e)+'</p>'; }
})();
