-- cPanel MySQL schema for DTA Cloud Platform
-- Import this file into the MySQL database created in cPanel/phpMyAdmin.
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS `Role` (
  `id` VARCHAR(191) NOT NULL,
  `name` ENUM('SUPER_ADMIN', 'ADMIN', 'STAFF', 'CUSTOMER') NOT NULL,
  `createdAt` DATETIME(3) NOT NULL,
  `updatedAt` DATETIME(3) NOT NULL,
  UNIQUE KEY `uniq_name` (`name`),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `Permission` (
  `id` VARCHAR(191) NOT NULL,
  `key` VARCHAR(191) NOT NULL,
  `description` VARCHAR(191) NOT NULL,
  UNIQUE KEY `uniq_key` (`key`),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `RolePermission` (
  `roleId` VARCHAR(191) NOT NULL,
  `permissionId` VARCHAR(191) NOT NULL,
  `assignedAt` DATETIME(3) NOT NULL,
  PRIMARY KEY (`roleId`,`permissionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `User` (
  `id` VARCHAR(191) NOT NULL,
  `email` VARCHAR(191) NOT NULL,
  `passwordHash` VARCHAR(191) NOT NULL,
  `name` VARCHAR(191) NOT NULL,
  `status` ENUM('ACTIVE', 'SUSPENDED', 'LOCKED') NOT NULL DEFAULT 'ACTIVE',
  `roleId` VARCHAR(191) NOT NULL,
  `failedLoginCount` INT NOT NULL DEFAULT 0,
  `lockedUntil` DATETIME(3) NULL,
  `lastLoginAt` DATETIME(3) NULL,
  `twoFactorSecret` VARCHAR(191) NULL,
  `twoFactorEnabled` TINYINT(1) NOT NULL DEFAULT 0,
  `createdAt` DATETIME(3) NOT NULL,
  `updatedAt` DATETIME(3) NOT NULL,
  UNIQUE KEY `uniq_email` (`email`),
  PRIMARY KEY (`id`),
  KEY `idx_user_0` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `RefreshToken` (
  `id` VARCHAR(191) NOT NULL,
  `userId` VARCHAR(191) NOT NULL,
  `tokenHash` VARCHAR(191) NOT NULL,
  `expiresAt` DATETIME(3) NOT NULL,
  `revokedAt` DATETIME(3) NULL,
  `createdAt` DATETIME(3) NOT NULL,
  UNIQUE KEY `uniq_tokenHash` (`tokenHash`),
  PRIMARY KEY (`id`),
  KEY `idx_refreshtoken_0` (`userId`,`expiresAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `Product` (
  `id` VARCHAR(191) NOT NULL,
  `name` VARCHAR(191) NOT NULL,
  `slug` VARCHAR(191) NOT NULL,
  `description` VARCHAR(191) NOT NULL,
  `status` ENUM('DRAFT', 'PUBLISHED', 'ARCHIVED') NOT NULL DEFAULT 'DRAFT',
  `imageUrl` VARCHAR(191) NULL,
  `createdAt` DATETIME(3) NOT NULL,
  `updatedAt` DATETIME(3) NOT NULL,
  UNIQUE KEY `uniq_slug` (`slug`),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `Package` (
  `id` VARCHAR(191) NOT NULL,
  `productId` VARCHAR(191) NOT NULL,
  `name` VARCHAR(191) NOT NULL,
  `description` VARCHAR(191) NOT NULL,
  `priceCents` INT NOT NULL,
  `durationDays` INT NOT NULL,
  `licenseType` ENUM('TIME_BASED', 'DEVICE_BOUND', 'SUBSCRIPTION') NOT NULL,
  `maxDevices` INT NOT NULL DEFAULT 1,
  `bundleId` VARCHAR(191) NULL,
  `requestQuota` INT NULL,
  `isActive` TINYINT(1) NOT NULL DEFAULT 1,
  `requireUdid` TINYINT(1) NOT NULL DEFAULT 1,
  `createdAt` DATETIME(3) NOT NULL,
  `updatedAt` DATETIME(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_package_0` (`productId`,`isActive`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `License` (
  `id` VARCHAR(191) NOT NULL,
  `key` VARCHAR(191) NOT NULL,
  `status` ENUM('PENDING', 'ACTIVE', 'EXPIRED', 'SUSPENDED', 'REVOKED') NOT NULL DEFAULT 'PENDING',
  `licenseType` ENUM('TIME_BASED', 'DEVICE_BOUND', 'SUBSCRIPTION') NOT NULL,
  `ownerId` VARCHAR(191) NOT NULL,
  `packageId` VARCHAR(191) NOT NULL,
  `orderId` VARCHAR(191) NULL,
  `expiresAt` DATETIME(3) NULL,
  `maxDevices` INT NOT NULL DEFAULT 1,
  `bundleId` VARCHAR(191) NULL,
  `activatedAt` DATETIME(3) NULL,
  `revokedAt` DATETIME(3) NULL,
  `suspendedAt` DATETIME(3) NULL,
  `createdAt` DATETIME(3) NOT NULL,
  `updatedAt` DATETIME(3) NOT NULL,
  UNIQUE KEY `uniq_key` (`key`),
  PRIMARY KEY (`id`),
  KEY `idx_license_0` (`ownerId`,`status`),
  KEY `idx_license_1` (`packageId`),
  KEY `idx_license_2` (`bundleId`),
  KEY `idx_license_3` (`status`,`expiresAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `LicenseActivation` (
  `id` VARCHAR(191) NOT NULL,
  `licenseId` VARCHAR(191) NOT NULL,
  `deviceId` VARCHAR(191) NOT NULL,
  `deviceName` VARCHAR(191) NOT NULL,
  `active` TINYINT(1) NOT NULL DEFAULT 1,
  `activatedAt` DATETIME(3) NOT NULL,
  `deactivatedAt` DATETIME(3) NULL,
  UNIQUE KEY `uniq_licenseactivation_licenseId_deviceId` (`licenseId`,`deviceId`),
  PRIMARY KEY (`id`),
  KEY `idx_licenseactivation_0` (`licenseId`,`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `Application` (
  `id` VARCHAR(191) NOT NULL,
  `ownerId` VARCHAR(191) NOT NULL,
  `name` VARCHAR(191) NOT NULL,
  `description` VARCHAR(191) NOT NULL,
  `version` VARCHAR(191) NOT NULL DEFAULT 'v1',
  `isActive` TINYINT(1) NOT NULL DEFAULT 1,
  `createdAt` DATETIME(3) NOT NULL,
  `updatedAt` DATETIME(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_application_0` (`ownerId`,`isActive`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `ApiKey` (
  `id` VARCHAR(191) NOT NULL,
  `name` VARCHAR(191) NOT NULL,
  `hashedKey` VARCHAR(191) NOT NULL,
  `prefix` VARCHAR(191) NOT NULL,
  `scopes` JSON NOT NULL,
  `status` ENUM('ACTIVE', 'DISABLED', 'REVOKED') NOT NULL DEFAULT 'ACTIVE',
  `ownerId` VARCHAR(191) NOT NULL,
  `applicationId` VARCHAR(191) NOT NULL,
  `requestLimit` INT NULL,
  `rateLimit` INT NOT NULL DEFAULT 120,
  `rateWindowSeconds` INT NOT NULL DEFAULT 60,
  `allowedIps` JSON NOT NULL,
  `expiresAt` DATETIME(3) NULL,
  `lastUsedAt` DATETIME(3) NULL,
  `requestCount` INT NOT NULL DEFAULT 0,
  `createdAt` DATETIME(3) NOT NULL,
  `updatedAt` DATETIME(3) NOT NULL,
  UNIQUE KEY `uniq_hashedKey` (`hashedKey`),
  PRIMARY KEY (`id`),
  KEY `idx_apikey_0` (`ownerId`,`status`),
  KEY `idx_apikey_1` (`applicationId`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `ApiEndpoint` (
  `id` VARCHAR(191) NOT NULL,
  `applicationId` VARCHAR(191) NOT NULL,
  `method` VARCHAR(191) NOT NULL,
  `path` VARCHAR(191) NOT NULL,
  `description` VARCHAR(191) NOT NULL,
  `requiredScopes` JSON NOT NULL,
  `isActive` TINYINT(1) NOT NULL DEFAULT 1,
  `createdAt` DATETIME(3) NOT NULL,
  `updatedAt` DATETIME(3) NOT NULL,
  UNIQUE KEY `uniq_apiendpoint_applicationId_method_path` (`applicationId`,`method`,`path`),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `ApiLog` (
  `id` VARCHAR(191) NOT NULL,
  `apiKeyId` VARCHAR(191) NULL,
  `method` VARCHAR(191) NOT NULL,
  `path` VARCHAR(191) NOT NULL,
  `statusCode` INT NOT NULL,
  `latencyMs` INT NOT NULL,
  `ipAddress` VARCHAR(191) NOT NULL,
  `errorMessage` VARCHAR(191) NULL,
  `createdAt` DATETIME(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_apilog_0` (`apiKeyId`,`createdAt`),
  KEY `idx_apilog_1` (`statusCode`,`createdAt`),
  KEY `idx_apilog_2` (`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `ApiUsage` (
  `id` VARCHAR(191) NOT NULL,
  `apiKeyId` VARCHAR(191) NOT NULL,
  `date` DATETIME(3) NOT NULL,
  `requests` INT NOT NULL DEFAULT 0,
  `errors` INT NOT NULL DEFAULT 0,
  `latencyTotalMs` INT NOT NULL DEFAULT 0,
  UNIQUE KEY `uniq_apiusage_apiKeyId_date` (`apiKeyId`,`date`),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `ShortLink` (
  `id` VARCHAR(191) NOT NULL,
  `code` VARCHAR(191) NOT NULL,
  `targetUrl` VARCHAR(191) NOT NULL,
  `title` VARCHAR(191) NOT NULL,
  `status` ENUM('ACTIVE', 'DISABLED', 'EXPIRED') NOT NULL DEFAULT 'ACTIVE',
  `passwordHash` VARCHAR(191) NULL,
  `oneTimeUse` TINYINT(1) NOT NULL DEFAULT 0,
  `usedAt` DATETIME(3) NULL,
  `expiresAt` DATETIME(3) NULL,
  `ownerId` VARCHAR(191) NOT NULL,
  `createdAt` DATETIME(3) NOT NULL,
  `updatedAt` DATETIME(3) NOT NULL,
  UNIQUE KEY `uniq_code` (`code`),
  PRIMARY KEY (`id`),
  KEY `idx_shortlink_0` (`ownerId`,`status`),
  KEY `idx_shortlink_1` (`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `ShortLinkClick` (
  `id` VARCHAR(191) NOT NULL,
  `linkId` VARCHAR(191) NOT NULL,
  `visitorHash` VARCHAR(191) NOT NULL,
  `referrerCategory` VARCHAR(191) NOT NULL DEFAULT 'direct',
  `deviceCategory` VARCHAR(191) NOT NULL DEFAULT 'desktop',
  `browser` VARCHAR(191) NOT NULL DEFAULT 'Unknown',
  `operatingSystem` VARCHAR(191) NOT NULL DEFAULT 'Unknown',
  `region` VARCHAR(191) NOT NULL DEFAULT 'Unknown',
  `statusCode` INT NOT NULL DEFAULT 302,
  `clickedAt` DATETIME(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_shortlinkclick_0` (`linkId`,`clickedAt`),
  KEY `idx_shortlinkclick_1` (`visitorHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `Order` (
  `id` VARCHAR(191) NOT NULL,
  `reference` VARCHAR(191) NOT NULL,
  `userId` VARCHAR(191) NOT NULL,
  `status` ENUM('PENDING', 'PAID', 'FAILED', 'CANCELLED', 'REFUNDED') NOT NULL DEFAULT 'PENDING',
  `subtotalCents` INT NOT NULL,
  `totalCents` INT NOT NULL,
  `currency` VARCHAR(191) NOT NULL DEFAULT 'USD',
  `provider` VARCHAR(191) NOT NULL DEFAULT 'manual',
  `providerReference` VARCHAR(191) NULL,
  `idempotencyKey` VARCHAR(191) NULL,
  `paidAt` DATETIME(3) NULL,
  `createdAt` DATETIME(3) NOT NULL,
  `updatedAt` DATETIME(3) NOT NULL,
  UNIQUE KEY `uniq_reference` (`reference`),
  UNIQUE KEY `uniq_providerReference` (`providerReference`),
  UNIQUE KEY `uniq_idempotencyKey` (`idempotencyKey`),
  PRIMARY KEY (`id`),
  KEY `idx_order_0` (`userId`,`status`,`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `OrderItem` (
  `id` VARCHAR(191) NOT NULL,
  `orderId` VARCHAR(191) NOT NULL,
  `packageId` VARCHAR(191) NOT NULL,
  `quantity` INT NOT NULL,
  `unitPriceCents` INT NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_orderitem_0` (`orderId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `Wallet` (
  `id` VARCHAR(191) NOT NULL,
  `userId` VARCHAR(191) NOT NULL,
  `balanceCents` INT NOT NULL DEFAULT 0,
  `currency` VARCHAR(191) NOT NULL DEFAULT 'USD',
  `updatedAt` DATETIME(3) NOT NULL,
  UNIQUE KEY `uniq_userId` (`userId`),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `Transaction` (
  `id` VARCHAR(191) NOT NULL,
  `walletId` VARCHAR(191) NOT NULL,
  `orderId` VARCHAR(191) NULL,
  `type` ENUM('TOPUP', 'PURCHASE', 'REFUND', 'ADJUSTMENT') NOT NULL,
  `amountCents` INT NOT NULL,
  `balanceAfterCents` INT NOT NULL,
  `description` VARCHAR(191) NOT NULL,
  `externalReference` VARCHAR(191) NULL,
  `createdAt` DATETIME(3) NOT NULL,
  UNIQUE KEY `uniq_externalReference` (`externalReference`),
  PRIMARY KEY (`id`),
  KEY `idx_transaction_0` (`walletId`,`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `AuditLog` (
  `id` VARCHAR(191) NOT NULL,
  `userId` VARCHAR(191) NULL,
  `action` VARCHAR(191) NOT NULL,
  `entityType` VARCHAR(191) NOT NULL,
  `entityId` VARCHAR(191) NULL,
  `metadata` JSON NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `SystemSetting` (
  `key` VARCHAR(191) NOT NULL,
  `value` JSON NOT NULL,
  `description` VARCHAR(191) NOT NULL,
  `updatedAt` DATETIME(3) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

























CREATE TABLE IF NOT EXISTS `AccessToken` (
  `id` VARCHAR(191) NOT NULL,
  `userId` VARCHAR(191) NOT NULL,
  `tokenHash` VARCHAR(64) NOT NULL,
  `expiresAt` DATETIME(3) NOT NULL,
  `createdAt` DATETIME(3) NOT NULL,
  `revokedAt` DATETIME(3) NULL,
  UNIQUE KEY `uniq_accesstoken_hash` (`tokenHash`),
  KEY `idx_accesstoken_user` (`userId`,`expiresAt`),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- SePay settings live in SystemSetting key=sepay and/or private/config.php sepay_* keys.
-- Order.currency should be VND for SePay checkouts. Existing USD rows remain valid.
