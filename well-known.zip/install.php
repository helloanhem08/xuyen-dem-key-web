<?php
declare(strict_types=1);

ini_set('display_errors', '0');
ini_set('log_errors', '1');
error_reporting(E_ALL);

$privateDir = dirname(__DIR__) . '/private';
if (!is_dir($privateDir) && !is_writable(dirname(__DIR__))) {
    $privateDir = __DIR__ . '/private';
}
$lock = $privateDir . '/install.lock';
if (is_file($lock)) {
    http_response_code(403);
    exit('Installer locked. Xóa private/install.lock nếu muốn cài lại.');
}

$msg = '';
$error = '';
$publicKey = '';
$fingerprint = '';
$adminEmail = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $host = trim($_POST['db_host'] ?? 'localhost');
    $port = (int)($_POST['db_port'] ?? 3306);
    $name = trim($_POST['db_name'] ?? '');
    $user = trim($_POST['db_user'] ?? '');
    $pass = (string)($_POST['db_pass'] ?? '');
    $adminEmail = strtolower(trim($_POST['admin_email'] ?? ''));
    $adminName = trim($_POST['admin_name'] ?? 'Administrator');
    $adminPass = (string)($_POST['admin_pass'] ?? '');
    $transport = (string)($_POST['transport_key'] ?? 'h4HQn0A7kFN6xpydECEVp3H5oCc1kF6p');
    $rsaPrivate = trim((string)($_POST['rsa_private_key'] ?? ''));
    $bankCode = strtoupper(trim((string)($_POST['bank_code'] ?? 'VCB')));
    $accountNumber = trim((string)($_POST['account_number'] ?? ''));
    $accountName = trim((string)($_POST['account_name'] ?? ''));
    $webhookToken = trim((string)($_POST['webhook_token'] ?? ''));
    if ($webhookToken === '') {
        $webhookToken = bin2hex(random_bytes(16));
    }

    if (!$name || !$user || !filter_var($adminEmail, FILTER_VALIDATE_EMAIL) || strlen($adminPass) < 8 || strlen($transport) !== 32) {
        $error = 'Kiểm tra DB, email admin (mật khẩu ≥ 8) và Transport Key (đúng 32 ký tự).';
    } else {
        try {
            if (!is_dir($privateDir)) {
                mkdir($privateDir, 0700, true);
            }

            $pdo = new PDO(
                "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4",
                $user,
                $pass,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                ]
            );

            $sql = file_get_contents(__DIR__ . '/database.sql');
            $sql = preg_replace('/^\s*--.*$/m', '', $sql);
            foreach (preg_split('/;\s*(?:\r?\n|$)/', $sql) as $stmt) {
                $stmt = trim($stmt);
                if ($stmt !== '') {
                    $pdo->exec($stmt);
                }
            }

            $now = date('Y-m-d H:i:s.v');

            $role = $pdo->query("SELECT id FROM `Role` WHERE name = 'SUPER_ADMIN' LIMIT 1")->fetchColumn();
            if (!$role) {
                $role = bin2hex(random_bytes(16));
                $pdo->prepare("INSERT INTO `Role` (id, name, createdAt, updatedAt) VALUES (?, ?, ?, ?)")
                    ->execute([$role, 'SUPER_ADMIN', $now, $now]);
            }
            $customer = $pdo->query("SELECT id FROM `Role` WHERE name = 'CUSTOMER' LIMIT 1")->fetchColumn();
            if (!$customer) {
                $customer = bin2hex(random_bytes(16));
                $pdo->prepare("INSERT INTO `Role` (id, name, createdAt, updatedAt) VALUES (?, ?, ?, ?)")
                    ->execute([$customer, 'CUSTOMER', $now, $now]);
            }

            $st = $pdo->prepare("SELECT id FROM `User` WHERE email = ? LIMIT 1");
            $st->execute([$adminEmail]);
            $uid = $st->fetchColumn();
            $hash = password_hash($adminPass, PASSWORD_DEFAULT);
            if ($uid) {
                $pdo->prepare("UPDATE `User` SET passwordHash = ?, name = ?, status = 'ACTIVE', roleId = ?, updatedAt = ? WHERE id = ?")
                    ->execute([$hash, $adminName, $role, $now, $uid]);
            } else {
                $uid = bin2hex(random_bytes(16));
                $pdo->prepare(
                    "INSERT INTO `User` (id, email, passwordHash, name, status, roleId, failedLoginCount, twoFactorEnabled, createdAt, updatedAt)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
                )->execute([$uid, $adminEmail, $hash, $adminName, 'ACTIVE', $role, 0, 0, $now, $now]);
            }

            $w = $pdo->prepare("SELECT id FROM `Wallet` WHERE userId = ?");
            $w->execute([$uid]);
            if (!$w->fetchColumn()) {
                $pdo->prepare("INSERT INTO `Wallet` (id, userId, balanceCents, currency, updatedAt) VALUES (?, ?, ?, ?, ?)")
                    ->execute([bin2hex(random_bytes(16)), $uid, 0, 'VND', $now]);
            }

            if ($rsaPrivate === '') {
                $res = openssl_pkey_new([
                    'private_key_type' => OPENSSL_KEYTYPE_RSA,
                    'private_key_bits' => 2048,
                ]);
                if (!$res) {
                    throw new RuntimeException('Không tạo được RSA. Bật PHP OpenSSL.');
                }
                openssl_pkey_export($res, $rsaPrivate);
                $details = openssl_pkey_get_details($res);
                $publicKey = $details['key'] ?? '';
            } else {
                $details = openssl_pkey_get_details(openssl_pkey_get_private($rsaPrivate));
                if (!$details || empty($details['key'])) {
                    throw new RuntimeException('RSA private key không hợp lệ.');
                }
                $publicKey = $details['key'];
            }
            $b64 = preg_replace('/-----(BEGIN|END) PUBLIC KEY-----|\s/', '', $publicKey);
            $der = base64_decode($b64 ?: '', true);
            $fingerprint = $der ? hash('sha256', $der) : '';

            $baseUrl = rtrim(
                ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http')
                . '://' . ($_SERVER['HTTP_HOST'] ?? ''),
                '/'
            );

            $cfg = [
                'db' => [
                    'host' => $host,
                    'port' => $port,
                    'name' => $name,
                    'user' => $user,
                    'pass' => $pass,
                ],
                'base_url'            => $baseUrl,
                'transport_key'       => $transport,
                'rsa_private_key'     => $rsaPrivate,
                'sepay_webhook_token' => $webhookToken,
                'sepay' => [
                    'bankCode'      => $bankCode,
                    'accountNumber' => $accountNumber,
                    'accountName'   => $accountName,
                ],
            ];

            file_put_contents($privateDir . '/config.php', "<?php\nreturn " . var_export($cfg, true) . ";\n", LOCK_EX);
            chmod($privateDir . '/config.php', 0600);
            file_put_contents($privateDir . '/install.lock', date('c'), LOCK_EX);
            chmod($privateDir . '/install.lock', 0600);
            file_put_contents($privateDir . '/rsa-public-key.pem', $publicKey, LOCK_EX);

            $msg = 'Atelier đã dựng xong.';
        } catch (Throwable $e) {
            error_log('DTA install error: ' . $e->getMessage());
            $error = $e->getMessage();
        }
    }
}
?>
<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>ShopDTA · Install</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,500;1,500&family=Outfit:wght@400;500&family=IBM+Plex+Mono:wght@400&display=swap" rel="stylesheet">
<style>
:root{--bg:#070706;--fg:#f4efe6;--muted:#9a9488;--line:#c9b89a;--bd:rgb(244 239 230 / .1);--s:#12110f;--a:#efe8dc;--af:#12110f}
*{box-sizing:border-box}
body{margin:0;min-height:100dvh;background:radial-gradient(900px 480px at 80% -10%,rgb(201 184 154 / .08),transparent 50%) var(--bg);color:var(--fg);font:15px Outfit,system-ui}
.wrap{max-width:720px;margin:0 auto;padding:48px 20px 80px}
.mark{font-family:"Cormorant Garamond",serif;font-size:28px}
h1{font-family:"Cormorant Garamond",serif;font-size:clamp(40px,7vw,64px);font-weight:500;letter-spacing:-.03em;line-height:.95;margin:12px 0}
.k{font-size:11px;letter-spacing:.22em;text-transform:uppercase;color:#6b665c}
p.lead{color:var(--muted);max-width:46ch;line-height:1.6}
.card{background:var(--s);border:1px solid var(--bd);border-radius:18px;padding:22px;margin-top:28px}
label{display:grid;gap:8px;margin-top:14px;font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:var(--muted)}
input,textarea{width:100%;height:48px;border-radius:10px;border:1px solid var(--bd);background:#070706;color:var(--fg);padding:0 12px;font:14px Outfit,system-ui}
textarea{height:120px;padding:12px;font-family:"IBM Plex Mono",monospace;font-size:12px}
.grid{display:grid;gap:0 14px}
@media(min-width:640px){.grid{grid-template-columns:1fr 1fr}}
.full{grid-column:1/-1}
button{margin-top:22px;height:48px;width:100%;border:0;border-radius:10px;background:var(--a);color:var(--af);font-weight:500}
.ok{background:#142018;border:1px solid rgb(143 191 154 / .3);padding:16px;border-radius:14px;color:#8fbf9a}
.err{background:#2a1414;border:1px solid rgb(217 137 128 / .3);padding:16px;border-radius:14px;color:#d98980;margin-top:16px}
a{color:var(--line)}
</style>
</head>
<body>
<div class="wrap">
  <p class="mark">ShopDTA</p>
  <p class="k" style="margin-top:36px">Installer · cPanel</p>
  <h1>Dựng bàn<br><em style="color:var(--line);font-style:italic">làm việc.</em></h1>
  <p class="lead">Bản mới. RSA 2048 được tạo lúc cài — dán public key vào dylib sau. Transport giữ để app hiện tại còn kết nối.</p>

<?php if ($error): ?><div class="err"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<?php if ($msg): ?>
  <div class="card ok">
    <b><?= htmlspecialchars($msg) ?></b>
    <p>Admin: <?= htmlspecialchars($adminEmail) ?> · <a href="/">Mở dashboard</a></p>
    <p class="k">SHA256 SPKI</p>
    <p style="font-family:IBM Plex Mono,monospace;font-size:12px;word-break:break-all"><?= htmlspecialchars($fingerprint) ?></p>
    <label>RSA public key — dán vào APIClientConfig.h khi thay dylib
      <textarea readonly><?= htmlspecialchars($publicKey) ?></textarea>
    </label>
  </div>
<?php else: ?>
<form method="post" class="card">
  <p class="k">1 · MySQL</p>
  <div class="grid">
    <label>DB Host<input name="db_host" value="localhost"></label>
    <label>DB Port<input name="db_port" value="3306"></label>
    <label>Database<input name="db_name" required></label>
    <label>DB User<input name="db_user" required></label>
    <label class="full">DB Password<input name="db_pass" type="password"></label>
  </div>
  <p class="k" style="margin-top:28px">2 · Admin</p>
  <div class="grid">
    <label>Tên<input name="admin_name" value="Administrator"></label>
    <label>Email<input name="admin_email" type="email" required></label>
    <label class="full">Mật khẩu (≥ 8)<input name="admin_pass" type="password" minlength="8" required></label>
  </div>
  <p class="k" style="margin-top:28px">3 · SePay</p>
  <div class="grid">
    <label>Mã NH<input name="bank_code" value="VCB"></label>
    <label>Số tài khoản<input name="account_number"></label>
    <label class="full">Chủ tài khoản<input name="account_name" value="SHOP DTA"></label>
    <label class="full">Webhook token (trống = tự tạo)<input name="webhook_token"></label>
  </div>
  <p class="k" style="margin-top:28px">4 · Protocol</p>
  <label class="full">Transport key (32 ký tự — giữ mặc định nếu dylib cũ)
    <input name="transport_key" value="h4HQn0A7kFN6xpydECEVp3H5oCc1kF6p" required minlength="32" maxlength="32">
  </label>
  <label class="full">RSA private (trống = tạo cặp mới)
    <textarea name="rsa_private_key" placeholder="Để trống để installer tạo RSA mới. Chỉ dán nếu bạn muốn dùng key có sẵn."></textarea>
  </label>
  <button type="submit">Dựng atelier</button>
</form>
<?php endif; ?>
</div>
</body>
</html>
