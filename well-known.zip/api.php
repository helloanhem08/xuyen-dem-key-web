<?php
declare(strict_types=1);

// cPanel-friendly error handling: never display, always log to PHP error_log (visible in cPanel File Manager / Errors)
ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');
ini_set('log_errors', '1');
error_reporting(E_ALL);

$__earlyUri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$__earlyRoute = trim((string)($_GET['route'] ?? ''));
$__isV4early = str_starts_with($__earlyUri, '/v4/client/') || in_array($__earlyRoute, ['package-v3','credential-v3','key-v3'], true);
$__isUdidEarly = str_starts_with($__earlyUri, '/udid');
if (!$__isV4early && !$__isUdidEarly && session_status() !== PHP_SESSION_ACTIVE) {
    session_set_cookie_params([
        'httponly' => true,
        'samesite' => 'Lax',
        'secure'   => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    ]);
    session_start();
}

// Resolve private dir: prefer ~/private (sibling of public_html), fallback to public_html/private
$privateDir = dirname(__DIR__) . '/private';
if (!is_dir($privateDir)) {
    $privateDir = __DIR__ . '/private';
}
$configPath = $privateDir . '/config.php';
if (!is_file($configPath)) {
    http_response_code(503);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => 'NOT_INSTALLED', 'message' => 'Open /install.php']);
    exit;
}

/** @var array $cfg */
$cfg = require $configPath;

try {
    $pdo = new PDO(
        sprintf(
            'mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
            $cfg['db']['host'],
            (int)$cfg['db']['port'],
            $cfg['db']['name']
        ),
        $cfg['db']['user'],
        $cfg['db']['pass'],
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (Throwable $e) {
    error_log('DTA DB connection failed: ' . $e->getMessage());
    http_response_code(500);
    exit('Database connection failed. Check cPanel database/user privileges.');
}

function ensure_security_tables(): void
{
    global $pdo;
    try {
        $pdo->exec(
            "CREATE TABLE IF NOT EXISTS `BanTarget` (
                id VARCHAR(64) PRIMARY KEY,
                kind VARCHAR(16) NOT NULL,
                value VARCHAR(191) NOT NULL,
                reason VARCHAR(255) NULL,
                active TINYINT(1) NOT NULL DEFAULT 1,
                createdAt DATETIME(3) NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        );
        $pdo->exec(
            "CREATE TABLE IF NOT EXISTS `Commission` (
                id VARCHAR(64) PRIMARY KEY,
                resellerId VARCHAR(64) NOT NULL,
                orderId VARCHAR(64) NOT NULL,
                amountCents INT NOT NULL DEFAULT 0,
                commissionCents INT NOT NULL DEFAULT 0,
                createdAt DATETIME(3) NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        );
        foreach ([
            "ALTER TABLE `User` ADD COLUMN referralCode VARCHAR(16) NULL",
            "ALTER TABLE `User` ADD COLUMN referredBy VARCHAR(64) NULL",
            "ALTER TABLE `User` ADD COLUMN commissionPct INT NOT NULL DEFAULT 0",
            "ALTER TABLE `User` ADD COLUMN unbindCountWeek INT NOT NULL DEFAULT 0",
            "ALTER TABLE `User` ADD COLUMN unbindWeekStart DATE NULL",
            "ALTER TABLE `Package` ADD COLUMN version VARCHAR(32) NOT NULL DEFAULT '1.0.0'",
            "ALTER TABLE `Package` ADD COLUMN requireUdid TINYINT(1) NOT NULL DEFAULT 1",
            "ALTER TABLE `Order` ADD COLUMN referralCode VARCHAR(16) NULL",
        ] as $sql) {
            try { $pdo->exec($sql); } catch (Throwable $e) {}
        }
    } catch (Throwable $e) {
        error_log('ensure_security_tables: ' . $e->getMessage());
    }
}
ensure_security_tables();

function push_event(string $type, array $payload = []): void
{
    global $pdo;
    try {
        $pdo->exec(
            "CREATE TABLE IF NOT EXISTS `RealtimeEvent` (
                seq BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                type VARCHAR(64) NOT NULL,
                payloadJson TEXT NULL,
                createdAt DATETIME(3) NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        );
        $pdo->prepare("INSERT INTO `RealtimeEvent` (type, payloadJson, createdAt) VALUES (?, ?, ?)")
            ->execute([$type, json_encode($payload, JSON_UNESCAPED_UNICODE), nowms()]);
        $pdo->exec("DELETE FROM `RealtimeEvent` WHERE seq < (SELECT m FROM (SELECT MAX(seq) - 400 AS m FROM `RealtimeEvent`) t)");
    } catch (Throwable $e) {
        error_log('push_event: ' . $e->getMessage());
    }
}

function banned_row(?string $udid, ?string $ip): ?array
{
    global $pdo;
    if ($udid) {
        $s = $pdo->prepare("SELECT * FROM `BanTarget` WHERE active = 1 AND kind = 'udid' AND value = ? LIMIT 1");
        $s->execute([$udid]);
        $r = $s->fetch();
        if ($r) return $r;
    }
    if ($ip) {
        $s = $pdo->prepare("SELECT * FROM `BanTarget` WHERE active = 1 AND kind = 'ip' AND value = ? LIMIT 1");
        $s->execute([$ip]);
        $r = $s->fetch();
        if ($r) return $r;
    }
    return null;
}

function json_out(mixed $data, int $code = 200): never
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function body_json(): array
{
    $raw = file_get_contents('php://input');
    $d = json_decode($raw ?: '', true);
    return is_array($d) ? $d : $_POST;
}

function uid(): string
{
    return bin2hex(random_bytes(16));
}

function nowms(): string
{
    return date('Y-m-d H:i:s.v');
}

function page_limit(): array
{
    $p = max(1, (int)($_GET['page'] ?? 1));
    $n = min(200, max(1, (int)($_GET['pageSize'] ?? 50)));
    return [$p, $n, ($p - 1) * $n];
}

function hash_token(string $t): string
{
    return hash('sha256', $t);
}

function decorate_user(?array $u): ?array
{
    if (!$u) return null;
    if (($u['roleName'] ?? '') !== 'SUPER_ADMIN' && !empty($u['isReseller'])) {
        $u['roleName'] = 'RESELLER';
    }
    return $u;
}

function token_user(): ?array
{
    global $pdo;
    $h = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (!preg_match('/^Bearer\s+(.+)$/i', $h, $m)) {
        return null;
    }
    $s = $pdo->prepare(
        "SELECT u.*, r.name AS roleName
         FROM AccessToken t
         JOIN `User` u ON u.id = t.userId
         JOIN `Role` r ON r.id = u.roleId
         WHERE t.tokenHash = ? AND t.revokedAt IS NULL AND t.expiresAt > ? AND u.status = 'ACTIVE'
         LIMIT 1"
    );
    $s->execute([hash_token(trim($m[1])), nowms()]);
    return decorate_user($s->fetch() ?: null);
}

function current_user(): ?array
{
    $u = token_user();
    if ($u) {
        return $u;
    }
    global $pdo;
    if (empty($_SESSION['uid'])) {
        return null;
    }
    $s = $pdo->prepare(
        "SELECT u.*, r.name AS roleName
         FROM `User` u
         JOIN `Role` r ON r.id = u.roleId
         WHERE u.id = ?
         LIMIT 1"
    );
    $s->execute([$_SESSION['uid']]);
    return decorate_user($s->fetch() ?: null);
}

function require_login(): array
{
    $u = current_user();
    if (!$u) {
        json_out(['error' => 'UNAUTHORIZED'], 401);
    }
    return $u;
}

function admin(array $u, bool $staff = true): void
{
    $roles = $staff ? ['SUPER_ADMIN', 'ADMIN', 'STAFF'] : ['SUPER_ADMIN', 'ADMIN'];
    if (!in_array($u['roleName'] ?? '', $roles, true)) {
        json_out(['error' => 'FORBIDDEN'], 403);
    }
}

function audit(string $action, string $type, ?string $eid = null, array $meta = []): void
{
    global $pdo;
    $u = current_user();
    try {
        $pdo->prepare(
            "INSERT INTO `AuditLog` (id, userId, action, entityType, entityId, metadata, ipAddress, createdAt)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
        )->execute([
            uid(),
            $u['id'] ?? null,
            $action,
            $type,
            $eid,
            json_encode($meta),
            $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            nowms(),
        ]);
    } catch (Throwable $e) {
        error_log('audit failed: ' . $e->getMessage());
    }
}

function valid_bundle(?string $b): bool
{
    return $b === null || $b === '' || preg_match('/^[a-z0-9]+(?:[.-][a-z0-9]+)*$/i', $b) === 1;
}

function license_key(): string
{
    global $pdo;
    do {
        $k = 'DTA-' . strtoupper(bin2hex(random_bytes(4))) . '-' .
             strtoupper(bin2hex(random_bytes(4))) . '-' .
             strtoupper(bin2hex(random_bytes(4)));
        $s = $pdo->prepare("SELECT 1 FROM `License` WHERE `key` = ? LIMIT 1");
        $s->execute([$k]);
    } while ($s->fetchColumn());
    return $k;
}


function sepay_token(): string
{
    global $cfg, $pdo;
    if (!empty($cfg['sepay_webhook_token'])) {
        return (string)$cfg['sepay_webhook_token'];
    }
    try {
        $s = $pdo->prepare("SELECT value FROM `SystemSetting` WHERE `key` = 'sepay' LIMIT 1");
        $s->execute();
        $raw = $s->fetchColumn();
        if ($raw) {
            $j = json_decode((string)$raw, true);
            if (is_array($j) && !empty($j['webhookToken'])) {
                return (string)$j['webhookToken'];
            }
        }
    } catch (Throwable $e) {
    }
    return '';
}

function fulfill_paid_order(string $oid): void
{
    global $pdo;
    $now = nowms();
    $lock = $pdo->prepare("UPDATE `Order` SET status = 'PAID', paidAt = ?, provider = 'sepay', updatedAt = ? WHERE id = ? AND status = 'PENDING'");
    $lock->execute([$now, $now, $oid]);
    if ($lock->rowCount() === 0) {
        return;
    }
    $s = $pdo->prepare("SELECT * FROM `Order` WHERE id = ? LIMIT 1");
    $s->execute([$oid]);
    $o = $s->fetch();
    if (!$o) {
        return;
    }
    $s = $pdo->prepare(
        "SELECT oi.*, p.durationDays, p.licenseType, p.maxDevices, p.bundleId
         FROM `OrderItem` oi JOIN `Package` p ON p.id = oi.packageId WHERE oi.orderId = ?"
    );
    $s->execute([$oid]);
    foreach ($s->fetchAll() as $it) {
        for ($i = 0; $i < max(1, (int)$it['quantity']); $i++) {
            $pdo->prepare(
                "INSERT INTO `License`
                 (id, `key`, status, licenseType, ownerId, packageId, orderId,
                  expiresAt, maxDevices, bundleId, createdAt, updatedAt)
                 VALUES (?, ?, 'ACTIVE', ?, ?, ?, ?, ?, ?, ?, ?, ?)"
            )->execute([
                uid(),
                license_key(),
                $it['licenseType'],
                $o['userId'],
                $it['packageId'],
                $oid,
                date('Y-m-d H:i:s', time() + max(1, (int)$it['durationDays']) * 86400),
                (int)$it['maxDevices'],
                $it['bundleId'],
                $now,
                $now,
            ]);
        }
    }
    $ref = strtoupper(trim((string)($o['referralCode'] ?? '')));
    if ($ref !== '') {
        $rs = $pdo->prepare("SELECT id, commissionPct FROM `User` WHERE referralCode = ? AND isReseller = 1 LIMIT 1");
        $rs->execute([$ref]);
        $reseller = $rs->fetch();
        if ($reseller) {
            $pct = max(0, (int)$reseller['commissionPct']);
            $amt = (int)$o['totalCents'];
            $pdo->prepare(
                "INSERT INTO `Commission` (id, resellerId, orderId, amountCents, commissionCents, createdAt)
                 VALUES (?, ?, ?, ?, ?, ?)"
            )->execute([uid(), $reseller['id'], $oid, $amt, (int)round($amt * $pct / 100), $now]);
        }
    }
    push_event('order.paid', ['orderId' => $oid, 'reference' => $o['reference'] ?? '']);
}

function public_base(): string
{
    global $cfg;
    return rtrim(
        $cfg['base_url'] ?? ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? '')),
        '/'
    );
}

function make_access_token(string $uid): string
{
    global $pdo;
    $plain = 'dta_' . bin2hex(random_bytes(32));
    $pdo->prepare(
        "INSERT INTO AccessToken (id, userId, tokenHash, expiresAt, createdAt)
         VALUES (?, ?, ?, ?, ?)"
    )->execute([
        uid(),
        $uid,
        hash_token($plain),
        date('Y-m-d H:i:s.v', time() + 86400),
        nowms(),
    ]);
    return $plain;
}

function decrypt_transport(string $raw): array
{
    global $cfg;
    $key = (string)($cfg['transport_key'] ?? '');
    if (strlen($key) !== 32) {
        throw new RuntimeException('Transport key must be exactly 32 bytes');
    }
    $cipher = base64_decode(trim($raw), true);
    if ($cipher === false || $cipher === '') {
        throw new RuntimeException('Invalid transport body');
    }
    $plain = openssl_decrypt($cipher, 'AES-256-ECB', $key, OPENSSL_RAW_DATA);
    if ($plain === false) {
        throw new RuntimeException('Transport decrypt failed');
    }
    $plain = rtrim($plain, "\0");
    $d = json_decode($plain, true);
    if (!is_array($d)) {
        throw new RuntimeException('Invalid transport JSON');
    }
    $endpoint = basename(parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: '');
    $canonical = $endpoint . '|' . ($d['timestamp'] ?? '') . '|' . ($d['nonce'] ?? '') . '|' .
                 ($d['data'] ?? '') . '|' . ($d['udid'] ?? '') . '|' . ($d['key'] ?? '') . '|' .
                 ($d['bundle_id'] ?? '');
    $expected = hash_hmac('sha256', $canonical, $key);
    $sig = strtolower(trim((string)($d['request_signature'] ?? '')));
    if ($sig !== '' && !hash_equals($expected, $sig)) {
        throw new RuntimeException('Invalid request signature');
    }
    if (isset($d['timestamp']) && $d['timestamp'] !== '') {
        $timestamp = (float)$d['timestamp'];
        for ($i = 0; $i < 3 && $timestamp > 9999999999; $i++) $timestamp /= 1000;
        if ($timestamp <= 0 || abs(microtime(true) - $timestamp) > 600) {
            throw new RuntimeException('Request timestamp expired');
        }
    }
    $nonce = trim((string)($d['nonce'] ?? ''));
    if ($nonce !== '') {
        try {
            global $pdo;
            $pdo->exec(
                "CREATE TABLE IF NOT EXISTS `RequestNonce` (
                    nonce VARCHAR(64) PRIMARY KEY,
                    createdAt DATETIME NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );
            $pdo->prepare("DELETE FROM `RequestNonce` WHERE createdAt < DATE_SUB(NOW(), INTERVAL 10 MINUTE)")->execute();
            $pdo->prepare("INSERT INTO `RequestNonce` (nonce, createdAt) VALUES (?, NOW())")->execute([substr($nonce, 0, 64)]);
        } catch (Throwable $e) {
            if (str_contains($e->getMessage(), 'Duplicate') || (int)$e->getCode() === 23000) {
                throw new RuntimeException('Replay nonce');
            }
        }
    }
    return $d;
}

function transport_response(array $payload): never
{
    global $cfg;
    $key = (string)($cfg['transport_key'] ?? '');
    if (strlen($key) !== 32) {
        http_response_code(500);
        exit('Transport not configured');
    }
    $sessionKey = random_bytes(32);
    $iv = random_bytes(16);
    $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $cipher = openssl_encrypt($json, 'AES-256-CBC', $sessionKey, OPENSSL_RAW_DATA, $iv);
    if ($cipher === false) {
        http_response_code(500);
        exit('Response encryption failed');
    }
    $x1 = base64_encode($cipher);
    $secretB64 = base64_encode($sessionKey . $iv);
    $private = (string)($cfg['rsa_private_key'] ?? '');
    if (!$private || !openssl_private_encrypt($secretB64, $x2, $private, OPENSSL_PKCS1_PADDING)) {
        http_response_code(500);
        exit('RSA private key is not configured');
    }
    $x2 = base64_encode($x2);
    $ts = sprintf('%.6f', microtime(true));
    $x3 = '';
    $signed = $x1 . '|' . $x2 . '|' . $ts . '|' . $x3;
    if (!openssl_sign($signed, $sig, $private, OPENSSL_ALGO_SHA256)) {
        http_response_code(500);
        exit('RSA signature failed');
    }
    $env = ['x1' => $x1, 'x2' => $x2, 'x3' => $x3, 'timestamp' => $ts, 's' => base64_encode($sig)];
    $outer = openssl_encrypt(
        json_encode($env, JSON_UNESCAPED_SLASHES),
        'AES-256-ECB',
        $key,
        OPENSSL_RAW_DATA
    );
    if ($outer === false) {
        http_response_code(500);
        exit('Envelope encryption failed');
    }
    header('Content-Type: text/plain; charset=utf-8');
    echo base64_encode($outer);
    exit;
}

$uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

/* Health check — no auth */
if ($uri === '/health.php' || $uri === '/health') {
    header('Content-Type: application/json; charset=utf-8');
    try {
        $pdo->query('SELECT 1');
        echo json_encode(['status' => 'ok', 'service' => 'dta-cloud-platform', 'time' => gmdate('c')], JSON_UNESCAPED_SLASHES);
    } catch (Throwable $e) {
        http_response_code(500);
        echo json_encode(['status' => 'error']);
    }
    exit;
}

/* Short-link redirect */
if (preg_match('#^/s/([A-Za-z0-9_-]+)$#', $uri, $sm) || (isset($_GET['code']) && str_contains($uri, 'redirect'))) {
    $code = $sm[1] ?? trim((string)($_GET['code'] ?? ''));
    if ($code === '') {
        http_response_code(404);
        exit('Not found');
    }
    $s = $pdo->prepare("SELECT * FROM `ShortLink` WHERE code = ? AND status = 'ACTIVE' LIMIT 1");
    $s->execute([$code]);
    $l = $s->fetch();
    if (!$l || ($l['expiresAt'] && strtotime($l['expiresAt']) < time()) || ($l['oneTimeUse'] && $l['usedAt'])) {
        http_response_code(404);
        exit('Link unavailable');
    }
    if ($l['passwordHash']) {
        $p = $_POST['password'] ?? $_GET['password'] ?? '';
        if (!$p || !password_verify($p, $l['passwordHash'])) {
            echo '<!doctype html><meta charset="utf-8"><title>Protected link</title>';
            echo '<form method="post" style="max-width:360px;margin:15vh auto;font:16px system-ui;display:grid;gap:12px">';
            echo '<h2>Protected link</h2><input name="password" type="password" required placeholder="Password"><button>Continue</button></form>';
            exit;
        }
    }
    try {
        $pdo->prepare(
            "INSERT INTO `ShortLinkClick`
             (id, linkId, visitorHash, referrerCategory, deviceCategory, browser, operatingSystem, statusCode, clickedAt)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
        )->execute([
            uid(), $l['id'],
            hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '') . ($_SERVER['HTTP_USER_AGENT'] ?? '')),
            'direct', 'desktop', 'Unknown', 'Unknown', 302, nowms(),
        ]);
    } catch (Throwable $e) {
        error_log('shortlink click log failed: ' . $e->getMessage());
    }
    if ($l['oneTimeUse']) {
        $pdo->prepare("UPDATE `ShortLink` SET usedAt = ?, updatedAt = ? WHERE id = ?")
            ->execute([nowms(), nowms(), $l['id']]);
    }
    header('Location: ' . $l['targetUrl'], true, 302);
    exit;
}

$routeQ = trim((string)($_GET['route'] ?? ''));
$isV4 = str_starts_with($uri, '/v4/client/') || in_array($routeQ, ['package-v3','credential-v3','key-v3'], true);
$path = $isV4 ? $uri : preg_replace('#^/api(?=/|$)#', '', $uri);
$body = $isV4 ? null : body_json();

function ensure_udid_table(): void
{
    global $pdo;
    try {
        $pdo->exec(
            "CREATE TABLE IF NOT EXISTS `UdidEnrollment` (
                token VARCHAR(64) PRIMARY KEY,
                status VARCHAR(16) NOT NULL,
                udid VARCHAR(191) NULL,
                product VARCHAR(64) NULL,
                version VARCHAR(64) NULL,
                serial VARCHAR(64) NULL,
                imei VARCHAR(64) NULL,
                bundleId VARCHAR(191) NULL,
                ip VARCHAR(64) NULL,
                userAgent VARCHAR(255) NULL,
                createdAt DATETIME(3) NULL,
                capturedAt DATETIME(3) NULL,
                expiresAt DATETIME(3) NULL,
                KEY idx_udid (udid),
                KEY idx_status (status, createdAt)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        );
    } catch (Throwable $e) {
        error_log('ensure_udid_table: ' . $e->getMessage());
    }
}

function require_enrolled_udid(): bool
{
    global $cfg, $pdo;
    $private = dirname(__DIR__) . '/private';
    if (!is_dir($private)) $private = __DIR__ . '/private';
    $f = $private . '/udid-settings.php';
    if (is_file($f)) {
        try {
            $s = require $f;
            if (is_array($s) && array_key_exists('require', $s)) return (bool)$s['require'];
        } catch (Throwable $e) {}
    }
    if (array_key_exists('require_enrolled_udid', $cfg)) {
        return (bool)$cfg['require_enrolled_udid'];
    }
    return false;
}

function parse_udid_plist(string $raw): array
{
    $xml = extract_device_plist($raw);
    $out = [];
    foreach (['UDID', 'PRODUCT', 'VERSION', 'SERIAL', 'IMEI', 'ICCID'] as $k) {
        if (preg_match('/<key>' . preg_quote($k, '/') . '<\/key>\s*<string>([^<]*)<\/string>/i', $xml, $m)) {
            $out[strtolower($k)] = trim($m[1]);
        }
    }
    if (empty($out['udid']) && preg_match('/\b([0-9A-Fa-f]{8}-[0-9A-Fa-f]{16}|[0-9A-Fa-f]{40})\b/', $xml, $m)) {
        $out['udid'] = strtoupper($m[1]);
    }
    return $out;
}

function extract_device_plist(string $raw): string
{
    if (str_contains($raw, '<plist') || str_contains($raw, '<?xml')) {
        $start = strpos($raw, '<?xml');
        if ($start === false) $start = strpos($raw, '<plist');
        $chunk = substr($raw, (int)$start);
        $end = strrpos($chunk, '</plist>');
        return $end !== false ? substr($chunk, 0, $end + 8) : $chunk;
    }
    $dir = sys_get_temp_dir();
    $in = @tempnam($dir, 'p7i');
    $outf = @tempnam($dir, 'p7o');
    if ($in === false || $outf === false) return $raw;
    file_put_contents($in, $raw);
    $pem = $in . '.pem';
    file_put_contents($pem, "-----BEGIN PKCS7-----\n" . chunk_split(base64_encode($raw), 64, "\n") . "-----END PKCS7-----\n");
    $cmds = [
        'openssl cms -inform DER -verify -noverify -in ' . escapeshellarg($in) . ' -out ' . escapeshellarg($outf),
        'openssl smime -inform DER -verify -noverify -in ' . escapeshellarg($in) . ' -out ' . escapeshellarg($outf),
        'openssl smime -inform PEM -verify -noverify -in ' . escapeshellarg($pem) . ' -out ' . escapeshellarg($outf),
        'openssl cms -inform PEM -verify -noverify -in ' . escapeshellarg($pem) . ' -out ' . escapeshellarg($outf),
    ];
    $xml = '';
    foreach ($cmds as $cmd) {
        @exec($cmd . ' 2>/dev/null', $_, $code);
        $out = @file_get_contents($outf) ?: '';
        if ($out !== '' && (str_contains($out, 'UDID') || str_contains($out, '<plist'))) {
            $xml = $out;
            break;
        }
    }
    @unlink($in); @unlink($outf); @unlink($pem);
    if ($xml !== '') return $xml;
    if (preg_match('/UDID[\\x00-\\x20]{0,24}([0-9A-Fa-f]{8}-[0-9A-Fa-f]{16}|[0-9A-Fa-f]{40})/s', $raw, $m)) {
        $u = strtoupper($m[1]);
        return '<?xml version="1.0"?><plist><dict><key>UDID</key><string>' . $u . '</string></dict></plist>';
    }
    return $raw;
}

function udid_uuid(string $seed): string
{
    $b = substr(hash('sha1', $seed, true), 0, 16);
    $b[6] = chr((ord($b[6]) & 0x0f) | 0x50);
    $b[8] = chr((ord($b[8]) & 0x3f) | 0x80);
    $h = bin2hex($b);
    return sprintf('%s-%s-%s-%s-%s', substr($h,0,8), substr($h,8,4), substr($h,12,4), substr($h,16,4), substr($h,20,12));
}

function letsencrypt_chain_pem(): string
{
    return <<<PEM
-----BEGIN CERTIFICATE-----
MIIE2jCCAsKgAwIBAgIQTr0klH4k05SALYSlL9WzGTANBgkqhkiG9w0BAQsFADAu
MQswCQYDVQQGEwJVUzENMAsGA1UEChMESVNSRzEQMA4GA1UEAxMHUm9vdCBZUjAe
Fw0yNTA5MDMwMDAwMDBaFw0yODA5MDIyMzU5NTlaMDMxCzAJBgNVBAYTAlVTMRYw
FAYDVQQKEw1MZXQncyBFbmNyeXB0MQwwCgYDVQQDEwNZUjIwggEiMA0GCSqGSIb3
DQEBAQUAA4IBDwAwggEKAoIBAQDZ0LxwBppqh84luqMerV/eeL/fXQ7mLQQv1Lnp
WKZbyvGpx6wh6AfnslAnF6ewTkcHA+gSOoBvm3Dfm06AuGiF+KRut4fAcowqnAQQ
CW98+QPP/eOv/wug7Iyk4NkOxf2I6g2f55T6nJoOTLFcukeRq80JGQEYan+dPFr9
OGUgQK2hGKgNkW87pappsOAuUJcroYhRt5uUis4qaZireiseu32gzDJNBAiKtsvd
6HX4v25bpkRNcS/B/Gtc9kVbUpD+2PLPxdei3Tim55k4tfAEXwD2qyiPTxrTNq6l
N+AMr5g2c1dNqkOTwjxeV6L5lpP1rGiYvLnRaPlOqyZRPW+5AgMBAAGjge4wgesw
DgYDVR0PAQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMBMBIGA1UdEwEB/wQI
MAYBAf8CAQAwHQYDVR0OBBYEFEAVLSZ57TIgnt+ach3WMh+BDIEMMB8GA1UdIwQY
MBaAFN7nW2DQIm1AKH0/DQH+pLVStFGUMDIGCCsGAQUFBwEBBCYwJDAiBggrBgEF
BQcwAoYWaHR0cDovL3lyLmkubGVuY3Iub3JnLzATBgNVHSAEDDAKMAgGBmeBDAEC
ATAnBgNVHR8EIDAeMBygGqAYhhZodHRwOi8veXIuYy5sZW5jci5vcmcvMA0GCSqG
SIb3DQEBCwUAA4ICAQB0ZUQWZ9/Yn9COEpo+JfecMnB0h0vwDm/M66IqXqw3LoaL
mx9lZvRTeDIS67PUeI3yCA2W6PKRD0/FE/G57lOmS+Xy5AaaL00ICGOqjNcCaMWW
8o8nevHOd4i4lqgtznE/28QwlcdJyF8yBiWHpnyjhEpmNWJURgOCOg2xpwRMBCsj
MScqYPtOhBeuYQvSwAEeTML2Ukh6uGuX4E14q65Ja8cdjF5bAldnP1eE4FBaAwsZ
G2fOqqrKV03Y85Nw2btedP1AtliQuJZs/Jo/gXxXdc7LrH3McgnpnbTiAncX7yES
hP6kzQejllqMCIt52HOjxDGWafS7Xw+DKwqmH+Eqy8dcbOuag/1AYlQoKNVK3F5q
Hh6tEDiMqQcLIibGKteE6iHo4A/bIScbzrhXUYuism42ZYzmc48FMVIH3qy4L84E
TdAH2gtxw0PAhvRVXp8HP7wfngpzsN/8xOTpeRSbM4+Qbc56G6+Bifmv6sk1ieQb
NA3wJdl4DDUuQSV8hBgx6zoI1ZSGORprDFux7c6rhc77QZMSRrEgomBeklervEve
86ylWmZ3WWHV6RLMi8xNvjd71r4EPIGgY7BZU/VPBkq+uA7Gb6mbJnFgV43uh3xy
LRFgxIAphIukwTGSMZZR+AI+Qnp0BYTWovHXozOf3H8r6hozEoT02JHn0AeTfA==
-----END CERTIFICATE-----

-----BEGIN CERTIFICATE-----
MIIF9DCCA9ygAwIBAgIRAPJLbRf52a18scn+p4eCaZ8wDQYJKoZIhvcNAQELBQAw
TzELMAkGA1UEBhMCVVMxKTAnBgNVBAoTIEludGVybmV0IFNlY3VyaXR5IFJlc2Vh
cmNoIEdyb3VwMRUwEwYDVQQDEwxJU1JHIFJvb3QgWDEwHhcNMjYwNTEzMDAwMDAw
WhcNMzIwOTAyMjM1OTU5WjAuMQswCQYDVQQGEwJVUzENMAsGA1UEChMESVNSRzEQ
MA4GA1UEAxMHUm9vdCBZUjCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIB
ANvGJnN78CTJdWL3+eGfsLN5TrNBJs+VH9hRXqRbwxu9sGNiB0BD1fcOxbSUQCJI
M1xE13Db+5Cw1w0s0EBYsvuIP/6joF0w8cuImbgR1OGgYbSQ4OpzI+DG8SGuTlcE
873OCS+kh3srlo6vl43M5OJg4Aeo1sfHp6kTJDoIiFBNJAY+OKfX/FUvYKuhjT+n
o49lmqmupSBI5PkBQiqrEGtWU5uxU/cQWHGu8jSjFBznZqvbNPLMXMLFxCb3WTfr
JBXXjqvWG+v4bjzxjjeAtOlU7qarRDvNOyAuQYLln904M+faKx8hnLCpJ15ZqaEg
cNlY+9MMWcC5yvL2A2j3l9+2buggZX+dOE91zYmIdawTvSZuVvlbRrAlLxIB6pwM
BjneXCjYQ8+3BCCjssbSNpZU3hTcBDdhfAlEDlYr6pEatnMdmDT5BqnKC92bd0Eh
M1fbLHioLccLCuievT8ZkPhZrq7Mii7gNXAcUEAR8+lzYal+9zTg7C5DALyVOeG/
CqfRAMn1KSHCR0NSA6P8tn/mGRlnCct5rtVCLnVySVpU6H1qGg3DgTOuskf8eahT
MiYbI5ezPJmO5ertalskQ1utp74+eDy92PI4ftHKTbq9IWhH4YZKh3WnJEIt+oQv
lYZbY8tpEroKrFB6PFGzrJIDRyts4HqvuH52RFj2zv/BAgMBAAGjgeswgegwDgYD
VR0PAQH/BAQDAgEGMBMGA1UdJQQMMAoGCCsGAQUFBwMBMA8GA1UdEwEB/wQFMAMB
Af8wHQYDVR0OBBYEFN7nW2DQIm1AKH0/DQH+pLVStFGUMB8GA1UdIwQYMBaAFHm0
WeZ7tuXkAXOACIjIGlj26ZtuMDIGCCsGAQUFBwEBBCYwJDAiBggrBgEFBQcwAoYW
aHR0cDovL3gxLmkubGVuY3Iub3JnLzATBgNVHSAEDDAKMAgGBmeBDAECATAnBgNV
HR8EIDAeMBygGqAYhhZodHRwOi8veDEuYy5sZW5jci5vcmcvMA0GCSqGSIb3DQEB
CwUAA4ICAQA8spSI95KKfn2W6GMmDpHBJSPaLbsS3W93cijJCRCYAc1fsJgL1FIL
7C0C9ecPOdcwB2fi0Dk2p94j9iTJCxmt5CFSKLRWwnXT2MMSXexVxqoVB79BdWPx
VXETkVme/qYSAuKVHh5Ps+5BixgmwS1JkjSAc+MfrUbNssVEEnH0aEiAh+rotXAV
JSP/Ye7LJPEwD9DWG72vVWbhAcuOf5OLjz57Ctk7MgQHynZ7+PlHJtajroCaIbtC
r6tcZZaAwUQm+jQyeWdV+2hv9deOYFmKeQyjjcSrN5Nadrw+L9DZJLbA1HqeNvLh
BgqpP0fvJq2N6EtD574N6eMI7uMsJTnji2UDz9el5XLSv9fqJMuDQtYVb2oTNoKp
oUqhxPVC0aq4eG5MESaIdn8b5ZGSSeAJLMHXljEdlNza+ncfkviXk1POLnnFdvx8
/gk6M374WbLWFXw8N141B/Rl/tINGfl1TxOIiqtiMYkL02RSGb1kq34BL9NPP27z
RGMuHGnzS3hFIrRTfKxrzUZ9RzQWzEG3K6fJ3r2nqSltkeytis9DIBoFY9VmVyjL
M71DMi+y1+TRSJVClEMwvA4yL++7q9XZx5r5wBRWB4kQTKH5qyoZnDw7iiuh1lID
yDFx8r7i9vIJU5HS3moZLkYWAOilMaV9N56A9Bgb6dNcHkvg3NoaYA==
-----END CERTIFICATE-----

PEM;
}

function profile_signer_paths(): array
{
    $priv = dirname(__DIR__) . '/private';
    if (!is_dir($priv)) $priv = __DIR__ . '/private';
    $home = dirname($priv);
    $cert = $key = $chain = null;
    foreach (['ssl.crt','cert.pem','shopdta.site.crt'] as $n) {
        if (is_readable($priv . '/' . $n) && filesize($priv . '/' . $n) > 80) { $cert = $priv . '/' . $n; break; }
    }
    foreach (['ssl.key','key.pem','shopdta.site.key'] as $n) {
        if (is_readable($priv . '/' . $n) && filesize($priv . '/' . $n) > 80) { $key = $priv . '/' . $n; break; }
    }
    foreach (['cabundle.crt','chain.pem','ca-bundle.crt'] as $n) {
        if (is_readable($priv . '/' . $n)) { $chain = $priv . '/' . $n; break; }
    }
    if (!$cert || !$key) {
        $certs = array_merge(glob($home . '/ssl/certs/*') ?: [], glob($home . '/ssl/certs/*.*') ?: []);
        $keys  = array_merge(glob($home . '/ssl/keys/*') ?: [], glob($home . '/ssl/keys/*.*') ?: []);
        $cabs  = array_merge(glob($home . '/ssl/cabs/*') ?: [], glob($home . '/ssl/cabs/*.*') ?: []);
        $best = -1; $pickC = $pickK = $pickB = null;
        foreach (array_unique($certs) as $c) {
            if (!is_readable($c) || filesize($c) < 80) continue;
            $raw = @file_get_contents($c);
            $p = $raw ? @openssl_x509_parse($raw) : false;
            if (!$p) continue;
            $names = [strtolower((string)($p['subject']['CN'] ?? ''))];
            $san = (string)($p['extensions']['subjectAltName'] ?? '');
            foreach (explode(',', $san) as $part) {
                if (preg_match('/DNS:([^\s,]+)/i', $part, $mm)) $names[] = strtolower(trim($mm[1]));
            }
            $score = 0;
            if (in_array('shopdta.site', $names, true)) $score += 80;
            if (($p['subject']['CN'] ?? '') === 'shopdta.site') $score += 40;
            $cn = strtolower((string)($p['subject']['CN'] ?? ''));
            if ($score > $best) { $best = $score; $pickC = $c; }
        }
        $pickK = null;
        if ($pickC) {
            $base = pathinfo($pickC, PATHINFO_FILENAME);
            foreach ($keys as $k) {
                if (pathinfo($k, PATHINFO_FILENAME) === $base) { $pickK = $k; break; }
            }
            if (!$pickK && $keys) $pickK = $keys[0];
        }
        if ($cabs) $pickB = $cabs[0];
        if ($pickC && $pickK && $best >= 50) { $cert = $pickC; $key = $pickK; $chain = $pickB; }
    }
    if ($cert && $key) return [$cert, $key, $chain];

    $cert = $priv . '/profile-sign.crt';
    $key = $priv . '/profile-sign.key';
    if (is_readable($cert) && is_readable($key)) return [$cert, $key, null];

    if (!is_dir($priv)) @mkdir($priv, 0700, true);
    $dn = ['countryName'=>'VN','organizationName'=>'ShopDTA','commonName'=>'shopdta.site'];
    $pk = openssl_pkey_new(['private_key_bits'=>2048,'private_key_type'=>OPENSSL_KEYTYPE_RSA]);
    if ($pk === false) return [null, null, null];
    $csr = openssl_csr_new($dn, $pk, ['digest_alg'=>'sha256']);
    $x509 = openssl_csr_sign($csr, null, $pk, 3650, ['digest_alg'=>'sha256']);
    if ($x509 === false) return [null, null, null];
    openssl_x509_export($x509, $certPem);
    openssl_pkey_export($pk, $keyPem);
    @file_put_contents($cert, $certPem);
    @file_put_contents($key, $keyPem);
    @chmod($cert, 0600); @chmod($key, 0600);
    return is_readable($cert) && is_readable($key) ? [$cert, $key, null] : [null, null, null];
}

function sign_mobileconfig(string $xml): string
{
    [$certPath, $keyPath, $chainPath] = profile_signer_paths();
    if (!$certPath || !$keyPath) return $xml;
    $in = tempnam(sys_get_temp_dir(), 'mc');
    $out = $in . '.der';
    file_put_contents($in, $xml);
    $chainFile = $chainPath;
    $leaf = (string)file_get_contents($certPath);
    $leafMeta = @openssl_x509_parse($leaf) ?: [];
    $issuerCn = (string)($leafMeta['issuer']['CN'] ?? '');
    $isLetsEncrypt = (bool)preg_match('/YR2|Let.s Encrypt|ISRG/i', $issuerCn);
    if ($isLetsEncrypt && (!$chainFile || !is_readable($chainFile)) && substr_count($leaf, 'BEGIN CERTIFICATE') < 2) {
        $chainFile = $in . '.chain';
        file_put_contents($chainFile, letsencrypt_chain_pem());
    }
    $cmd = 'openssl smime -sign -signer ' . escapeshellarg($certPath)
        . ' -inkey ' . escapeshellarg($keyPath)
        . ($chainFile && is_readable($chainFile) ? ' -certfile ' . escapeshellarg($chainFile) : '')
        . ' -nodetach -outform der -in ' . escapeshellarg($in) . ' -out ' . escapeshellarg($out);
    @exec($cmd . ' 2>/dev/null');
    $der = is_file($out) ? (string)file_get_contents($out) : '';
    @unlink($in); @unlink($out);
    if ($chainFile && str_starts_with($chainFile, sys_get_temp_dir())) @unlink($chainFile);
    return (strlen($der) > 64) ? $der : $xml;
}

function emit_mobileconfig(string $xml): never
{
    while (ob_get_level() > 0) { @ob_end_clean(); }
    $body = sign_mobileconfig($xml);
    header_remove('Set-Cookie');
    header('Content-Type: application/x-apple-aspen-config');
    header('Cache-Control: no-store');
    header('Content-Length: ' . strlen($body));
    echo $body;
    exit;
}

function enrollment_row(string $token): ?array
{
    global $pdo;
    ensure_udid_table();
    $s = $pdo->prepare("SELECT * FROM `UdidEnrollment` WHERE token = ? LIMIT 1");
    $s->execute([$token]);
    return $s->fetch() ?: null;
}

/** Resolve UDID from enroll token or already-captured UDID. */
function resolve_enrolled_udid(string $udid, string $enrollToken = ''): ?string
{
    global $pdo;
    ensure_udid_table();
    if ($enrollToken !== '') {
        $r = enrollment_row($enrollToken);
        if ($r && ($r['status'] ?? '') === 'CAPTURED' && !empty($r['udid'])) {
            return (string)$r['udid'];
        }
        return null;
    }
    if ($udid === '') return null;
    $s = $pdo->prepare("SELECT udid FROM `UdidEnrollment` WHERE udid = ? AND status = 'CAPTURED' ORDER BY capturedAt DESC LIMIT 1");
    $s->execute([$udid]);
    $hit = $s->fetchColumn();
    return $hit ? (string)$hit : null;
}

function udid_profile_xml(string $token, string $callback): string
{
    $uuid = strtoupper(udid_uuid('req-' . $token));
    $cb = htmlspecialchars($callback, ENT_XML1 | ENT_QUOTES);
    return <<<XML
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
<key>PayloadContent</key>
<dict>
<key>DeviceAttributes</key>
<array>
<string>UDID</string>
<string>DEVICE_NAME</string>
<string>VERSION</string>
<string>PRODUCT</string>
<string>MAC_ADDRESS_EN0</string>
<string>IMEI</string>
<string>ICCID</string>
</array>
<key>URL</key>
<string>{$cb}</string>
</dict>
<key>PayloadDescription</key>
<string>Cài cấu hình để gửi UDID về ShopDTA. Xóa hồ sơ sau khi app đã nhận.</string>
<key>PayloadDisplayName</key>
<string>Lấy UDID Thiết Bị</string>
<key>PayloadIdentifier</key>
<string>shopdta.site</string>
<key>PayloadOrganization</key>
<string>ShopDTA</string>
<key>PayloadType</key>
<string>Profile Service</string>
<key>PayloadUUID</key>
<string>{$uuid}</string>
<key>PayloadVersion</key>
<integer>1</integer>
</dict>
</plist>
XML;
}

function udid_ack_profile(string $token, string $udid): string
{
    $uuid = udid_uuid('ack-' . $token);
    $pu = udid_uuid('acc-' . $token);
    $id = 'site.shopdta.udid.ack.' . $token;
    return <<<XML
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>PayloadContent</key>
    <array>
        <dict>
            <key>PayloadDisplayName</key>
            <string>Device</string>
            <key>PayloadIdentifier</key>
            <string>site.shopdta.udid.done.{$token}</string>
            <key>PayloadOrganization</key>
            <string>ShopDTA</string>
            <key>PayloadType</key>
            <string>com.apple.applicationaccess</string>
            <key>PayloadUUID</key>
            <string>{$pu}</string>
            <key>PayloadVersion</key>
            <integer>1</integer>
            <key>allowAppInstallation</key>
            <true/>
        </dict>
    </array>
    <key>PayloadDisplayName</key>
    <string>ShopDTA UDID</string>
    <key>PayloadDescription</key>
    <string>UDID received. You can remove this profile.</string>
    <key>PayloadIdentifier</key>
    <string>{$id}</string>
    <key>PayloadOrganization</key>
    <string>ShopDTA</string>
    <key>PayloadRemovalDisallowed</key>
    <false/>
    <key>PayloadType</key>
    <string>Configuration</string>
    <key>PayloadUUID</key>
    <string>{$uuid}</string>
    <key>PayloadVersion</key>
    <integer>1</integer>
</dict>
</plist>
XML;
}

/* ---------- UDID enrollment (public, before login) ---------- */
ensure_udid_table();

if (preg_match('#^/udid/enroll$#', $path) && ($method === 'POST' || $method === 'GET')) {
    $bundle = strtolower(trim((string)(($body['bundleId'] ?? $_GET['bundle'] ?? ''))));
    $token = bin2hex(random_bytes(16));
    $now = nowms();
    $exp = date('Y-m-d H:i:s', time() + 15 * 60);
    $pdo->prepare(
        "INSERT INTO `UdidEnrollment` (token, status, bundleId, ip, userAgent, createdAt, expiresAt)
         VALUES (?, 'PENDING', ?, ?, ?, ?, ?)"
    )->execute([
        $token,
        $bundle !== '' ? $bundle : null,
        $_SERVER['REMOTE_ADDR'] ?? '',
        substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255),
        $now,
        $exp,
    ]);
    $base = public_base();
    json_out([
        'token' => $token,
        'status' => 'PENDING',
        'profileUrl' => $base . '/udid/profile/' . $token . '.mobileconfig',
        'statusUrl' => $base . '/udid/status/' . $token,
        'doneUrl' => $base . '/udid?token=' . $token,
        'expiresAt' => $exp,
        'instruction' => 'Tải cấu hình → Cài trong Cài đặt → quay lại app. Server nhận UDID thật rồi mới cho nhập key.',
    ], 201);
}

if (preg_match('#^/udid/profile/([A-Fa-f0-9]+)#', $path, $m) && $method === 'GET') {
    $row = enrollment_row($m[1]);
    if (!$row) {
        http_response_code(404);
        exit('Enrollment not found');
    }
    $callback = public_base() . '/udid/endpoint?t=' . $m[1];
    emit_mobileconfig(udid_profile_xml($m[1], $callback));
}

if (($path === '/udid/endpoint' || preg_match('#^/udid/callback/([A-Fa-f0-9]+)#', $path, $m)) && ($method === 'POST' || $method === 'PUT')) {
    $token = preg_replace('/[^A-Fa-f0-9]/', '', (string)($_GET['t'] ?? ($m[1] ?? '')));
    $row = enrollment_row($token);
    $raw = file_get_contents('php://input') ?: '';
    error_log('UDID callback token=' . $token . ' bytes=' . strlen($raw) . ' ct=' . ($_SERVER['CONTENT_TYPE'] ?? ''));
    @file_put_contents(dirname(__DIR__).'/private/udid-callback.log', date('c').' token='.$token.' bytes='.strlen($raw).' ct='.($_SERVER['CONTENT_TYPE'] ?? '').PHP_EOL, FILE_APPEND);
    $info = parse_udid_plist($raw);
    $udid = strtoupper(trim((string)($info['udid'] ?? '')));
    if ($row && $udid !== '') {
        $pdo->prepare(
            "UPDATE `UdidEnrollment`
             SET status = 'CAPTURED', udid = ?, product = ?, version = ?, serial = ?, imei = ?,
                 capturedAt = ?, ip = ?
             WHERE token = ? AND status IN ('PENDING','CAPTURED')"
        )->execute([
            $udid,
            $info['product'] ?? null,
            $info['version'] ?? null,
            $info['serial'] ?? null,
            $info['imei'] ?? null,
            nowms(),
            $_SERVER['REMOTE_ADDR'] ?? '',
            $token,
        ]);
        try { push_event('udid.captured', ['token' => $token, 'udid' => $udid, 'product' => $info['product'] ?? '']); } catch (Throwable $e) {}
    } else {
        error_log('UDID callback parse miss token=' . $token . ' udid=' . $udid);
    }
    /* muacert.com style: 301 to a page with UDID — do NOT return another mobileconfig. */
    $loc = '/udid?token=' . rawurlencode($token) . '&captured=1';
    if ($udid !== '') $loc .= '&udid=' . rawurlencode($udid);
    while (ob_get_level() > 0) { @ob_end_clean(); }
    header_remove('Set-Cookie');
    header('Content-Type: text/plain; charset=utf-8');
    header('Location: ' . $loc, true, 301);
    echo 'Moved Permanently. Redirecting to ' . $loc;
    exit;
}

if (preg_match('#^/udid/status/([A-Fa-f0-9]+)#', $path) && $method === 'GET') {
    $row = enrollment_row($m[1]);
    if (!$row) json_out(['error' => 'NOT_FOUND'], 404);
    if (($row['status'] ?? '') === 'PENDING' && !empty($row['expiresAt']) && strtotime((string)$row['expiresAt']) < time()) {
        $pdo->prepare("UPDATE `UdidEnrollment` SET status = 'EXPIRED' WHERE token = ? AND status = 'PENDING'")->execute([$m[1]]);
        $row['status'] = 'EXPIRED';
    }
    json_out([
        'token' => $row['token'],
        'status' => $row['status'],
        'udid' => $row['status'] === 'CAPTURED' ? $row['udid'] : null,
        'product' => $row['product'],
        'version' => $row['version'],
        'capturedAt' => $row['capturedAt'],
        'ready' => $row['status'] === 'CAPTURED',
    ]);
}

if (($path === '/udid' || $path === '/udid/done') && $method === 'GET') {
    $token = preg_replace('/[^A-Fa-f0-9]/', '', (string)($_GET['token'] ?? ''));
    if ($token === '') {
        $token = bin2hex(random_bytes(16));
        $now = nowms();
        $pdo->prepare(
            "INSERT INTO `UdidEnrollment` (token, status, ip, userAgent, createdAt, expiresAt)
             VALUES (?, 'PENDING', ?, ?, ?, ?)"
        )->execute([
            $token,
            $_SERVER['REMOTE_ADDR'] ?? '',
            substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255),
            $now,
            date('Y-m-d H:i:s', time() + 15 * 60),
        ]);
        header('Location: ' . public_base() . '/udid?token=' . $token, true, 302);
        exit;
    }
    $row = enrollment_row($token);
    if (!$row) {
        http_response_code(404);
        echo 'Session hết hạn. Mở lại từ app.';
        exit;
    }
    if (($row['status'] ?? '') === 'PENDING' && !empty($row['expiresAt']) && strtotime((string)$row['expiresAt']) < time()) {
        $row['status'] = 'EXPIRED';
    }
    $ready = ($row['status'] ?? '') === 'CAPTURED';
    $udid = $ready ? (string)$row['udid'] : '';
    $product = htmlspecialchars((string)($row['product'] ?? ''), ENT_QUOTES);
    $profile = htmlspecialchars(public_base() . '/udid/profile/' . $token . '.mobileconfig', ENT_QUOTES);
    $statusUrl = htmlspecialchars(public_base() . '/udid/status/' . $token, ENT_QUOTES);
    $udidH = htmlspecialchars($udid, ENT_QUOTES);
    $step = $ready ? 3 : 1;
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="vi"><head><meta charset="utf-8">'
        . '<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">'
        . '<meta name="theme-color" content="#070706">'
        . '<title>' . ($ready ? 'Đã nhận UDID' : 'Lấy UDID iPhone') . '</title>'
        . '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap">'
        . '<style>'
        . 'body{margin:0;min-height:100dvh;background:#0c0c0b;color:#f7f4ee;font-family:"Be Vietnam Pro",system-ui,sans-serif}'
        . '.wrap{max-width:420px;margin:0 auto;padding:28px 20px 48px}'
        . '.k{font-size:12px;letter-spacing:.16em;text-transform:uppercase;color:#a39e92}'
        . 'h1{font-size:28px;margin:10px 0 8px;letter-spacing:-.02em}'
        . 'p{color:#c9c3b6;line-height:1.6}'
        . '.card{background:#171614;border:1px solid rgb(247 244 238 / .16);border-radius:16px;padding:18px;margin-top:18px}'
        . '.step{display:flex;gap:12px;padding:12px 0;border-top:1px solid rgb(247 244 238 / .12)}'
        . '.n{width:28px;height:28px;border-radius:999px;display:grid;place-items:center;background:#22211e;color:#d7c7a8;font-size:12px;flex:none}'
        . '.n.on{background:#f0e7d6;color:#161513}'
        . '.btn{display:block;text-align:center;background:#f0e7d6;color:#161513;border-radius:12px;padding:14px;font-weight:600;text-decoration:none;margin-top:16px}'
        . '.ghost{display:block;text-align:center;color:#a39e92;margin-top:12px;font-size:14px}'
        . '.mono{font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:13px;word-break:break-all;color:#d7c7a8}'
        . '.ok{color:#9dcc8f}'
        . '</style></head><body><div class="wrap">'
        . '<p class="k">ShopDTA · cấu hình iPhone</p>'
        . '<h1>' . ($ready ? 'Đã nhận UDID' : 'Lấy UDID thật') . '</h1>'
        . '<p>' . ($ready
            ? 'Máy đã gửi UDID về server. Quay lại app để nhập key — key sẽ gắn đúng máy này.'
            : 'Bấm tải cấu hình, cài trong Cài đặt, rồi Safari sẽ nhảy về trang này.') . '</p>'
        . '<div class="card">'
        . '<div class="step"><div class="n' . ($step >= 1 ? ' on' : '') . '">1</div><div><b>Tải cấu hình</b><p style="margin:4px 0 0">File .mobileconfig — ShopDTA chỉ lấy UDID / model.</p></div></div>'
        . '<div class="step"><div class="n' . ($step >= 2 ? ' on' : '') . '">2</div><div><b>Cài trong Cài đặt</b><p style="margin:4px 0 0">Cài đặt → Cấu hình đã tải → Cài đặt. Cho phép khi iOS hỏi.</p></div></div>'
        . '<div class="step"><div class="n' . ($ready ? ' on' : '') . '">3</div><div><b>Đã nhận UDID</b><p style="margin:4px 0 0">'
        . ($ready ? '<span class="ok">Server đã gắn session.</span>' : 'Đợi iPhone gửi xong, trang tự cập nhật.') . '</p></div></div>'
        . ($ready
            ? '<p class="mono" style="margin-top:14px">' . $udidH . ($product !== '' ? '<br>' . $product : '') . '</p>'
              . '<a class="btn" href="#" id="copyU">Sao chép UDID</a>'
              . '<p class="ghost">Xóa hồ sơ ShopDTA trong Cài đặt → VPN.</p>'
            : '<a class="btn" href="' . $profile . '">Tải cấu hình</a>'
              . '<p class="ghost">Không đóng Safari sau khi cài.</p>')
        . '</div></div>'
        . ($ready
            ? '<script>document.getElementById("copyU").addEventListener("click",function(e){e.preventDefault();var u=' . json_encode($udid) . ';if(navigator.clipboard)navigator.clipboard.writeText(u);else{var t=document.createElement("textarea");t.value=u;document.body.appendChild(t);t.select();document.execCommand("copy");t.remove();}this.textContent="Đã sao chép - mở lại game";});</script>'
            : '<script>const u=' . json_encode($statusUrl) . ';async function tick(){try{const r=await fetch(u);const j=await r.json();if(j.ready) location.replace(location.pathname+"?token=' . htmlspecialchars($token, ENT_QUOTES) . '&captured=1");}catch(e){}setTimeout(tick,2000);}tick();</script>')
        . '</body></html>';
    exit;
}

/* ---------- helpers ---------- */

function row_user(string $id): ?array
{
    global $pdo;
    $s = $pdo->prepare(
        "SELECT u.id, u.email, u.name, u.status, u.lastLoginAt, u.createdAt, r.name AS roleName
         FROM `User` u JOIN `Role` r ON r.id = u.roleId
         WHERE u.id = ? LIMIT 1"
    );
    $s->execute([$id]);
    return $s->fetch() ?: null;
}

function public_user(array $u): array
{
    return [
        'id'     => $u['id'],
        'email'  => $u['email'],
        'name'   => $u['name'],
        'status' => $u['status'] ?? 'ACTIVE',
        'role'   => ['name' => $u['roleName'] ?? 'CUSTOMER'],
        'roleName' => $u['roleName'] ?? 'CUSTOMER',
        'referralCode' => $u['referralCode'] ?? null,
        'commissionPct' => (int)($u['commissionPct'] ?? 0),
        'isReseller' => (int)($u['isReseller'] ?? 0),
        'unbindCountWeek' => (int)($u['unbindCountWeek'] ?? 0),
    ];
}

function ensure_wallet(string $uid): array
{
    global $pdo;
    $s = $pdo->prepare("SELECT * FROM `Wallet` WHERE userId = ? LIMIT 1");
    $s->execute([$uid]);
    $w = $s->fetch();
    if ($w) {
        return $w;
    }
    $w = [
        'id'           => uid(),
        'userId'       => $uid,
        'balanceCents' => 0,
        'currency'     => 'USD',
        'updatedAt'    => nowms(),
    ];
    $pdo->prepare(
        "INSERT INTO `Wallet` (id, userId, balanceCents, currency, updatedAt)
         VALUES (?, ?, ?, ?, ?)"
    )->execute(array_values($w));
    return $w;
}

function package_row(string $id): ?array
{
    global $pdo;
    $s = $pdo->prepare(
        "SELECT p.*, pr.name AS productName, pr.slug AS productSlug
         FROM `Package` p
         LEFT JOIN `Product` pr ON pr.id = p.productId
         WHERE p.id = ? LIMIT 1"
    );
    $s->execute([$id]);
    return $s->fetch() ?: null;
}

function license_row(string $key): ?array
{
    global $pdo;
    $s = $pdo->prepare(
        "SELECT l.*,
                p.name AS packageName, p.description AS packageDescription,
                p.durationDays, p.licenseType AS packageLicenseType,
                p.maxDevices AS packageMaxDevices, p.bundleId AS packageBundleId,
                pr.name AS productName
         FROM `License` l
         JOIN `Package` p ON p.id = l.packageId
         LEFT JOIN `Product` pr ON pr.id = p.productId
         WHERE l.`key` = ? LIMIT 1"
    );
    $s->execute([$key]);
    return $s->fetch() ?: null;
}

function client_common(array $d): array
{
    global $pdo;
    $bundle = strtolower(trim((string)($d['bundle_id'] ?? '')));
    $clientName = trim((string)($d['package_name'] ?? $d['packageName'] ?? ''));
    $clientVer = trim((string)($d['app_version'] ?? ''));

    // Prefer exact bundle match, then generic (NULL bundleId)
    $s = $pdo->prepare(
        "SELECT p.*, pr.name AS productName
         FROM `Package` p
         LEFT JOIN `Product` pr ON pr.id = p.productId
         WHERE p.isActive = 1 AND (p.bundleId = ? OR p.bundleId IS NULL OR p.bundleId = '')
         ORDER BY (p.bundleId IS NULL OR p.bundleId = ''), p.updatedAt DESC, p.createdAt DESC
         LIMIT 1"
    );
    $s->execute([$bundle !== '' ? $bundle : '__none__']);
    $p = $s->fetch() ?: null;

    // Auto-create product + package when app sends a new bundle_id
    if (!$p && $bundle !== '' && valid_bundle($bundle)) {
        $now = nowms();
        // product
        $prodId = uid();
        $slug = preg_replace('/[^a-z0-9]+/', '-', $bundle) ?: 'app';
        try {
            $pdo->prepare(
                "INSERT INTO `Product` (id, name, slug, description, status, imageUrl, createdAt, updatedAt)
                 VALUES (?, ?, ?, ?, 'PUBLISHED', NULL, ?, ?)"
            )->execute([$prodId, $clientName !== '' ? $clientName : $bundle, $slug, 'Auto-created from client bundle ' . $bundle, $now, $now]);
        } catch (Throwable $e) {
            $ex = $pdo->prepare("SELECT id FROM `Product` WHERE slug = ? LIMIT 1");
            $ex->execute([$slug]);
            $found = $ex->fetchColumn();
            if ($found) {
                $prodId = $found;
            } else {
                $any = $pdo->query("SELECT id FROM `Product` ORDER BY createdAt ASC LIMIT 1")->fetchColumn();
                if ($any) {
                    $prodId = $any;
                } else {
                    // last resort: new id without unique slug collision
                    $prodId = uid();
                    $pdo->prepare(
                        "INSERT INTO `Product` (id, name, slug, description, status, imageUrl, createdAt, updatedAt)
                         VALUES (?, ?, ?, ?, 'PUBLISHED', NULL, ?, ?)"
                    )->execute([$prodId, $bundle, $slug . '-' . substr($prodId, 0, 6), 'Auto-created', $now, $now]);
                }
            }
        }
        $pkgId = uid();
        $pdo->prepare(
            "INSERT INTO `Package`
             (id, productId, name, description, priceCents, durationDays, licenseType,
              maxDevices, bundleId, requestQuota, isActive, version, createdAt, updatedAt)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, 1, ?, ?, ?)"
        )->execute([
            $pkgId,
            $prodId,
            $clientName !== '' ? $clientName : ('Package ' . $bundle),
            'Auto-created for bundle ' . $bundle,
            0,
            30,
            'TIME_BASED',
            1,
            $bundle,
            $clientVer !== '' ? $clientVer : '1.0.0',
            $now,
            $now,
        ]);
        $s = $pdo->prepare(
            "SELECT p.*, pr.name AS productName
             FROM `Package` p
             LEFT JOIN `Product` pr ON pr.id = p.productId
             WHERE p.id = ? LIMIT 1"
        );
        $s->execute([$pkgId]);
        $p = $s->fetch() ?: null;
    }

    return ['package' => $p, 'bundle' => $bundle];
}

function ensure_client_log_table(): void
{
    global $pdo;
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        $pdo->exec(
            "CREATE TABLE IF NOT EXISTS `ClientRequestLog` (
              `id` VARCHAR(191) NOT NULL,
              `endpoint` VARCHAR(64) NOT NULL,
              `bundleId` VARCHAR(191) NULL,
              `udid` VARCHAR(191) NULL,
              `deviceCode` VARCHAR(191) NULL,
              `licenseKey` VARCHAR(191) NULL,
              `statusCode` INT NOT NULL,
              `resultCode` INT NULL,
              `latencyMs` INT NOT NULL,
              `ipAddress` VARCHAR(64) NOT NULL,
              `userAgent` VARCHAR(255) NULL,
              `requestJson` TEXT NULL,
              `responseSummary` VARCHAR(255) NULL,
              `errorMessage` TEXT NULL,
              `createdAt` DATETIME(3) NOT NULL,
              PRIMARY KEY (`id`),
              KEY `idx_crl_created` (`createdAt`),
              KEY `idx_crl_endpoint` (`endpoint`,`createdAt`),
              KEY `idx_crl_bundle` (`bundleId`,`createdAt`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );
    } catch (Throwable $e) {
        error_log('ensure_client_log_table: ' . $e->getMessage());
    }
}

/** @param array<string,mixed>|null $detail */
function client_log(string $path, int $status, float $start, ?array $detail = null): void
{
    global $pdo;
    $latency = (int)round((microtime(true) - $start) * 1000);
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $ua = substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255);
    $endpoint = basename(parse_url($path, PHP_URL_PATH) ?: $path);

    try {
        $pdo->prepare(
            "INSERT INTO `ApiLog`
             (id, apiKeyId, method, path, statusCode, latencyMs, ipAddress, errorMessage, createdAt)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
        )->execute([
            uid(), null, 'POST', $path, $status, $latency, $ip,
            $detail['error'] ?? ($detail['summary'] ?? null),
            nowms(),
        ]);
    } catch (Throwable $e) {
        error_log('ApiLog insert failed: ' . $e->getMessage());
    }

    try {
        ensure_client_log_table();
        $reqJson = null;
        if (isset($detail['request']) && is_array($detail['request'])) {
            // redact nothing critical for admin debugging; truncate
            $reqJson = substr(json_encode($detail['request'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: '', 0, 8000);
        }
        $pdo->prepare(
            "INSERT INTO `ClientRequestLog`
             (id, endpoint, bundleId, udid, deviceCode, licenseKey, statusCode, resultCode,
              latencyMs, ipAddress, userAgent, requestJson, responseSummary, errorMessage, createdAt)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        )->execute([
            uid(),
            $endpoint,
            $detail['bundle_id'] ?? null,
            $detail['udid'] ?? null,
            $detail['device_code'] ?? null,
            $detail['key'] ?? null,
            $status,
            isset($detail['result_code']) ? (int)$detail['result_code'] : null,
            $latency,
            $ip,
            $ua,
            $reqJson,
            isset($detail['summary']) ? substr((string)$detail['summary'], 0, 255) : null,
            $detail['error'] ?? null,
            nowms(),
        ]);
    } catch (Throwable $e) {
        error_log('ClientRequestLog insert failed: ' . $e->getMessage());
    }
}

/* ---------- Native iOS client endpoints (AES-256-ECB + HMAC + RSA) ---------- */

if ($isV4) {
    require __DIR__ . '/v4-client.php';
    exit;
}

/* ---------- SePay webhook (public) ---------- */
if (($path === '/webhooks/sepay' || $uri === '/api/webhooks/sepay' || $uri === '/webhooks/sepay') && $method === 'POST') {
    $hdr = (string)($_SERVER['HTTP_AUTHORIZATION'] ?? '');
    $tok = '';
    if (preg_match('/Apikey\s+(.+)$/i', $hdr, $mm)) {
        $tok = trim($mm[1]);
    } elseif (preg_match('/Bearer\s+(.+)$/i', $hdr, $mm)) {
        $tok = trim($mm[1]);
    }
    $expected = sepay_token();
    if ($expected === '' || !hash_equals($expected, $tok)) {
        json_out(['error' => 'UNAUTHORIZED'], 401);
    }
    $payload = $body ?: body_json();
    $content = (string)($payload['content'] ?? $payload['description'] ?? '');
    $amount = (int)($payload['transferAmount'] ?? $payload['amount'] ?? 0);
    $type = strtolower((string)($payload['transferType'] ?? 'in'));
    if ($type !== '' && $type !== 'in') {
        json_out(['ok' => true, 'ignored' => 'not inbound']);
    }
    $s = $pdo->query("SELECT * FROM `Order` WHERE status = 'PENDING' ORDER BY createdAt DESC LIMIT 200");
    $hit = null;
    foreach ($s->fetchAll() as $o) {
        $ref = (string)($o['reference'] ?? '');
        if ($ref !== '' && stripos($content, $ref) !== false) {
            if ($amount > 0 && $amount + 1 < (int)$o['totalCents']) {
                continue;
            }
            $hit = $o;
            break;
        }
    }
    if (!$hit) {
        json_out(['ok' => true, 'matched' => false]);
    }
    $pdo->beginTransaction();
    try {
        fulfill_paid_order($hit['id']);
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        json_out(['error' => $e->getMessage()], 500);
    }
    json_out(['ok' => true, 'matched' => true, 'orderId' => $hit['id']]);
}

/* ---------- Auth (public) ---------- */

if ($path === '/auth/login' && $method === 'POST') {
    $email = strtolower(trim((string)($body['email'] ?? '')));
    $pass = (string)($body['password'] ?? '');
    $s = $pdo->prepare(
        "SELECT u.*, r.name AS roleName
         FROM `User` u JOIN `Role` r ON r.id = u.roleId
         WHERE LOWER(u.email) = ? LIMIT 1"
    );
    $s->execute([$email]);
    $u = $s->fetch();
    if ($u && (int)($u['failedLoginCount'] ?? 0) >= 8) {
        json_out(['error' => 'LOCKED'], 423);
    }
    if (!$u || !password_verify($pass, $u['passwordHash']) || $u['status'] !== 'ACTIVE') {
        if ($u) {
            $pdo->prepare("UPDATE `User` SET failedLoginCount = failedLoginCount + 1 WHERE id = ?")->execute([$u['id']]);
        }
        json_out(['error' => 'INVALID_CREDENTIALS'], 401);
    }
    $_SESSION['uid'] = $u['id'];
    $pdo->prepare("UPDATE `User` SET lastLoginAt = ?, failedLoginCount = 0 WHERE id = ?")
        ->execute([nowms(), $u['id']]);
    $access = make_access_token($u['id']);
    json_out(['accessToken' => $access, 'tokenType' => 'Bearer', 'expiresIn' => '24h']);
}

if ($path === '/auth/register' && $method === 'POST') {
    $email = strtolower(trim((string)($body['email'] ?? '')));
    $name = trim((string)($body['name'] ?? ''));
    $pass = (string)($body['password'] ?? '');
    $confirm = (string)($body['confirmPassword'] ?? $body['confirm'] ?? '');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($pass) < 8 || $name === '') {
        json_out(['error' => 'INVALID_INPUT'], 422);
    }
    if ($confirm === '' || !hash_equals($pass, $confirm)) {
        json_out(['error' => 'PASSWORD_MISMATCH'], 422);
    }
    $s = $pdo->prepare("SELECT id FROM `User` WHERE email = ?");
    $s->execute([$email]);
    if ($s->fetch()) {
        json_out(['error' => 'EMAIL_EXISTS'], 409);
    }
    $r = $pdo->query("SELECT id FROM `Role` WHERE name = 'CUSTOMER' LIMIT 1")->fetchColumn();
    $id = uid();
    $now = nowms();
    $pdo->prepare(
        "INSERT INTO `User`
         (id, email, passwordHash, name, status, roleId, failedLoginCount, twoFactorEnabled, createdAt, updatedAt)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    )->execute([
        $id, $email, password_hash($pass, PASSWORD_DEFAULT), $name,
        'ACTIVE', $r, 0, 0, $now, $now,
    ]);
    $code = strtoupper(substr(preg_replace('/[^a-z0-9]/i', '', explode('@', $email)[0]) . 'XX', 0, 6));
    $refIn = strtoupper(trim((string)($body['referralCode'] ?? $body['ref'] ?? '')));
    $sponsor = null;
    if ($refIn !== '') {
        $sp = $pdo->prepare("SELECT id FROM `User` WHERE referralCode = ? LIMIT 1");
        $sp->execute([$refIn]);
        $sponsor = $sp->fetchColumn() ?: null;
    }
    try {
        $pdo->prepare("UPDATE `User` SET referralCode = ?, referredBy = ? WHERE id = ?")->execute([$code, $sponsor, $id]);
    } catch (Throwable $e) {}
    ensure_wallet($id);
    $_SESSION['uid'] = $id;
    json_out(['accessToken' => make_access_token($id), 'tokenType' => 'Bearer', 'expiresIn' => '24h'], 201);
}

if ($path === '/auth/logout' && $method === 'POST') {
    $h = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (preg_match('/^Bearer\s+(.+)$/i', $h, $m)) {
        $pdo->prepare("UPDATE AccessToken SET revokedAt = ? WHERE tokenHash = ?")
            ->execute([nowms(), hash_token(trim($m[1]))]);
    }
    $_SESSION = [];
    if (session_id() !== '') {
        session_destroy();
    }
    json_out(['ok' => true]);
}

if ($path === '/auth/refresh' && $method === 'POST') {
    json_out(['error' => 'REFRESH_NOT_REQUIRED'], 401);
}

/* ---------- Authenticated routes ---------- */

$u = require_login();

if ($path === '/debug/client' && $method === 'POST') {
    admin($u, false);
    $ep = trim((string)($body['endpoint'] ?? 'package-v3'));
    $bundle = strtolower(trim((string)($body['bundle_id'] ?? $body['bundleId'] ?? '')));
    $udid = trim((string)($body['udid'] ?? ''));
    $key = trim((string)($body['key'] ?? ''));
    $device = trim((string)($body['device_code'] ?? $body['device'] ?? 'iPhone'));
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $request = compact('ep', 'bundle', 'udid', 'key', 'device');
    if ($ep === 'health') {
        json_out(['request' => $request, 'response' => ['ok' => true, 'service' => 'ShopDTA']]);
    }
    if ($ban = banned_row($udid, $ip)) {
        json_out(['request' => $request, 'response' => ['success' => false, 'code' => 6403, 'message' => 'Banned', 'ban' => $ban['kind']]]);
    }
    if ($ep === 'package-v3') {
        $s = $pdo->prepare("SELECT * FROM `Package` WHERE LOWER(bundleId) = ? AND isActive = 1 ORDER BY priceCents ASC LIMIT 1");
        $s->execute([$bundle]);
        $p = $s->fetch();
        json_out([
            'request' => $request,
            'response' => $p
                ? ['success' => true, 'code' => 200, 'data' => ['name' => $p['name'], 'version' => $p['version'] ?? '1.0.0', 'durationDays' => (int)$p['durationDays'], 'maxDevices' => (int)$p['maxDevices']]]
                : ['success' => false, 'code' => 4000, 'message' => 'No package for bundle'],
        ]);
    }
    if ($ep === 'credential-v3') {
        $s = $pdo->prepare(
            "SELECT l.* FROM `License` l
             JOIN `LicenseActivation` a ON a.licenseId = l.id AND a.active = 1
             WHERE a.deviceId = ? AND l.status = 'ACTIVE' LIMIT 1"
        );
        $s->execute([$udid]);
        $l = $s->fetch();
        json_out([
            'request' => $request,
            'response' => $l
                ? ['success' => true, 'code' => 6200, 'data' => ['key' => $l['key'], 'expiredAt' => $l['expiresAt']]]
                : ['success' => false, 'code' => 6404, 'message' => 'Device not logged in.'],
        ]);
    }
    if ($ep === 'key-v3') {
        $l = license_row($key);
        if (!$l) {
            json_out(['request' => $request, 'response' => ['success' => false, 'code' => 4000, 'message' => 'License key invalid.']]);
        }
        json_out(['request' => $request, 'response' => ['success' => true, 'code' => 4200, 'data' => ['key' => $l['key'], 'expiredAt' => $l['expiresAt']]]]);
    }
    json_out(['error' => 'UNKNOWN_ENDPOINT'], 422);
}

if ($path === '/debug/security' && $method === 'GET') {
    admin($u, false);
    global $cfg;
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $tok = sepay_token();
    $items = [
        ['id' => 'https', 'ok' => $https, 'title' => 'HTTPS', 'detail' => $https ? 'Đang TLS' : 'Chưa HTTPS — token dễ lộ'],
        ['id' => 'webhook', 'ok' => $tok !== '', 'title' => 'SePay webhook token', 'detail' => $tok !== '' ? 'Có token, chỉ header Apikey' : 'Chưa cấu hình'],
        ['id' => 'transport', 'ok' => strlen((string)($cfg['transport_key'] ?? '')) === 32, 'title' => 'Transport key 32 byte', 'detail' => 'AES+HMAC client v4'],
        ['id' => 'rsa', 'ok' => !empty($cfg['rsa_private_key']), 'title' => 'RSA private', 'detail' => 'Ký envelope response'],
        ['id' => 'packages', 'ok' => true, 'title' => 'GET /packages', 'detail' => 'Chỉ admin'],
        ['id' => 'validate', 'ok' => true, 'title' => 'POST /licenses/validate', 'detail' => 'Chỉ admin — chặn dò key'],
        ['id' => 'debug', 'ok' => true, 'title' => 'POST /debug/client', 'detail' => 'Chỉ admin'],
        ['id' => 'login-lock', 'ok' => true, 'title' => 'Login lock', 'detail' => 'Khóa sau 8 lần sai'],
        ['id' => 'nonce', 'ok' => true, 'title' => 'Nonce anti-replay', 'detail' => 'Client v4 nonce 1 lần / 10 phút'],
        ['id' => 'webhook-query', 'ok' => true, 'title' => 'Webhook không nhận token query', 'detail' => 'Chỉ Authorization header'],
        ['id' => 'client-error', 'ok' => true, 'title' => 'Client error không leak', 'detail' => 'Không trả exception ra JSON'],
    ];
    json_out(['items' => $items, 'score' => count(array_filter($items, fn($i) => $i['ok'])) . '/' . count($items)]);
}

/* Users */
if ($path === '/users/me' && $method === 'GET') {
    json_out(public_user($u));
}

if ($path === '/users' && $method === 'GET') {
    admin($u);
    [$pg, $lim, $off] = page_limit();
    $s = $pdo->prepare(
        "SELECT u.id, u.email, u.name, u.status, u.lastLoginAt, u.createdAt, r.name AS roleName
         FROM `User` u JOIN `Role` r ON r.id = u.roleId
         ORDER BY u.createdAt DESC LIMIT $lim OFFSET $off"
    );
    $s->execute();
    $items = array_map('public_user', $s->fetchAll());
    $total = (int)$pdo->query("SELECT COUNT(*) FROM `User`")->fetchColumn();
    json_out(['items' => $items, 'page' => $pg, 'pageSize' => $lim, 'total' => $total]);
}

if (preg_match('#^/users/([^/]+)$#', $path, $m) && $method === 'PATCH') {
    admin($u, false);
    $id = $m[1];
    $pdo->prepare(
        "UPDATE `User`
         SET name = COALESCE(?, name), email = COALESCE(?, email),
             status = COALESCE(?, status), roleId = COALESCE(?, roleId), updatedAt = ?
         WHERE id = ?"
    )->execute([
        $body['name'] ?? null,
        $body['email'] ?? null,
        $body['status'] ?? null,
        $body['roleId'] ?? null,
        nowms(),
        $id,
    ]);
    json_out(['ok' => true]);
}

/* Products */
if ($path === '/products' && $method === 'GET') {
    [$pg, $lim, $off] = page_limit();
    $s = $pdo->prepare(
        "SELECT * FROM `Product` ORDER BY createdAt DESC LIMIT $lim OFFSET $off"
    );
    $s->execute();
    json_out(['items' => $s->fetchAll(), 'page' => $pg, 'pageSize' => $lim]);
}

if ($path === '/products' && $method === 'POST') {
    admin($u, false);
    $id = uid();
    $now = nowms();
    $slug = trim((string)($body['slug'] ?? '')) ?: preg_replace('/[^a-z0-9]+/', '-', strtolower($body['name'] ?? 'product'));
    $pdo->prepare(
        "INSERT INTO `Product` (id, name, slug, description, status, imageUrl, createdAt, updatedAt)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
    )->execute([
        $id,
        trim((string)($body['name'] ?? '')),
        $slug,
        $body['description'] ?? '',
        $body['status'] ?? 'ACTIVE',
        $body['imageUrl'] ?? null,
        $now,
        $now,
    ]);
    audit('product.create', 'Product', $id);
    json_out(['id' => $id], 201);
}

if (preg_match('#^/products/([^/]+)$#', $path, $m) && $method === 'DELETE') {
    admin($u, false);
    $pdo->prepare("DELETE FROM `Product` WHERE id = ?")->execute([$m[1]]);
    json_out(['ok' => true]);
}

if (preg_match('#^/products/([^/]+)$#', $path, $m) && $method === 'PATCH') {
    admin($u, false);
    $pdo->prepare(
        "UPDATE `Product`
         SET name = COALESCE(?, name), slug = COALESCE(?, slug),
             description = COALESCE(?, description), status = COALESCE(?, status),
             imageUrl = ?, updatedAt = ?
         WHERE id = ?"
    )->execute([
        $body['name'] ?? null,
        $body['slug'] ?? null,
        $body['description'] ?? null,
        $body['status'] ?? null,
        $body['imageUrl'] ?? null,
        nowms(),
        $m[1],
    ]);
    json_out(['ok' => true]);
}


if ($path === '/shop/packages' && $method === 'GET') {
    $bundle = strtolower(trim((string)($_GET['bundle'] ?? '')));
    $sql = "SELECT p.*, pr.name AS productName FROM `Package` p
            LEFT JOIN `Product` pr ON pr.id = p.productId
            WHERE p.isActive = 1";
    $args = [];
    if ($bundle !== '') {
        $sql .= " AND (LOWER(p.bundleId) = ? OR p.bundleId IS NULL OR p.bundleId = '')";
        $args[] = $bundle;
    }
    $sql .= " ORDER BY p.bundleId ASC, p.priceCents ASC";
    $s = $pdo->prepare($sql);
    $s->execute($args);
    json_out(['items' => $s->fetchAll()]);
}

if ($path === '/shop/checkout' && $method === 'POST') {
    $pkg = package_row((string)($body['packageId'] ?? ''));
    if (!$pkg || !(int)$pkg['isActive']) {
        json_out(['error' => 'INVALID_PACKAGE'], 422);
    }
    $oid = uid();
    $ref = 'DTA' . strtoupper(substr($oid, 0, 8));
    $now = nowms();
    $price = (int)$pkg['priceCents'];
    $pdo->beginTransaction();
    try {
        $pdo->prepare(
            "INSERT INTO `Order`
             (id, reference, userId, status, subtotalCents, totalCents, currency, provider, createdAt, updatedAt, referralCode)
             VALUES (?, ?, ?, 'PENDING', ?, ?, 'VND', 'sepay', ?, ?, ?)"
        )->execute([
            $oid, $ref, $u['id'], $price, $price, $now, $now,
            strtoupper(trim((string)($body['referralCode'] ?? ''))) ?: null,
        ]);
        $pdo->prepare(
            "INSERT INTO `OrderItem` (id, orderId, packageId, quantity, unitPriceCents) VALUES (?, ?, ?, 1, ?)"
        )->execute([uid(), $oid, $pkg['id'], $price]);
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        json_out(['error' => $e->getMessage()], 500);
    }
    $bank = $cfg['sepay'] ?? [];
    json_out([
        'id' => $oid,
        'reference' => $ref,
        'content' => $ref,
        'amountVnd' => $price,
        'bankCode' => $bank['bankCode'] ?? 'VCB',
        'accountNumber' => $bank['accountNumber'] ?? '',
        'accountName' => $bank['accountName'] ?? '',
    ], 201);
}

if ($path === '/settings/sepay' && ($method === 'POST' || $method === 'PUT' || $method === 'PATCH')) {
    admin($u, false);
    global $cfg, $configPath;
    $cfg['sepay'] = [
        'bankCode' => strtoupper(trim((string)($body['bankCode'] ?? ($cfg['sepay']['bankCode'] ?? 'VCB')))),
        'accountNumber' => trim((string)($body['accountNumber'] ?? ($cfg['sepay']['accountNumber'] ?? ''))),
        'accountName' => trim((string)($body['accountName'] ?? ($cfg['sepay']['accountName'] ?? ''))),
    ];
    $tok = trim((string)($body['webhookToken'] ?? ''));
    if ($tok !== '' && $tok !== 'configured') {
        $cfg['sepay_webhook_token'] = $tok;
    }
    file_put_contents($configPath, "<?php\nreturn " . var_export($cfg, true) . ";\n", LOCK_EX);
    json_out(['ok' => true]);
}

if ($path === '/settings/sepay' && $method === 'GET') {
    admin($u, false);
    json_out([
        'bankCode' => $cfg['sepay']['bankCode'] ?? 'VCB',
        'accountNumber' => $cfg['sepay']['accountNumber'] ?? '',
        'accountName' => $cfg['sepay']['accountName'] ?? '',
        'webhookToken' => sepay_token() !== '' ? 'configured' : '',
    ]);
}

/* Packages */
if ($path === '/packages' && $method === 'GET') {
    admin($u, false);
    [$pg, $lim, $off] = page_limit();
    $s = $pdo->prepare(
        "SELECT p.*, pr.name AS productName, pr.slug AS productSlug, pr.description AS productDescription
         FROM `Package` p
         LEFT JOIN `Product` pr ON pr.id = p.productId
         ORDER BY p.createdAt DESC LIMIT $lim OFFSET $off"
    );
    $s->execute();
    $items = $s->fetchAll();
    foreach ($items as &$it) {
        $it['isActive'] = (bool)(int)($it['isActive'] ?? 0);
        $it['requireUdid'] = (bool)(int)($it['requireUdid'] ?? 1);
        $it['priceCents'] = (int)($it['priceCents'] ?? 0);
        $it['durationDays'] = (int)($it['durationDays'] ?? 0);
        $it['maxDevices'] = (int)($it['maxDevices'] ?? 1);
        $it['product'] = [
            'name' => $it['productName'] ?? '',
            'slug' => $it['productSlug'] ?? '',
            'description' => $it['productDescription'] ?? '',
        ];
    }
    unset($it);
    json_out(['items' => $items, 'page' => $pg, 'pageSize' => $lim]);
}

if ($path === '/packages' && $method === 'POST') {
    admin($u, false);
    $id = uid();
    $now = nowms();
    $bundle = isset($body['bundleId']) ? (trim((string)$body['bundleId']) ?: null) : null;
    if ($bundle !== null && $bundle !== '' && !valid_bundle($bundle)) {
        json_out(['error' => 'INVALID_BUNDLE_ID'], 422);
    }
    $pdo->prepare(
        "INSERT INTO `Package`
         (id, productId, name, description, priceCents, durationDays, licenseType,
          maxDevices, bundleId, requestQuota, isActive, requireUdid, createdAt, updatedAt)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    )->execute([
        $id,
        $body['productId'] ?? '',
        $body['name'] ?? '',
        $body['description'] ?? '',
        (int)($body['priceCents'] ?? round((float)($body['price'] ?? 0) * 100)),
        (int)($body['durationDays'] ?? 30),
        $body['licenseType'] ?? 'TIME_BASED',
        (int)($body['maxDevices'] ?? 1),
        $bundle,
        $body['requestQuota'] ?? null,
        isset($body['isActive']) ? (int)$body['isActive'] : 1,
        isset($body['requireUdid']) ? (int)(bool)$body['requireUdid'] : 1,
        $now,
        $now,
    ]);
    audit('package.create', 'Package', $id);
    try {
        $ver = trim((string)($body['version'] ?? '1.0.0')) ?: '1.0.0';
        $pdo->prepare("UPDATE `Package` SET version = ? WHERE id = ?")->execute([$ver, $id]);
    } catch (Throwable $e) {}
    json_out(['id' => $id], 201);
}

if (preg_match('#^/packages/([^/]+)$#', $path, $m) && $method === 'PATCH') {
    admin($u, false);
    $id = $m[1];
    $pdo->prepare(
        "UPDATE `Package`
         SET name = COALESCE(?, name), description = COALESCE(?, description),
             priceCents = COALESCE(?, priceCents), durationDays = COALESCE(?, durationDays),
             maxDevices = COALESCE(?, maxDevices), bundleId = ?, requestQuota = ?,
             isActive = COALESCE(?, isActive), requireUdid = COALESCE(?, requireUdid), updatedAt = ?
         WHERE id = ?"
    )->execute([
        $body['name'] ?? null,
        $body['description'] ?? null,
        isset($body['priceCents']) ? (int)$body['priceCents'] : (isset($body['priceVnd']) ? (int)$body['priceVnd'] : null),
        isset($body['durationDays']) ? (int)$body['durationDays'] : null,
        isset($body['maxDevices']) ? (int)$body['maxDevices'] : null,
        $body['bundleId'] ?? null,
        $body['requestQuota'] ?? null,
        isset($body['isActive']) ? (int)$body['isActive'] : null,
        isset($body['requireUdid']) ? (int)(bool)$body['requireUdid'] : null,
        nowms(),
        $id,
    ]);
    if (isset($body['version'])) {
        try {
            $ver = trim((string)$body['version']) ?: '1.0.0';
            $pdo->prepare("UPDATE `Package` SET version = ? WHERE id = ?")->execute([$ver, $id]);
        } catch (Throwable $e) {}
    }
    push_event('package.updated', ['id' => $id, 'name' => $body['name'] ?? null, 'version' => $body['version'] ?? null]);
    json_out(['ok' => true]);
}

if (preg_match('#^/packages/([^/]+)$#', $path, $m) && $method === 'DELETE') {
    admin($u, false);
    $id = $m[1];
    try {
        $c = $pdo->prepare("SELECT COUNT(*) FROM `License` WHERE packageId = ?");
        $c->execute([$id]);
        $n = (int)$c->fetchColumn();
    } catch (Throwable $e) { $n = 1; }
    if ($n === 0) {
        try { $pdo->prepare("DELETE FROM `OrderItem` WHERE packageId = ?")->execute([$id]); } catch (Throwable $e) {}
        $pdo->prepare("DELETE FROM `Package` WHERE id = ?")->execute([$id]);
        json_out(['ok' => true, 'hard' => true]);
    }
    $pdo->prepare("UPDATE `Package` SET isActive = 0, updatedAt = ? WHERE id = ?")->execute([nowms(), $id]);
    json_out(['ok' => true, 'hard' => false, 'licenses' => $n]);
}

/* Licenses */
if ($path === '/licenses' && $method === 'GET') {
    [$pg, $lim, $off] = page_limit();
    $where = $u['roleName'] === 'CUSTOMER' ? 'WHERE l.ownerId = ?' : '';
    $args = $u['roleName'] === 'CUSTOMER' ? [$u['id']] : [];
    $s = $pdo->prepare(
        "SELECT l.*, p.name AS packageName, p.bundleId AS packageBundleId, u.email AS ownerEmail
         FROM `License` l
         LEFT JOIN `Package` p ON p.id = l.packageId
         LEFT JOIN `User` u ON u.id = l.ownerId
         $where
         ORDER BY l.createdAt DESC LIMIT $lim OFFSET $off"
    );
    $s->execute($args);
    $rows = $s->fetchAll();
    foreach ($rows as &$r) {
        $r['owner'] = ['email' => $r['ownerEmail'] ?? ''];
        $r['package'] = ['name' => $r['packageName'] ?? ''];
        $exp = $r['expiresAt'] ? strtotime((string)$r['expiresAt']) : 0;
        $r['remainingSeconds'] = $exp ? max(0, $exp - time()) : 0;
        $r['expired'] = $exp > 0 && $exp <= time();
        $q = $pdo->prepare("SELECT * FROM `LicenseActivation` WHERE licenseId = ?");
        $q->execute([$r['id']]);
        $r['activations'] = $q->fetchAll();
        $r['activeDevices'] = count(array_filter($r['activations'], fn($a) => (int)($a['active'] ?? 0) === 1));
    }
    unset($r);
    json_out(['items' => $rows, 'page' => $pg, 'pageSize' => $lim]);
}

if ($path === '/devices' && $method === 'GET') {
    $where = $u['roleName'] === 'CUSTOMER' ? 'WHERE l.ownerId = ?' : '';
    $args = $u['roleName'] === 'CUSTOMER' ? [$u['id']] : [];
    $s = $pdo->prepare(
        "SELECT a.*, l.`key` AS licenseKey, l.bundleId, l.maxDevices, l.expiresAt, l.ownerId
         FROM `LicenseActivation` a
         JOIN `License` l ON l.id = a.licenseId
         $where
         ORDER BY a.activatedAt DESC LIMIT 200"
    );
    $s->execute($args);
    json_out(['items' => $s->fetchAll()]);
}

if ($path === '/udid/enrollments' && $method === 'GET') {
    admin($u, false);
    ensure_udid_table();
    $s = $pdo->query("SELECT * FROM `UdidEnrollment` ORDER BY createdAt DESC LIMIT 200");
    json_out(['items' => $s->fetchAll() ?: [], 'requireEnrolled' => require_enrolled_udid()]);
}

if ($path === '/settings/udid' && $method === 'GET') {
    admin($u, false);
    json_out(['requireEnrolled' => require_enrolled_udid()]);
}

if ($path === '/settings/udid' && ($method === 'POST' || $method === 'PATCH')) {
    admin($u, false);
    $on = !empty($body['requireEnrolled']);
    $private = dirname(__DIR__) . '/private';
    if (!is_dir($private)) $private = __DIR__ . '/private';
    file_put_contents(
        $private . '/udid-settings.php',
        "<?php\nreturn ['require' => " . ($on ? 'true' : 'false') . "];\n"
    );
    push_event('setting.udid', ['require' => $on]);
    json_out(['ok' => true, 'requireEnrolled' => $on]);
}

if (preg_match('#^/devices/([^/]+)/unbind$#', $path, $m) && $method === 'POST') {
    $id = $m[1];
    $s = $pdo->prepare(
        "SELECT a.*, l.ownerId FROM `LicenseActivation` a JOIN `License` l ON l.id = a.licenseId WHERE a.id = ?"
    );
    $s->execute([$id]);
    $row = $s->fetch();
    if (!$row) {
        json_out(['error' => 'NOT_FOUND'], 404);
    }
    if ($u['roleName'] === 'CUSTOMER' && $row['ownerId'] !== $u['id']) {
        json_out(['error' => 'FORBIDDEN'], 403);
    }
    if ($u['roleName'] !== 'SUPER_ADMIN' && $u['roleName'] !== 'ADMIN') {
        $week = date('Y-m-d', strtotime('monday this week'));
        $start = $u['unbindWeekStart'] ?? null;
        if ($start !== $week) {
            $pdo->prepare("UPDATE `User` SET unbindCountWeek = 0, unbindWeekStart = ? WHERE id = ?")->execute([$week, $u['id']]);
        }
        $cas = $pdo->prepare("UPDATE `User` SET unbindCountWeek = unbindCountWeek + 1, unbindWeekStart = ? WHERE id = ? AND unbindCountWeek < 1");
        $cas->execute([$week, $u['id']]);
        if ($cas->rowCount() === 0) {
            json_out(['error' => 'UNBIND_LIMIT', 'message' => 'Hết lượt đổi máy tuần này.'], 429);
        }
    }
    $pdo->prepare("UPDATE `LicenseActivation` SET active = 0, deactivatedAt = ? WHERE id = ?")
        ->execute([nowms(), $id]);
    json_out(['ok' => true]);
}

if ($path === '/events' && $method === 'GET') {
    $after = (int)($_GET['after'] ?? 0);
    try {
        $s = $pdo->prepare("SELECT seq, type, payloadJson, createdAt FROM `RealtimeEvent` WHERE seq > ? ORDER BY seq ASC LIMIT 80");
        $s->execute([$after]);
        $items = [];
        foreach ($s->fetchAll() as $r) {
            $items[] = [
                'seq' => (int)$r['seq'],
                'type' => $r['type'],
                'at' => $r['createdAt'],
                'payload' => json_decode((string)$r['payloadJson'], true) ?: [],
            ];
        }
        json_out(['items' => $items]);
    } catch (Throwable $e) {
        json_out(['items' => []]);
    }
}

if ($path === '/bans' && $method === 'GET') {
    admin($u, false);
    $s = $pdo->query("SELECT * FROM `BanTarget` ORDER BY createdAt DESC LIMIT 200");
    json_out(['items' => $s->fetchAll()]);
}

if ($path === '/bans' && $method === 'POST') {
    admin($u, false);
    $id = uid();
    $pdo->prepare("INSERT INTO `BanTarget` (id, kind, value, reason, active, createdAt) VALUES (?, ?, ?, ?, 1, ?)")
        ->execute([
            $id,
            in_array($body['kind'] ?? '', ['udid', 'ip'], true) ? $body['kind'] : 'udid',
            trim((string)($body['value'] ?? '')),
            trim((string)($body['reason'] ?? 'ban')),
            nowms(),
        ]);
    json_out(['id' => $id], 201);
}

if (preg_match('#^/bans/([^/]+)/unban$#', $path, $m) && $method === 'POST') {
    admin($u, false);
    $pdo->prepare("UPDATE `BanTarget` SET active = 0 WHERE id = ?")->execute([$m[1]]);
    json_out(['ok' => true]);
}

if (preg_match('#^/users/([^/]+)/promote$#', $path, $m) && $method === 'POST') {
    admin($u, false);
    $pct = max(1, min(80, (int)($body['commissionPct'] ?? 20)));
    $code = strtoupper(substr(preg_replace('/[^a-z0-9]/i', '', (string)$m[1]) . bin2hex(random_bytes(2)), 0, 6));
    $pdo->prepare("UPDATE `User` SET isReseller = 1, commissionPct = ?, referralCode = COALESCE(NULLIF(referralCode,''), ?) WHERE id = ?")
        ->execute([$pct, $code, $m[1]]);
    json_out(['ok' => true]);
}

if ($path === '/commissions' && $method === 'GET') {
    if ($u['roleName'] === 'CUSTOMER') {
        json_out(['error' => 'FORBIDDEN'], 403);
    }
    $sql = "SELECT * FROM `Commission`";
    $args = [];
    if ($u['roleName'] === 'RESELLER') {
        $sql .= " WHERE resellerId = ?";
        $args[] = $u['id'];
    }
    $sql .= " ORDER BY createdAt DESC LIMIT 200";
    $s = $pdo->prepare($sql);
    $s->execute($args);
    json_out(['items' => $s->fetchAll()]);
}

if (preg_match('#^/licenses/([^/]+)/extend$#', $path, $m) && $method === 'POST') {
    admin($u, false);
    $days = max(1, (int)($body['days'] ?? 7));
    $s = $pdo->prepare("SELECT * FROM `License` WHERE id = ?");
    $s->execute([$m[1]]);
    $l = $s->fetch();
    if (!$l) {
        json_out(['error' => 'NOT_FOUND'], 404);
    }
    $base = max(time(), $l['expiresAt'] ? strtotime((string)$l['expiresAt']) : time());
    $next = date('Y-m-d H:i:s', $base + $days * 86400);
    $pdo->prepare("UPDATE `License` SET expiresAt = ?, status = 'ACTIVE', updatedAt = ? WHERE id = ?")
        ->execute([$next, nowms(), $m[1]]);
    json_out(['ok' => true, 'expiresAt' => $next]);
}

if ($path === '/licenses' && $method === 'POST') {
    admin($u, false);
    $pkgId = $body['packageId'] ?? '';
    $pkg = package_row($pkgId);
    if (!$pkg) {
        json_out(['error' => 'PACKAGE_NOT_FOUND'], 404);
    }
    $count = max(1, min(50, (int)($body['count'] ?? 1)));
    $status = in_array($body['status'] ?? 'ACTIVE', ['ACTIVE', 'PENDING'], true)
        ? ($body['status'] ?? 'ACTIVE') : 'ACTIVE';
    $ownerId = $body['ownerId'] ?? $u['id'];
    $days = isset($body['durationDays']) ? max(1, (int)$body['durationDays']) : max(1, (int)$pkg['durationDays']);
    $maxDev = isset($body['maxDevices']) ? max(1, (int)$body['maxDevices']) : max(1, (int)$pkg['maxDevices']);
    $bundle = isset($body['bundleId']) ? (trim((string)$body['bundleId']) ?: null) : ($pkg['bundleId'] ?? null);
    $now = nowms();
    $expires = date('Y-m-d H:i:s', time() + $days * 86400);
    $created = [];
    for ($i = 0; $i < $count; $i++) {
        $id = uid();
        $key = license_key();
        $pdo->prepare(
            "INSERT INTO `License`
             (id, `key`, status, licenseType, ownerId, packageId, expiresAt, maxDevices, bundleId, createdAt, updatedAt)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        )->execute([
            $id, $key, $status, $pkg['licenseType'], $ownerId, $pkgId,
            $expires, $maxDev, $bundle, $now, $now,
        ]);
        $created[] = ['id' => $id, 'key' => $key, 'expiresAt' => $expires, 'status' => $status];
        audit('license.create', 'License', $id);
    }
    json_out([
        'items' => $created,
        'id' => $created[0]['id'],
        'key' => $created[0]['key'],
        'count' => count($created),
    ], 201);
}

if ($path === '/licenses/validate' && $method === 'POST') {
    admin($u, false);
    $key = trim((string)($body['key'] ?? ''));
    $l = license_row($key);
    if (!$l) {
        json_out(['valid' => false, 'error' => 'NOT_FOUND']);
    }
    $valid = $l['status'] === 'ACTIVE'
        && (!$l['expiresAt'] || strtotime($l['expiresAt']) > time());
    json_out([
        'valid'   => $valid,
        'license' => $valid ? [
            'key'       => $l['key'],
            'status'    => $l['status'],
            'expiresAt' => $l['expiresAt'],
            'package'   => $l['packageName'],
        ] : null,
    ]);
}

if (preg_match('#^/licenses/([^/]+)/(activate|deactivate|revoke)$#', $path, $m) && $method === 'POST') {
    $id = $m[1];
    $action = $m[2];
    $s = $pdo->prepare("SELECT * FROM `License` WHERE id = ?");
    $s->execute([$id]);
    $l = $s->fetch();
    if (!$l) {
        json_out(['error' => 'NOT_FOUND'], 404);
    }
    if ($u['roleName'] === 'CUSTOMER' && $l['ownerId'] !== $u['id']) {
        json_out(['error' => 'FORBIDDEN'], 403);
    }
    if ($action === 'revoke') {
        admin($u, false);
        $pdo->prepare("UPDATE `License` SET status = 'REVOKED', updatedAt = ? WHERE id = ?")
            ->execute([nowms(), $id]);
        json_out(['ok' => true]);
    }
    if ($action === 'deactivate') {
        $dev = trim((string)($body['deviceId'] ?? ''));
        if ($dev === '') {
            json_out(['error' => 'DEVICE_REQUIRED'], 422);
        }
        $pdo->prepare(
            "UPDATE `LicenseActivation`
             SET active = 0, deactivatedAt = ?
             WHERE licenseId = ? AND deviceId = ?"
        )->execute([nowms(), $id, $dev]);
        json_out(['ok' => true]);
    }
    // activate
    $dev = trim((string)($body['deviceId'] ?? $body['udid'] ?? ''));
    if ($dev === '') {
        json_out(['error' => 'DEVICE_REQUIRED'], 422);
    }
    $q = $pdo->prepare("SELECT COUNT(*) FROM `LicenseActivation` WHERE licenseId = ? AND active = 1");
    $q->execute([$id]);
    $active = (int)$q->fetchColumn();
    if ($active >= (int)$l['maxDevices']) {
        json_out(['error' => 'DEVICE_LIMIT'], 422);
    }
    $pdo->prepare(
        "INSERT INTO `LicenseActivation`
         (id, licenseId, deviceId, deviceName, active, activatedAt)
         VALUES (?, ?, ?, ?, 1, ?)
         ON DUPLICATE KEY UPDATE
           active = 1, deactivatedAt = NULL,
           deviceName = VALUES(deviceName), activatedAt = VALUES(activatedAt)"
    )->execute([
        uid(),
        $id,
        $dev,
        $body['deviceName'] ?? $dev,
        nowms(),
    ]);
    $pdo->prepare(
        "UPDATE `License`
         SET status = 'ACTIVE', activatedAt = COALESCE(activatedAt, ?), updatedAt = ?
         WHERE id = ?"
    )->execute([nowms(), nowms(), $id]);
    json_out(['ok' => true]);
}

/* Applications */
if ($path === '/applications' && $method === 'GET') {
    [$pg, $lim, $off] = page_limit();
    $s = $pdo->prepare(
        "SELECT a.*,
                (SELECT COUNT(*) FROM `ApiKey` k WHERE k.applicationId = a.id) AS apiKeyCount
         FROM `Application` a
         WHERE a.ownerId = ?
         ORDER BY a.createdAt DESC LIMIT $lim OFFSET $off"
    );
    $s->execute([$u['id']]);
    $items = $s->fetchAll();
    foreach ($items as &$it) {
        $it['_count'] = ['apiKeys' => (int)$it['apiKeyCount']];
    }
    unset($it);
    json_out(['items' => $items]);
}

if ($path === '/applications' && $method === 'POST') {
    $id = uid();
    $now = nowms();
    $pdo->prepare(
        "INSERT INTO `Application`
         (id, ownerId, name, description, version, isActive, createdAt, updatedAt)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
    )->execute([
        $id,
        $u['id'],
        $body['name'] ?? 'App',
        $body['description'] ?? '',
        $body['version'] ?? '1.0.0',
        isset($body['isActive']) ? (int)$body['isActive'] : 1,
        $now,
        $now,
    ]);
    json_out(['id' => $id], 201);
}

if (preg_match('#^/applications/([^/]+)$#', $path, $m) && $method === 'PATCH') {
    $pdo->prepare(
        "UPDATE `Application`
         SET name = COALESCE(?, name), description = COALESCE(?, description),
             version = COALESCE(?, version), isActive = COALESCE(?, isActive), updatedAt = ?
         WHERE id = ? AND ownerId = ?"
    )->execute([
        $body['name'] ?? null,
        $body['description'] ?? null,
        $body['version'] ?? null,
        isset($body['isActive']) ? (int)$body['isActive'] : null,
        nowms(),
        $m[1],
        $u['id'],
    ]);
    json_out(['ok' => true]);
}

if (preg_match('#^/applications/([^/]+)$#', $path, $m) && $method === 'DELETE') {
    admin($u, false);
    $pdo->prepare("DELETE FROM `Application` WHERE id = ?")->execute([$m[1]]);
    json_out(['ok' => true]);
}

/* API Keys */
if ($path === '/api-keys' && $method === 'GET') {
    [$pg, $lim, $off] = page_limit();
    $s = $pdo->prepare(
        "SELECT id, name, prefix, scopes, status, ownerId, applicationId,
                requestLimit, rateLimit, rateWindowSeconds, expiresAt, lastUsedAt,
                requestCount, createdAt
         FROM `ApiKey`
         WHERE ownerId = ?
         ORDER BY createdAt DESC LIMIT $lim OFFSET $off"
    );
    $s->execute([$u['id']]);
    $items = $s->fetchAll();
    foreach ($items as &$it) {
        $it['scopes'] = json_decode($it['scopes'] ?? '[]', true) ?: [];
    }
    unset($it);
    json_out(['items' => $items]);
}

if ($path === '/api-keys' && $method === 'POST') {
    $id = uid();
    $plain = 'dta_' . bin2hex(random_bytes(32));
    $now = nowms();
    $scopes = json_encode(array_values($body['scopes'] ?? ['read']));
    // 16 columns, 14 placeholders (status='ACTIVE', requestCount=0 are literals)
    $pdo->prepare(
        "INSERT INTO `ApiKey`
         (id, name, hashedKey, prefix, scopes, status, ownerId, applicationId,
          requestLimit, rateLimit, rateWindowSeconds, allowedIps, expiresAt,
          requestCount, createdAt, updatedAt)
         VALUES (?, ?, ?, ?, ?, 'ACTIVE', ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)"
    )->execute([
        $id,
        $body['name'] ?? 'API Key',
        password_hash($plain, PASSWORD_DEFAULT),
        substr($plain, 0, 12),
        $scopes,
        $u['id'],
        $body['applicationId'] ?? '',
        isset($body['requestLimit']) ? (int)$body['requestLimit'] : null,
        (int)($body['rateLimit'] ?? 120),
        (int)($body['rateWindowSeconds'] ?? 60),
        json_encode($body['allowedIps'] ?? []),
        $body['expiresAt'] ?? null,
        $now,
        $now,
    ]);
    json_out(['id' => $id, 'name' => $body['name'] ?? 'API Key', 'apiKey' => $plain], 201);
}

if (preg_match('#^/api-keys/([^/]+)/(rotate|revoke)$#', $path, $m) && $method === 'POST') {
    $s = $pdo->prepare("SELECT * FROM `ApiKey` WHERE id = ? AND ownerId = ?");
    $s->execute([$m[1], $u['id']]);
    if (!$s->fetch()) {
        json_out(['error' => 'NOT_FOUND'], 404);
    }
    if ($m[2] === 'revoke') {
        $pdo->prepare("UPDATE `ApiKey` SET status = 'REVOKED', updatedAt = ? WHERE id = ?")
            ->execute([nowms(), $m[1]]);
        json_out(['ok' => true]);
    }
    $plain = 'dta_' . bin2hex(random_bytes(32));
    $pdo->prepare(
        "UPDATE `ApiKey`
         SET hashedKey = ?, prefix = ?, status = 'ACTIVE', updatedAt = ?
         WHERE id = ?"
    )->execute([
        password_hash($plain, PASSWORD_DEFAULT),
        substr($plain, 0, 12),
        nowms(),
        $m[1],
    ]);
    json_out(['apiKey' => $plain]);
}

/* Logs & usage */
if ($path === '/rsa-public' && $method === 'GET') {
    admin($u);
    global $cfg;
    $private = (string)($cfg['rsa_private_key'] ?? '');
    $public = '';
    if ($private !== '') {
        $details = @openssl_pkey_get_details(@openssl_pkey_get_private($private));
        $public = is_array($details) ? (string)($details['key'] ?? '') : '';
    }
    $fingerprint = '';
    if ($public !== '') {
        $b64 = preg_replace('/-----(BEGIN|END) PUBLIC KEY-----|\s/', '', $public);
        $der = base64_decode($b64 ?: '', true);
        if ($der !== false) {
            $fingerprint = hash('sha256', $der);
        }
    }
    json_out([
        'publicKey' => $public,
        'fingerprintSha256' => $fingerprint,
        'expectedClientFingerprint' => 'c4982cc1095e58fc6aef39510d158a3943a949a968eaa76f1845e9c1bdf626a5',
        'matchesClient' => $fingerprint === 'c4982cc1095e58fc6aef39510d158a3943a949a968eaa76f1845e9c1bdf626a5',
        'transportKeyLength' => strlen((string)($cfg['transport_key'] ?? '')),
        'note' => 'Giữ RSA cũ. matchesClient=true nghĩa là public key server khớp APIClient-New.',
    ]);
}

if ($path === '/client-logs' && $method === 'GET') {
    admin($u);
    ensure_client_log_table();
    [$pg, $lim, $off] = page_limit();
    $endpoint = trim((string)($_GET['endpoint'] ?? ''));
    $where = '';
    $args = [];
    if ($endpoint !== '') {
        $where = 'WHERE endpoint = ?';
        $args[] = $endpoint;
    }
    $s = $pdo->prepare(
        "SELECT * FROM `ClientRequestLog` $where ORDER BY createdAt DESC LIMIT $lim OFFSET $off"
    );
    $s->execute($args);
    $items = $s->fetchAll();
    foreach ($items as &$it) {
        if (!empty($it['requestJson'])) {
            $decoded = json_decode($it['requestJson'], true);
            $it['request'] = is_array($decoded) ? $decoded : null;
        } else {
            $it['request'] = null;
        }
        unset($it['requestJson']);
    }
    unset($it);
    $cntSql = "SELECT COUNT(*) FROM `ClientRequestLog`" . ($where ? " $where" : '');
    $c = $pdo->prepare($cntSql);
    $c->execute($args);
    $total = (int)$c->fetchColumn();
    json_out(['items' => $items, 'page' => $pg, 'pageSize' => $lim, 'total' => $total]);
}

if ($path === '/api-logs' && $method === 'GET') {
    admin($u);
    [$pg, $lim, $off] = page_limit();
    $s = $pdo->prepare(
        "SELECT * FROM `ApiLog` ORDER BY createdAt DESC LIMIT $lim OFFSET $off"
    );
    $s->execute();
    $items = $s->fetchAll();
    $total = (int)$pdo->query("SELECT COUNT(*) FROM `ApiLog`")->fetchColumn();
    json_out(['items' => $items, 'page' => $pg, 'pageSize' => $lim, 'total' => $total]);
}

if ($path === '/usage' && $method === 'GET') {
    admin($u);
    $s = $pdo->query("SELECT * FROM `ApiUsage` ORDER BY date DESC LIMIT 500");
    json_out(['items' => $s->fetchAll()]);
}

/* Payments / Wallet */
if ($path === '/payments/wallet' && $method === 'GET') {
    $w = ensure_wallet($u['id']);
    $s = $pdo->prepare(
        "SELECT * FROM `Transaction` WHERE walletId = ? ORDER BY createdAt DESC LIMIT 100"
    );
    $s->execute([$w['id']]);
    json_out(['wallet' => $w, 'transactions' => $s->fetchAll()]);
}

if ($path === '/payments/wallet/topup' && $method === 'POST') {
    $amount = (int)($body['amountCents'] ?? 0);
    if ($amount <= 0) {
        json_out(['error' => 'INVALID_AMOUNT'], 422);
    }
    $w = ensure_wallet($u['id']);
    $pdo->beginTransaction();
    try {
        $s = $pdo->prepare("SELECT * FROM `Wallet` WHERE id = ? FOR UPDATE");
        $s->execute([$w['id']]);
        $w = $s->fetch();
        $bal = (int)$w['balanceCents'] + $amount;
        $pdo->prepare("UPDATE `Wallet` SET balanceCents = ?, updatedAt = ? WHERE id = ?")
            ->execute([$bal, nowms(), $w['id']]);
        $pdo->prepare(
            "INSERT INTO `Transaction`
             (id, walletId, type, amountCents, balanceAfterCents, description, externalReference, createdAt)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
        )->execute([
            uid(),
            $w['id'],
            'TOPUP',
            $amount,
            $bal,
            'Manual top-up',
            $body['reference'] ?? null,
            nowms(),
        ]);
        $pdo->commit();
        json_out(['ok' => true, 'balanceCents' => $bal]);
    } catch (Throwable $e) {
        $pdo->rollBack();
        json_out(['error' => $e->getMessage()], 422);
    }
}

if ($path === '/payments/orders' && $method === 'GET') {
    [$pg, $lim, $off] = page_limit();
    $s = $pdo->prepare(
        "SELECT * FROM `Order` WHERE userId = ? ORDER BY createdAt DESC LIMIT $lim OFFSET $off"
    );
    $s->execute([$u['id']]);
    $items = $s->fetchAll();
    foreach ($items as &$o) {
        $q = $pdo->prepare(
            "SELECT oi.*, p.name AS packageName FROM `OrderItem` oi
             JOIN `Package` p ON p.id = oi.packageId WHERE oi.orderId = ?"
        );
        $q->execute([$o['id']]);
        $o['items'] = $q->fetchAll();
        $lic = $pdo->prepare("SELECT id, `key`, status, expiresAt FROM `License` WHERE orderId = ? LIMIT 1");
        $lic->execute([$o['id']]);
        $o['license'] = $lic->fetch() ?: null;
        $o['amountVnd'] = (int)($o['totalCents'] ?? 0);
        $o['content'] = $o['reference'] ?? '';
        $o['bankCode'] = $cfg['sepay']['bankCode'] ?? 'VCB';
        $o['accountNumber'] = $cfg['sepay']['accountNumber'] ?? '';
        $o['accountName'] = $cfg['sepay']['accountName'] ?? '';
    }
    unset($o);
    json_out(['items' => $items]);
}

if (preg_match('#^/payments/orders/([^/]+)$#', $path, $m) && $method === 'GET') {
    $s = $pdo->prepare("SELECT * FROM `Order` WHERE id = ? LIMIT 1");
    $s->execute([$m[1]]);
    $o = $s->fetch();
    if (!$o) {
        json_out(['error' => 'NOT_FOUND'], 404);
    }
    if ($u['roleName'] === 'CUSTOMER' && $o['userId'] !== $u['id']) {
        json_out(['error' => 'FORBIDDEN'], 403);
    }
    $q = $pdo->prepare(
        "SELECT oi.*, p.name AS packageName FROM `OrderItem` oi
         JOIN `Package` p ON p.id = oi.packageId WHERE oi.orderId = ?"
    );
    $q->execute([$o['id']]);
    $o['items'] = $q->fetchAll();
    $lic = $pdo->prepare("SELECT id, `key`, status, expiresAt FROM `License` WHERE orderId = ? LIMIT 1");
    $lic->execute([$o['id']]);
    $o['license'] = $lic->fetch() ?: null;
    $o['amountVnd'] = (int)($o['totalCents'] ?? 0);
    $o['content'] = $o['reference'] ?? '';
    $o['bankCode'] = $cfg['sepay']['bankCode'] ?? 'VCB';
    $o['accountNumber'] = $cfg['sepay']['accountNumber'] ?? '';
    $o['accountName'] = $cfg['sepay']['accountName'] ?? '';
    json_out($o);
}

if ($path === '/payments/orders' && $method === 'POST') {
    $itemsIn = $body['items'] ?? [];
    if (!is_array($itemsIn) || count($itemsIn) === 0) {
        json_out(['error' => 'EMPTY_CART'], 422);
    }
    $oid = uid();
    $ref = 'ORD-' . strtoupper(substr($oid, 0, 8));
    $now = nowms();
    $subtotal = 0;
    $rows = [];
    foreach ($itemsIn as $it) {
        $pkg = package_row($it['packageId'] ?? '');
        if (!$pkg || !(int)$pkg['isActive']) {
            json_out(['error' => 'INVALID_PACKAGE'], 422);
        }
        $qty = max(1, (int)($it['quantity'] ?? 1));
        $price = (int)$pkg['priceCents'];
        $subtotal += $price * $qty;
        $rows[] = ['p' => $pkg, 'qty' => $qty, 'price' => $price];
    }
    $pdo->beginTransaction();
    try {
        $pdo->prepare(
            "INSERT INTO `Order`
             (id, reference, userId, status, subtotalCents, totalCents, currency, provider, createdAt, updatedAt, idempotencyKey)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        )->execute([
            $oid,
            $ref,
            $u['id'],
            'PENDING',
            $subtotal,
            $subtotal,
            'USD',
            'manual',
            $now,
            $now,
            $body['idempotencyKey'] ?? null,
        ]);
        foreach ($rows as $r) {
            $pdo->prepare(
                "INSERT INTO `OrderItem` (id, orderId, packageId, quantity, unitPriceCents)
                 VALUES (?, ?, ?, ?, ?)"
            )->execute([uid(), $oid, $r['p']['id'], $r['qty'], $r['price']]);
        }
        $pdo->commit();
        json_out(['id' => $oid, 'reference' => $ref, 'totalCents' => $subtotal], 201);
    } catch (Throwable $e) {
        $pdo->rollBack();
        json_out(['error' => $e->getMessage()], 422);
    }
}

if (preg_match('#^/payments/orders/([^/]+)/pay-with-wallet$#', $path, $m) && $method === 'POST') {
    $oid = $m[1];
    $pdo->beginTransaction();
    try {
        $s = $pdo->prepare("SELECT * FROM `Order` WHERE id = ? AND userId = ? FOR UPDATE");
        $s->execute([$oid, $u['id']]);
        $o = $s->fetch();
        if (!$o) {
            throw new RuntimeException('ORDER_NOT_FOUND');
        }
        if ($o['status'] !== 'PENDING') {
            throw new RuntimeException('ORDER_NOT_PENDING');
        }
        $w = ensure_wallet($u['id']);
        $s = $pdo->prepare("SELECT * FROM `Wallet` WHERE id = ? FOR UPDATE");
        $s->execute([$w['id']]);
        $w = $s->fetch();
        if ((int)$w['balanceCents'] < (int)$o['totalCents']) {
            throw new RuntimeException('INSUFFICIENT_BALANCE');
        }
        $bal = (int)$w['balanceCents'] - (int)$o['totalCents'];
        $pdo->prepare("UPDATE `Wallet` SET balanceCents = ?, updatedAt = ? WHERE id = ?")
            ->execute([$bal, nowms(), $w['id']]);
        $pdo->prepare(
            "INSERT INTO `Transaction`
             (id, walletId, orderId, type, amountCents, balanceAfterCents, description, createdAt)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
        )->execute([
            uid(),
            $w['id'],
            $oid,
            'PURCHASE',
            -(int)$o['totalCents'],
            $bal,
            'Order ' . $o['reference'],
            nowms(),
        ]);
        $pdo->prepare(
            "UPDATE `Order` SET status = 'PAID', paidAt = ?, provider = 'wallet', updatedAt = ? WHERE id = ?"
        )->execute([nowms(), nowms(), $oid]);
        $s = $pdo->prepare(
            "SELECT oi.*, p.* FROM `OrderItem` oi
             JOIN `Package` p ON p.id = oi.packageId WHERE oi.orderId = ?"
        );
        $s->execute([$oid]);
        foreach ($s->fetchAll() as $it) {
            for ($i = 0; $i < (int)$it['quantity']; $i++) {
                $pdo->prepare(
                    "INSERT INTO `License`
                     (id, `key`, status, licenseType, ownerId, packageId, orderId,
                      expiresAt, maxDevices, bundleId, createdAt, updatedAt)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
                )->execute([
                    uid(),
                    license_key(),
                    'ACTIVE',
                    $it['licenseType'],
                    $u['id'],
                    $it['id'], // package id from join
                    $oid,
                    date('Y-m-d H:i:s', time() + max(1, (int)$it['durationDays']) * 86400),
                    (int)$it['maxDevices'],
                    $it['bundleId'],
                    nowms(),
                    nowms(),
                ]);
            }
        }
        $pdo->commit();
        json_out(['ok' => true, 'orderId' => $oid]);
    } catch (Throwable $e) {
        $pdo->rollBack();
        json_out(['error' => $e->getMessage()], 422);
    }
}

/* Dashboard */
if ($path === '/dashboard' && $method === 'GET') {
    admin($u);
    $totalUsers = (int)$pdo->query("SELECT COUNT(*) FROM `User`")->fetchColumn();
    $activeLicenses = (int)$pdo->query("SELECT COUNT(*) FROM `License` WHERE status = 'ACTIVE'")->fetchColumn();
    $totalApiRequests = (int)$pdo->query("SELECT COUNT(*) FROM `ApiLog`")->fetchColumn();
    $apiErrors = (int)$pdo->query("SELECT COUNT(*) FROM `ApiLog` WHERE statusCode >= 400")->fetchColumn();
    $apiErrorRate = $totalApiRequests > 0 ? round(($apiErrors / $totalApiRequests) * 100, 2) : 0;
    $totalRevenueCents = (int)$pdo->query("SELECT COALESCE(SUM(totalCents),0) FROM `Order` WHERE status = 'PAID'")->fetchColumn();
    $totalShortenedUrls = (int)$pdo->query("SELECT COUNT(*) FROM `ShortLink`")->fetchColumn();
    $totalLinkClicks = (int)$pdo->query("SELECT COUNT(*) FROM `ShortLinkClick`")->fetchColumn();

    // Charts last 30 days
    $apiChart = $pdo->query(
        "SELECT DATE(createdAt) AS createdAt, COUNT(*) AS cnt
         FROM `ApiLog`
         WHERE createdAt >= DATE_SUB(NOW(), INTERVAL 30 DAY)
         GROUP BY DATE(createdAt) ORDER BY createdAt"
    )->fetchAll();
    $clickChart = $pdo->query(
        "SELECT DATE(clickedAt) AS clickedAt, COUNT(*) AS cnt
         FROM `ShortLinkClick`
         WHERE clickedAt >= DATE_SUB(NOW(), INTERVAL 30 DAY)
         GROUP BY DATE(clickedAt) ORDER BY clickedAt"
    )->fetchAll();

    json_out([
        'stats' => [
            'totalRevenueCents'  => $totalRevenueCents,
            'totalUsers'         => $totalUsers,
            'activeLicenses'     => $activeLicenses,
            'totalApiRequests'   => $totalApiRequests,
            'apiErrorRate'       => $apiErrorRate,
            'totalShortenedUrls' => $totalShortenedUrls,
            'totalLinkClicks'    => $totalLinkClicks,
        ],
        'recentOrders'       => [],
        'recentApiActivity'  => [],
        'recentSystemEvents' => [],
        'charts' => [
            'apiRequests' => array_map(fn($r) => [
                'createdAt' => $r['createdAt'],
                '_count' => ['_all' => (int)$r['cnt']],
            ], $apiChart),
            'linkClicks' => array_map(fn($r) => [
                'clickedAt' => $r['clickedAt'],
                '_count' => ['_all' => (int)$r['cnt']],
            ], $clickChart),
        ],
    ]);
}

/* Shortener */
if ($path === '/shortener/links' && $method === 'GET') {
    [$pg, $lim, $off] = page_limit();
    $s = $pdo->prepare(
        "SELECT l.*,
                (SELECT COUNT(*) FROM `ShortLinkClick` c WHERE c.linkId = l.id) AS clicks
         FROM `ShortLink` l
         WHERE l.ownerId = ?
         ORDER BY l.createdAt DESC LIMIT $lim OFFSET $off"
    );
    $s->execute([$u['id']]);
    $items = $s->fetchAll();
    foreach ($items as &$it) {
        $it['_count'] = ['clicks' => (int)$it['clicks']];
    }
    unset($it);
    json_out(['items' => $items]);
}

if ($path === '/shortener/links' && $method === 'POST') {
    $url = trim((string)($body['targetUrl'] ?? ''));
    if (!filter_var($url, FILTER_VALIDATE_URL) || !preg_match('#^https?://#i', $url)) {
        json_out(['error' => 'INVALID_URL'], 422);
    }
    $code = trim((string)($body['code'] ?? '')) ?: substr(bin2hex(random_bytes(5)), 0, 8);
    $s = $pdo->prepare("SELECT id FROM `ShortLink` WHERE code = ?");
    $s->execute([$code]);
    if ($s->fetch()) {
        json_out(['error' => 'CODE_TAKEN'], 409);
    }
    $id = uid();
    $now = nowms();
    $pdo->prepare(
        "INSERT INTO `ShortLink`
         (id, code, targetUrl, title, status, passwordHash, oneTimeUse, ownerId, createdAt, updatedAt)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    )->execute([
        $id,
        $code,
        $url,
        $body['title'] ?? $code,
        'ACTIVE',
        !empty($body['password']) ? password_hash($body['password'], PASSWORD_DEFAULT) : null,
        !empty($body['oneTimeUse']) ? 1 : 0,
        $u['id'],
        $now,
        $now,
    ]);
    json_out(['id' => $id, 'code' => $code, 'shortUrl' => public_base() . '/s/' . $code], 201);
}

if (preg_match('#^/shortener/links/([^/]+)/analytics$#', $path, $m) && $method === 'GET') {
    $s = $pdo->prepare(
        "SELECT DATE(clickedAt) AS d, COUNT(*) AS n
         FROM `ShortLinkClick`
         WHERE linkId = ?
         GROUP BY DATE(clickedAt) ORDER BY d"
    );
    $s->execute([$m[1]]);
    json_out([
        'byDay' => array_map(fn($x) => [$x['d'], (int)$x['n']], $s->fetchAll()),
    ]);
}

if (preg_match('#^/shortener/links/([^/]+)$#', $path, $m) && $method === 'DELETE') {
    $pdo->prepare("DELETE FROM `ShortLink` WHERE id = ? AND ownerId = ?")
        ->execute([$m[1], $u['id']]);
    json_out(['ok' => true]);
}

if (preg_match('#^/shortener/links/([^/]+)$#', $path, $m) && $method === 'PATCH') {
    $pdo->prepare(
        "UPDATE `ShortLink`
         SET targetUrl = COALESCE(?, targetUrl), title = COALESCE(?, title),
             status = COALESCE(?, status), updatedAt = ?
         WHERE id = ? AND ownerId = ?"
    )->execute([
        $body['targetUrl'] ?? null,
        $body['title'] ?? null,
        $body['status'] ?? null,
        nowms(),
        $m[1],
        $u['id'],
    ]);
    json_out(['ok' => true]);
}

json_out(['error' => 'NOT_FOUND', 'path' => $path], 404);
