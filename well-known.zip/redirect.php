<?php
$code = trim((string)($_GET['code'] ?? ''));
if ($code === '' && preg_match('#/s/([A-Za-z0-9_-]+)#', $_SERVER['REQUEST_URI'] ?? '', $m)) {
    $code = $m[1];
}
$_GET['code'] = $code;
$_SERVER['REQUEST_URI'] = '/s/' . $code;
require __DIR__ . '/api.php';
