<?php
declare(strict_types=1);
ini_set('display_errors', '0');
$privateDir = dirname(__DIR__) . '/private';
if (!is_dir($privateDir)) $privateDir = __DIR__ . '/private';
$configPath = $privateDir . '/config.php';
if (!is_file($configPath)) { http_response_code(503); exit('Not installed'); }
$cfg = require $configPath;
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
$pdo = new PDO(
    sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $cfg['db']['host'], (int)$cfg['db']['port'], $cfg['db']['name']),
    $cfg['db']['user'], $cfg['db']['pass'],
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
);

function uid(): string { return bin2hex(random_bytes(16)); }
function nowms(): string { return date('Y-m-d H:i:s.v'); }
function license_key_gen(PDO $pdo): string {
    do {
        $k = 'DTA-' . strtoupper(bin2hex(random_bytes(4))) . '-' . strtoupper(bin2hex(random_bytes(4))) . '-' . strtoupper(bin2hex(random_bytes(4)));
        $s = $pdo->prepare("SELECT 1 FROM `License` WHERE `key`=? LIMIT 1");
        $s->execute([$k]);
    } while ($s->fetchColumn());
    return $k;
}

// auth
$ok = false;
$qtoken = $_GET['token'] ?? ($_POST['token'] ?? '');
if (!empty($_SESSION['uid'])) {
    $s = $pdo->prepare("SELECT r.name rn FROM `User` u JOIN `Role` r ON r.id=u.roleId WHERE u.id=?");
    $s->execute([$_SESSION['uid']]);
    $ok = in_array($s->fetchColumn(), ['SUPER_ADMIN','ADMIN','STAFF'], true);
}
if (!$ok && $qtoken !== '') {
    $s = $pdo->prepare("SELECT r.name rn FROM AccessToken t JOIN `User` u ON u.id=t.userId JOIN `Role` r ON r.id=u.roleId WHERE t.tokenHash=? AND t.revokedAt IS NULL AND t.expiresAt>NOW()");
    $s->execute([hash('sha256', $qtoken)]);
    $ok = in_array($s->fetchColumn(), ['SUPER_ADMIN','ADMIN','STAFF'], true);
}
if (!$ok) {
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><meta charset=utf-8><p style="font:16px system-ui;padding:2rem">Cần login admin. <a href="/login">/login</a></p>';
    echo '<script>var t=localStorage.getItem("accessToken");if(t)location.replace("?token="+encodeURIComponent(t));</script>';
    exit;
}

$msg = '';
$createdKeys = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['packageId'])) {
    $pkgId = $_POST['packageId'];
    $count = max(1, min(50, (int)($_POST['count'] ?? 1)));
    $days = max(1, (int)($_POST['days'] ?? 30));
    $maxDev = max(1, (int)($_POST['maxDevices'] ?? 1));
    $s = $pdo->prepare("SELECT * FROM `Package` WHERE id=?");
    $s->execute([$pkgId]);
    $pkg = $s->fetch();
    if ($pkg) {
        $now = nowms();
        $expires = date('Y-m-d H:i:s', time() + $days * 86400);
        $owner = $_SESSION['uid'] ?? $pdo->query("SELECT id FROM `User` ORDER BY createdAt LIMIT 1")->fetchColumn();
        for ($i = 0; $i < $count; $i++) {
            $id = uid();
            $key = license_key_gen($pdo);
            $pdo->prepare(
                "INSERT INTO `License` (id,`key`,status,licenseType,ownerId,packageId,expiresAt,maxDevices,bundleId,createdAt,updatedAt)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?)"
            )->execute([$id, $key, 'ACTIVE', $pkg['licenseType'], $owner, $pkgId, $expires, $maxDev, $pkg['bundleId'], $now, $now]);
            $createdKeys[] = $key;
        }
        $msg = 'Đã tạo ' . count($createdKeys) . ' key.';
    } else {
        $msg = 'Package không tồn tại.';
    }
}

$packages = $pdo->query("SELECT id, name, bundleId, durationDays, maxDevices FROM `Package` WHERE isActive=1 ORDER BY createdAt DESC")->fetchAll();
$licenses = $pdo->query(
    "SELECT l.`key`, l.status, l.expiresAt, l.maxDevices, l.bundleId, p.name packageName, l.createdAt
     FROM `License` l LEFT JOIN `Package` p ON p.id=l.packageId
     ORDER BY l.createdAt DESC LIMIT 100"
)->fetchAll();

$private = (string)($cfg['rsa_private_key'] ?? '');
$public = '';
if ($private) {
    $details = @openssl_pkey_get_details(@openssl_pkey_get_private($private));
    $public = is_array($details) ? (string)($details['key'] ?? '') : '';
}
$tokenQ = $qtoken !== '' ? '?token=' . urlencode($qtoken) : '';
header('Content-Type: text/html; charset=utf-8');
?>
<!doctype html>
<html lang="vi"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Quản lý Key — DTA</title>
<style>
body{margin:0;font:14px system-ui;background:#0b1020;color:#e8eefc}
.wrap{max-width:960px;margin:0 auto;padding:16px}
h1,h2{margin:0 0 12px}
.card{background:#111827;border:1px solid #1e293b;border-radius:14px;padding:16px;margin-bottom:16px}
label{display:block;margin:10px 0 4px;color:#94a3b8;font-size:12px}
input,select{width:100%;box-sizing:border-box;padding:10px;border-radius:10px;border:1px solid #334155;background:#0b1020;color:#fff}
button{margin-top:12px;padding:12px 16px;border:0;border-radius:10px;background:#4f46e5;color:#fff;font-weight:600;width:100%}
table{width:100%;border-collapse:collapse;font-size:13px}
td,th{padding:8px;border-bottom:1px solid #1e293b;text-align:left;word-break:break-all}
.ok{background:#064e3b;padding:10px;border-radius:8px;margin-bottom:12px}
.keys{font-family:monospace;background:#020617;padding:10px;border-radius:8px;white-space:pre-wrap}
a{color:#7dd3fc}
textarea{width:100%;min-height:120px;font-family:monospace;font-size:11px;background:#020617;color:#a7f3d0;border:1px solid #334155;border-radius:8px;padding:10px;box-sizing:border-box}
.warn{background:#422006;padding:10px;border-radius:8px;margin-bottom:12px;font-size:13px}
</style>
</head><body>
<div class="wrap">
  <p><a href="/">← Console</a> · <a href="/client-logs.php<?= htmlspecialchars($tokenQ) ?>">Game logs</a></p>
  <h1>Quản lý License Key</h1>

  <div class="card">
    <h2>RSA Public Key (dán vào app)</h2>
    <div class="warn">App báo <b>“Chữ ký response không hợp lệ”</b> = public key trong app <b>không khớp</b> private key trên server. Copy key dưới đây vào APIClient-New.</div>
    <textarea readonly id="rsa"><?= htmlspecialchars($public ?: '(chưa có RSA key — chạy lại install.php và dán private key cũ nếu có)') ?></textarea>
    <button type="button" onclick="navigator.clipboard.writeText(document.getElementById('rsa').value)">Copy public key</button>
  </div>

  <div class="card">
    <h2>Tạo key theo Package</h2>
    <?php if ($msg): ?><div class="ok"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
    <?php if ($createdKeys): ?><div class="keys"><?= htmlspecialchars(implode("\n", $createdKeys)) ?></div><?php endif; ?>
    <form method="post">
      <?php if ($qtoken): ?><input type="hidden" name="token" value="<?= htmlspecialchars($qtoken) ?>"><?php endif; ?>
      <label>Package</label>
      <select name="packageId" required>
        <option value="">— chọn —</option>
        <?php foreach ($packages as $p): ?>
          <option value="<?= htmlspecialchars($p['id']) ?>">
            <?= htmlspecialchars($p['name']) ?> (<?= htmlspecialchars($p['bundleId'] ?: 'any') ?>)
          </option>
        <?php endforeach; ?>
      </select>
      <label>Số lượng key</label>
      <input type="number" name="count" value="1" min="1" max="50">
      <label>Số ngày</label>
      <input type="number" name="days" value="30" min="1">
      <label>Max devices</label>
      <input type="number" name="maxDevices" value="1" min="1">
      <button type="submit">Tạo key ACTIVE</button>
    </form>
  </div>

  <div class="card">
    <h2>Keys gần đây</h2>
    <table>
      <tr><th>Key</th><th>Package</th><th>Status</th><th>Hết hạn</th><th>Bundle</th></tr>
      <?php foreach ($licenses as $l): ?>
      <tr>
        <td><?= htmlspecialchars($l['key']) ?></td>
        <td><?= htmlspecialchars($l['packageName'] ?? '') ?></td>
        <td><?= htmlspecialchars($l['status']) ?></td>
        <td><?= htmlspecialchars($l['expiresAt'] ?? '') ?></td>
        <td><?= htmlspecialchars($l['bundleId'] ?? '') ?></td>
      </tr>
      <?php endforeach; ?>
    </table>
  </div>
</div>
</body></html>
