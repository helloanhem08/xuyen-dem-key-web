<?php
declare(strict_types=1);
/**
 * Native iOS APIClient protocol (libAPIClient 6.1.0 / dtalq).
 * Always HTTP 200 + AES-ECB envelope. Business codes live in JSON.
 */
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Accept, User-Agent');
header('Cache-Control: no-store');
if (!headers_sent()) {
    header_remove('Set-Cookie');
}

$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
$uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$route = trim((string)($_GET['route'] ?? ''));
if ($route === '') {
    $route = basename(rtrim($uri, '/'));
}

error_log('V4 HIT ' . $method . ' ' . $uri . ' route=' . $route . ' ip=' . ($_SERVER['REMOTE_ADDR'] ?? ''));

if ($method === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$start = microtime(true);

function v4_fail(string $message, int $code = 0): never
{
    global $uri, $start;
    client_log($uri, 200, $start, [
        'error' => $message,
        'result_code' => $code ?: null,
        'summary' => 'v4 fail: ' . $message,
        'request' => ['raw_error' => true],
    ]);
    transport_response([
        'success' => false,
        'code' => $code ?: 500,
        'status' => 'invalid',
        'message' => $message,
        'unix' => time(),
        'data' => (object)[],
    ]);
}

function v4_package_row(array $d): ?array
{
    global $pdo;
    $token = '';
    if (isset($d['data']) && is_scalar($d['data'])) {
        $token = trim((string)$d['data']);
    }
    foreach (['package_token', 'packageToken', 'token', 'api_token'] as $f) {
        if ($token === '' && isset($d[$f]) && is_scalar($d[$f])) {
            $token = trim((string)$d[$f]);
        }
    }
    $bundle = strtolower(trim((string)($d['bundle_id'] ?? '')));
    $x = client_common($d);
    $p = is_array($x['package'] ?? null) ? $x['package'] : null;
    return $p;
}

function v4_pkg_payload(?array $p, array $d): array
{
    $name = (string)($p['name'] ?? 'ShopDTA');
    $ver = (string)($p['version'] ?? $p['client_version'] ?? '1.0.0');
    $bundle = strtolower(trim((string)($d['bundle_id'] ?? $p['bundleId'] ?? '')));
    $custom = new stdClass();
    return [
        'id' => $p['id'] ?? 0,
        'name' => $name,
        'clientIdMode' => 'udid',
        'isRealTimeEventEnable' => false,
        'data' => $custom,
        'contactInfo' => '',
        'requireAuth' => true,
        'requireUdid' => (bool)(int)($p['requireUdid'] ?? 1),
        'allowManualUdid' => true,
        'needUpdate' => false,
        'update' => false,
        'maintenance' => false,
        'clientVersion' => (string)($d['client_version'] ?? '6.1.0'),
        'version' => $ver,
        'bundle_id' => $bundle,
        'link' => '',
        'changelog' => '',
        'status' => 'Running',
        'unix' => time(),
    ];
}

function v4_auth_success(int $code, array $license, ?array $package, string $udid, array $d): array
{
    $exp = (string)($license['expiresAt'] ?? $license['expires_at'] ?? 'lifetime');
    $key = (string)($license['key'] ?? $license['license_key'] ?? '');
    $pkgName = (string)($package['name'] ?? $license['packageName'] ?? '');
    $now = time();
    return [
        'success' => true,
        'code' => $code,
        'status' => 'success',
        'unix' => $now,
        'deviceModel' => (string)($d['device_code'] ?? 'iPhone'),
        'ip' => (string)($_SERVER['REMOTE_ADDR'] ?? ''),
        'data' => [
            'id' => $license['id'] ?? 0,
            'key' => $key,
            'udid' => $udid,
            'expiredAt' => $exp,
            'expiredAtLocal' => $exp,
            'time' => $exp,
            'unix' => $now,
            'package' => [
                'id' => $package['id'] ?? '',
                'name' => $pkgName,
                'data' => new stdClass(),
            ],
        ],
        'key' => $key,
        'UDID' => $udid,
        'expired_at' => $exp,
        'expired_at_local' => $exp,
        'device_model' => (string)($d['device_code'] ?? ''),
        'login_ip' => (string)($_SERVER['REMOTE_ADDR'] ?? ''),
        'package_name' => $pkgName,
        'package_data' => new stdClass(),
    ];
}

if ($method !== 'POST') {
    http_response_code(405);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'POST only';
    exit;
}

$raw = (string)file_get_contents('php://input');
error_log('V4 BODY bytes=' . strlen($raw) . ' ua=' . substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 80));

try {
    $d = decrypt_transport($raw);
} catch (Throwable $e) {
    v4_fail($e->getMessage(), 0);
}

$bundle = strtolower(trim((string)($d['bundle_id'] ?? '')));
$udid = trim((string)($d['udid'] ?? $d['uid'] ?? $d['device_id'] ?? ''));

if (!in_array($route, ['package-v3', 'credential-v3', 'key-v3'], true)) {
    v4_fail('Unknown client endpoint', 0);
}

$p = v4_package_row($d);

if ($route === 'package-v3') {
    $data = v4_pkg_payload($p, $d);
    client_log($uri, 200, $start, [
        'bundle_id' => $bundle,
        'udid' => $udid ?: null,
        'device_code' => $d['device_code'] ?? null,
        'result_code' => 200,
        'summary' => 'package-v3 OK name=' . $data['name'] . ' v' . $data['version'],
        'request' => [
            'bundle_id' => $bundle,
            'data' => $d['data'] ?? null,
            'client_version' => $d['client_version'] ?? null,
            'device_code' => $d['device_code'] ?? null,
            'udid' => $udid ?: null,
            'ua' => $_SERVER['HTTP_USER_AGENT'] ?? '',
        ],
    ]);
    transport_response([
        'success' => true,
        'code' => 200,
        'status' => 'success',
        'deviceModel' => (string)($d['device_code'] ?? 'iPhone'),
        'udidIPCheck' => 0,
        'ip' => (string)($_SERVER['REMOTE_ADDR'] ?? ''),
        'unix' => time(),
        'maintenance' => false,
        'update' => false,
        'link' => '',
        'changelog' => '',
        'data' => $data,
    ]);
}

if ($route === 'credential-v3') {
    if ($udid === '') {
        client_log($uri, 200, $start, [
            'bundle_id' => $bundle, 'result_code' => 6400, 'summary' => 'invalid udid',
        ]);
        transport_response([
            'success' => false, 'code' => 6400, 'status' => 'invalid',
            'message' => 'UDID không hợp lệ', 'unix' => time(), 'data' => (object)[],
        ]);
    }
    $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
    if (banned_row($udid, $ip)) {
        transport_response([
            'success' => false, 'code' => 6403, 'status' => 'blocked',
            'message' => 'Thiết bị hoặc IP đã bị khóa', 'unix' => time(), 'data' => (object)[],
        ]);
    }
    global $pdo;
    $s = $pdo->prepare(
        "SELECT l.*, p.name AS packageName, p.bundleId AS packageBundleId
         FROM `License` l
         LEFT JOIN `Package` p ON p.id = l.packageId
         WHERE l.status = 'ACTIVE'
           AND (l.expiresAt IS NULL OR l.expiresAt > ?)
           AND EXISTS (
             SELECT 1 FROM `LicenseActivation` a
             WHERE a.licenseId = l.id AND a.deviceId = ? AND a.active = 1
           )
         ORDER BY l.expiresAt DESC LIMIT 1"
    );
    $s->execute([nowms(), $udid]);
    $l = $s->fetch();
    if ($l) {
        client_log($uri, 200, $start, [
            'bundle_id' => $bundle, 'udid' => $udid, 'key' => $l['key'] ?? null,
            'result_code' => 6200, 'summary' => 'credential-v3 OK',
        ]);
        transport_response(v4_auth_success(6200, $l, $p, $udid, $d));
    }
    client_log($uri, 200, $start, [
        'bundle_id' => $bundle, 'udid' => $udid, 'result_code' => 6404,
        'summary' => 'credential-v3 needs login',
    ]);
    transport_response([
        'success' => false,
        'code' => 6404,
        'status' => 'logout',
        'message' => 'Thiết bị chưa đăng nhập',
        'unix' => time(),
        'data' => (object)[],
    ]);
}

$key = trim((string)($d['key'] ?? $d['license_key'] ?? $d['inputKey'] ?? ''));
$l = $key !== '' ? license_row($key) : null;
if (!$l) {
    client_log($uri, 200, $start, [
        'bundle_id' => $bundle, 'udid' => $udid, 'key' => $key,
        'result_code' => 4000, 'summary' => 'key invalid',
    ]);
    transport_response([
        'success' => false, 'code' => 4000, 'status' => 'invalid',
        'message' => 'Key không hợp lệ', 'unix' => time(), 'data' => (object)[],
    ]);
}
if (in_array((string)$l['status'], ['REVOKED', 'SUSPENDED', 'EXPIRED'], true)
    || ($l['expiresAt'] && strtotime((string)$l['expiresAt']) < time())) {
    client_log($uri, 200, $start, [
        'bundle_id' => $bundle, 'udid' => $udid, 'key' => $key,
        'result_code' => 4001, 'summary' => 'key expired',
    ]);
    transport_response([
        'success' => false, 'code' => 4001, 'status' => 'expired',
        'message' => 'Key đã hết hạn', 'unix' => time(), 'data' => (object)[],
    ]);
}
$assigned = strtolower(trim((string)($l['bundleId'] ?: $l['packageBundleId'] ?: '')));
if ($assigned !== '' && $bundle !== '' && $assigned !== $bundle) {
    transport_response([
        'success' => false, 'code' => 4000, 'status' => 'invalid',
        'message' => 'Key không thuộc package này', 'unix' => time(), 'data' => (object)[],
    ]);
}

global $pdo;
$pdo->beginTransaction();
try {
    $q = $pdo->prepare("SELECT * FROM `License` WHERE id = ? FOR UPDATE");
    $q->execute([$l['id']]);
    $l = $q->fetch() ?: $l;
    $q = $pdo->prepare("SELECT COUNT(*) FROM `LicenseActivation` WHERE licenseId = ? AND active = 1");
    $q->execute([$l['id']]);
    $active = (int)$q->fetchColumn();
    $q = $pdo->prepare("SELECT id FROM `LicenseActivation` WHERE licenseId = ? AND deviceId = ? AND active = 1");
    $q->execute([$l['id'], $udid]);
    $existing = $q->fetch();
    if (!$existing && $udid !== '' && $active >= (int)$l['maxDevices']) {
        $pdo->rollBack();
        transport_response([
            'success' => false, 'code' => 4002, 'status' => 'exceeded_count',
            'message' => 'Key đã vượt quá số thiết bị', 'unix' => time(), 'data' => (object)[],
        ]);
    }
    if (!$existing && $udid !== '') {
        $pdo->prepare(
            "INSERT INTO `LicenseActivation`
             (id, licenseId, deviceId, deviceName, active, activatedAt)
             VALUES (?, ?, ?, ?, 1, ?)
             ON DUPLICATE KEY UPDATE
               active = 1, deactivatedAt = NULL,
               deviceName = VALUES(deviceName), activatedAt = VALUES(activatedAt)"
        )->execute([uid(), $l['id'], $udid, (string)($d['device_code'] ?? $udid), nowms()]);
    }
    $pdo->prepare(
        "UPDATE `License` SET status = 'ACTIVE', activatedAt = COALESCE(activatedAt, ?), updatedAt = ? WHERE id = ?"
    )->execute([nowms(), nowms(), $l['id']]);
    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    v4_fail($e->getMessage(), 6402);
}

client_log($uri, 200, $start, [
    'bundle_id' => $bundle, 'udid' => $udid, 'key' => $l['key'] ?? $key,
    'result_code' => 4200, 'summary' => 'key-v3 activated',
]);
transport_response(v4_auth_success(4200, $l, $p, $udid, $d));
