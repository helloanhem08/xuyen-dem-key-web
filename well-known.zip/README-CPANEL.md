# ShopDTA Atelier — cPanel

Bản UI mới. RSA **tạo mới** lúc `/install.php`. Dán public key vào dylib sau.

## Upload

1. Giữ `private/` nếu đang chạy live (hoặc xóa `install.lock` để cài lại).
2. Xóa `assets/` SPA cũ và `index.html` cũ.
3. Upload: `index.html`, `static/`, `api.php`, `install.php`, `.htaccess`, `health.php`, `database.sql`.
4. Mở `/install.php` — điền MySQL + admin + SePay. Để trống RSA = tạo cặp mới.
5. Copy public key hiện ra, thay vào `APIClientConfig.h` khi sẵn sàng.
6. Transport mặc định giữ `h4HQn0A7kFN6xpydECEVp3H5oCc1kF6p` để dylib cũ còn nói chuyện.

## UDID enrollment (bước 1 của UI key)

1. App `GET/POST /udid/enroll` → `{ token, profileUrl }`
2. User tải `/udid/profile/{token}.mobileconfig` → Cài đặt iOS
3. iPhone POST UDID tới `/udid/callback/{token}`
4. App poll `GET /udid/status/{token}` đến `ready: true` + `udid`
5. Mới hiện form nhập key. `key-v3` gửi `enroll_token` trong `data`
6. Server gắn **UDID thật** với key (không tin UDID client tự khai)

Bật bắt buộc: Điều hành → Thiết bị → `requireEnrolled`  
Mã `6405` = chưa enroll. Mặc định **tắt** để dylib cũ còn chạy; bật sau khi ra UI mới.

`POST /api/webhooks/sepay`  
Header: `Authorization: Apikey TOKEN`

## Tài khoản demo (preview)

Admin: admin@shopdta.site / ShopDTA!2026  
User: user@shopdta.site / User1234!
