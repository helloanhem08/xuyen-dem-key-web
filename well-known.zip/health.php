<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

$privateDir = dirname(__DIR__) . '/private';
if (!is_dir($privateDir)) {
    $privateDir = __DIR__ . '/private';
}
$configPath = $privateDir . '/config.php';

if (!is_file($configPath)) {
    http_response_code(503);
    echo json_encode(['status' => 'not_installed']);
    exit;
}
try {
    $cfg = require $configPath;
    $pdo = new PDO(
        sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $cfg['db']['host'], (int)$cfg['db']['port'], $cfg['db']['name']),
        $cfg['db']['user'],
        $cfg['db']['pass'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    $pdo->query('SELECT 1');
    echo json_encode(['status' => 'ok', 'service' => 'dta-cloud-platform', 'time' => gmdate('c')], JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'db']);
}
