<?php
$_GET['route'] = 'key-v3'; require dirname(__DIR__, 3) . '/api.php';
