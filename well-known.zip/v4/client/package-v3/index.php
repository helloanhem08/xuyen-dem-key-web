<?php
$_GET['route'] = 'package-v3'; require dirname(__DIR__, 3) . '/api.php';
