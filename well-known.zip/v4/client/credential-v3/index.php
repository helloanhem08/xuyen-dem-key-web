<?php
$_GET['route'] = 'credential-v3'; require dirname(__DIR__, 3) . '/api.php';
