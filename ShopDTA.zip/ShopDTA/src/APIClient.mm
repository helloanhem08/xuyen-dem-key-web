#import "APIClientInternal.h"
#import <sys/utsname.h>
#import <Security/Security.h>

void SDTALog(NSString *format, ...) { va_list a; va_start(a,format); NSString *s=[[NSString alloc] initWithFormat:format arguments:a]; va_end(a); NSLog(@"[ShopDTA APIClient] %@",s); }
NSString *SDTASafeString(id v) { if ([v isKindOfClass:NSString.class]) return v; if ([v isKindOfClass:NSNumber.class]) return [(NSNumber *)v stringValue]; return @""; }
NSInteger SDTAInteger(id v, NSInteger f) { return [v respondsToSelector:@selector(integerValue)]?[v integerValue]:f; }
BOOL SDTABool(id v, BOOL f) { return [v respondsToSelector:@selector(boolValue)]?[v boolValue]:f; }
NSString *SDTAJSONString(NSDictionary *d) { NSData *x=[NSJSONSerialization dataWithJSONObject:d?:@{} options:0 error:nil]; return x?[[NSString alloc]initWithData:x encoding:NSUTF8StringEncoding]:@"{}"; }
NSString *SDTARedactedKey(NSString *k) { if (k.length<=8) return k.length?@"••••":@""; return [NSString stringWithFormat:@"%@••••%@",[k substringToIndex:4],[k substringFromIndex:k.length-4]]; }
static NSString *const SDTAUDIDService=@"ShopDTA.APIClient.Device";
static NSString *SDTAKeychainUDID(void) { NSDictionary *q=@{(__bridge id)kSecClass:(__bridge id)kSecClassGenericPassword,(__bridge id)kSecAttrService:SDTAUDIDService,(__bridge id)kSecReturnData:@YES,(__bridge id)kSecMatchLimit:(__bridge id)kSecMatchLimitOne}; CFTypeRef result=NULL; OSStatus s=SecItemCopyMatching((__bridge CFDictionaryRef)q,&result); if(s!=errSecSuccess)return @""; NSData *d=CFBridgingRelease(result); return [[NSString alloc]initWithData:d encoding:NSUTF8StringEncoding] ?: @""; }
static void SDTAStoreKeychainUDID(NSString *value) { NSData *d=[value dataUsingEncoding:NSUTF8StringEncoding]; NSDictionary *q=@{(__bridge id)kSecClass:(__bridge id)kSecClassGenericPassword,(__bridge id)kSecAttrService:SDTAUDIDService}; NSDictionary *a=@{(__bridge id)kSecValueData:d,(__bridge id)kSecAttrAccessible:(__bridge id)kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly}; if(SecItemUpdate((__bridge CFDictionaryRef)q,(__bridge CFDictionaryRef)a)==errSecItemNotFound){NSMutableDictionary *add=[q mutableCopy];[add addEntriesFromDictionary:a];SecItemAdd((__bridge CFDictionaryRef)add,NULL);} }

@implementation SDTAState
+ (instancetype)shared { static SDTAState *s; static dispatch_once_t once; dispatch_once(&once, ^{ s=[SDTAState new]; s.token=APICLIENT_PACKAGE_TOKEN; s.language=@"vi"; s.contactButtonTitle=@"Liên hệ"; s.deviceModel=[s currentModel]; s.packageData=@{}; s.requireUdid=YES; s.allowManualUdid=YES; s.ui=[SDTAUI new]; }); return s; }
- (NSString *)currentModel { struct utsname u; uname(&u); return [NSString stringWithUTF8String:u.machine] ?: @"iPhone"; }
- (NSString *)ensureStableUDID {
    if (self.udid.length) { SDTAStoreKeychainUDID(self.udid); return self.udid; }
    NSString *saved=SDTAKeychainUDID(); if (saved.length) { self.udid=saved; return saved; }
    saved=[[NSUserDefaults standardUserDefaults] stringForKey:APICLIENT_UDID_DEFAULTS_KEY]; if (saved.length) { self.udid=saved; SDTAStoreKeychainUDID(saved); return saved; }
    NSString *v=[UIDevice currentDevice].identifierForVendor.UUIDString; if (!v.length) v=NSUUID.UUID.UUIDString;
    self.udid=v; SDTAStoreKeychainUDID(v); return v;
}
- (NSDictionary *)baseRequest {
    NSTimeInterval ms=[[NSDate date] timeIntervalSince1970]*1000.0; NSString *ts=[NSString stringWithFormat:@"%.6f",ms];
    NSString *nonce=NSUUID.UUID.UUIDString.lowercaseString;
    NSString *bundle=NSBundle.mainBundle.bundleIdentifier ?: @"";
    NSString *token=self.token.length?self.token:APICLIENT_PACKAGE_TOKEN;
    return @{ @"data": token, @"timestamp":ts, @"nonce":nonce, @"device_code":self.deviceModel.length?self.deviceModel:@"iPhone", @"client_version":APICLIENT_VERSION, @"bundle_id":bundle };
}
- (void)firePaidCallbackOnce { if (self.paidCallbackFired) return; self.paidCallbackFired=YES; apiclient_callback cb=self.paidCallback; self.paidCallback=nil; if (cb) dispatch_async(dispatch_get_main_queue(), cb); }
@end

static void SDTAApplyCommon(NSDictionary *p) {
    SDTAState *s=SDTAState.shared; NSString *model=SDTASafeString(p[@"deviceModel"]); if(model.length)s.deviceModel=model; NSString *ip=SDTASafeString(p[@"ip"]); if(ip.length)s.loginIP=ip;
    NSDictionary *data=[p[@"data"] isKindOfClass:NSDictionary.class]?p[@"data"]:@{};
    if (data.count) s.packageData=data;
    NSString *name=SDTASafeString(p[@"name"]); if(!name.length) name=SDTASafeString(data[@"name"]); if(name.length)s.packageName=name;
    NSString *ver=SDTASafeString(p[@"version"]); if(!ver.length)ver=SDTASafeString(data[@"version"]); if(!ver.length)ver=SDTASafeString(data[@"clientVersion"]); if(ver.length)s.packageVersion=ver;
    if (p[@"requireUdid"] || data[@"requireUdid"]) s.requireUdid=SDTABool(p[@"requireUdid"], SDTABool(data[@"requireUdid"], YES));
    s.allowManualUdid=SDTABool(p[@"allowManualUdid"], SDTABool(data[@"allowManualUdid"], YES));
}
static void SDTAApplyLicense(NSDictionary *p, NSString *inputKey) {
    SDTAState *s=SDTAState.shared; NSDictionary *d=[p[@"data"] isKindOfClass:NSDictionary.class]?p[@"data"]:@{};
    NSString *k=SDTASafeString(d[@"key"]); if(!k.length)k=SDTASafeString(p[@"key"]); if(!k.length)k=inputKey ?: @""; s.licenseKey=k;
    NSArray *expKeys=@[@"expiredAt",@"expired_at",@"expired"]; for(NSString *x in expKeys){ NSString *v=SDTASafeString(d[x]); if(!v.length)v=SDTASafeString(p[x]); if(v.length){s.expiredAt=v;break;} }
    NSString *local=SDTASafeString(d[@"expiredAtLocal"]); if(!local.length)local=SDTASafeString(p[@"expiredAtLocal"]); s.expiredAtLocal=local;
    SDTAApplyCommon(p);
}
NSString *SDTABusinessMessage(NSInteger code, NSDictionary *p) {
    NSString *server=SDTASafeString(p[@"message"]); if(!server.length)server=SDTASafeString(p[@"msg"]);
    switch(code){ case 6400:return @"UDID không hợp lệ hoặc không khớp thiết bị."; case 6401:return @"Phiên đăng nhập đã hết hạn."; case 6402:return @"Hệ thống xác thực đang gặp lỗi."; case 6403:return @"Thiết bị hoặc tài khoản đã bị khóa."; case 6404:return @"Thiết bị chưa đăng nhập. Vui lòng nhập license key."; case 4000:return @"License key không hợp lệ."; case 4001:return @"License key đã hết hạn."; case 4002:return @"License key đã vượt quá số thiết bị cho phép."; case 4003:return @"License key đã bị vô hiệu hóa."; default:return server.length?server:[NSString stringWithFormat:@"Máy chủ trả mã nghiệp vụ %ld.",(long)code]; }
}

void SDTAHandlePackage(void (^completion)(BOOL,NSError *)) {
    [[SDTANetwork shared] postPath:APICLIENT_PACKAGE_PATH json:[SDTAState.shared baseRequest] completion:^(NSDictionary *p,NSError *e,NSInteger h){
        if(e||!p){completion(NO,e);return;} SDTAApplyCommon(p); NSInteger code=SDTAInteger(p[@"code"],-1); BOOL success=SDTABool(p[@"success"],code==200);
        NSDictionary *d=[p[@"data"] isKindOfClass:NSDictionary.class]?p[@"data"]:@{}; BOOL maintenance=SDTABool(p[@"maintenance"],SDTABool(d[@"maintenance"],NO)); BOOL update=SDTABool(p[@"update"],SDTABool(d[@"needUpdate"],SDTABool(d[@"update"],NO)));
        if(!success||code!=200){completion(NO,[SDTAError errorWithKind:SDTAErrorBusiness message:SDTABusinessMessage(code,p) detail:nil]);return;}
        if(maintenance){completion(NO,[SDTAError errorWithKind:SDTAErrorBusiness message:@"Hệ thống đang bảo trì. Vui lòng thử lại sau." detail:nil]);return;}
        if(update){ NSString *cl=SDTASafeString(d[@"changelog"]); completion(NO,[SDTAError errorWithKind:SDTAErrorBusiness message:@"Ứng dụng/client cần cập nhật trước khi tiếp tục." detail:cl]);return; }
        completion(YES,nil);
    }];
}
void SDTAHandleCredential(void (^completion)(BOOL,BOOL,NSError *)) {
    NSMutableDictionary *r=[[SDTAState.shared baseRequest] mutableCopy]; r[@"udid"]=[SDTAState.shared ensureStableUDID];
    [[SDTANetwork shared] postPath:APICLIENT_CREDENTIAL_PATH json:r completion:^(NSDictionary *p,NSError *e,NSInteger h){
        if(e||!p){completion(NO,NO,e);return;} SDTAApplyCommon(p); NSInteger code=SDTAInteger(p[@"code"],-1);
        if(code==6200){SDTAApplyLicense(p,nil);completion(YES,NO,nil);return;} if(code==6404||code==6400||code==6401){completion(NO,YES,nil);return;}
        completion(NO,NO,[SDTAError errorWithKind:SDTAErrorBusiness message:SDTABusinessMessage(code,p) detail:nil]);
    }];
}
void SDTAHandleLogin(NSString *key, void (^completion)(BOOL,NSError *)) {
    NSMutableDictionary *r=[[SDTAState.shared baseRequest] mutableCopy]; r[@"udid"]=[SDTAState.shared ensureStableUDID]; r[@"key"]=key ?: @"";
    [[SDTANetwork shared] postPath:APICLIENT_KEY_PATH json:r completion:^(NSDictionary *p,NSError *e,NSInteger h){
        if(e||!p){completion(NO,e);return;} NSInteger code=SDTAInteger(p[@"code"],-1); if(code==4200){SDTAApplyLicense(p,key);completion(YES,nil);return;}
        completion(NO,[SDTAError errorWithKind:SDTAErrorBusiness message:SDTABusinessMessage(code,p) detail:nil]);
    }];
}

static void SDTALoginUI(void);
static void SDTAStartPaidFlow(void) {
    SDTAState *s=SDTAState.shared; [s.ui showInitializing:@"Package initializing…"];
    SDTAHandlePackage(^(BOOL ok,NSError *e){
        if(!ok){[s.ui showErrorTitle:@"Không thể khởi tạo" message:e.localizedDescription retry:^{SDTAStartPaidFlow();}];return;}
        NSDictionary *d=s.packageData; BOOL requireAuth=SDTABool(d[@"requireAuth"],YES);
        if(!requireAuth){[s.ui showSuccess];[s firePaidCallbackOnce];return;}
        [s.ui showInitializing:@"Đang kiểm tra thiết bị…"];
        SDTAHandleCredential(^(BOOL auth,BOOL login,NSError *ce){ if(auth){[s.ui showSuccess];[s firePaidCallbackOnce];} else if(login){SDTALoginUI();} else {[s.ui showErrorTitle:@"Xác thực thiết bị thất bại" message:ce.localizedDescription retry:^{SDTAStartPaidFlow();}];} });
    });
}
static void SDTADoLogin(void) {
    SDTAState *s=SDTAState.shared;
    [s.ui showLoginWithMessage:nil submit:^(NSString *key){
        SDTAHandleLogin(key,^(BOOL ok,NSError *e){
            if(ok){[s.ui showSuccess];[s firePaidCallbackOnce];}
            else {[s.ui showLoginWithMessage:e.localizedDescription submit:^(NSString *k2){
                [s.ui showInitializing:@"Đang xác thực license…"];
                SDTAHandleLogin(k2,^(BOOL ok2,NSError *e2){
                    if(ok2){[s.ui showSuccess];[s firePaidCallbackOnce];}
                    else { [s.ui showErrorTitle:@"License không hợp lệ" message:e2.localizedDescription retry:^{SDTADoLogin();}]; }
                });
            }];}
        });
    }];
}
static void SDTALoginUI(void) {
    SDTAState *s=SDTAState.shared;
    if (!s.requireUdid) { [s ensureStableUDID]; SDTADoLogin(); return; }
    NSString *saved=[[NSUserDefaults standardUserDefaults] stringForKey:@"ShopDTA.enrolledUDID"];
    if (saved.length) { s.udid=saved; SDTADoLogin(); return; }
    [s.ui showUDIDThen:^{ SDTADoLogin(); }];
}

static NSString *S(const char *c){ return c?[NSString stringWithUTF8String:c]:@""; }
extern "C" {
void apiclient_set_token(const char* v){SDTAState.shared.token=S(v);} void apiclient_set_udid(const char* v){SDTAState.shared.udid=S(v); if(SDTAState.shared.udid.length)SDTAStoreKeychainUDID(SDTAState.shared.udid);}
void apiclient_set_language(const char* v){SDTAState.shared.language=S(v);} void apiclient_set_contact_button_title(const char* v){SDTAState.shared.contactButtonTitle=S(v);} void apiclient_set_description(const char* v){SDTAState.shared.customDescription=S(v);}
void apiclient_hide_ui(bool v){SDTAState.shared.hideUI=v;} void apiclient_strict_mode(bool v){SDTAState.shared.strictMode=v;} void apiclient_silent_mode(bool v){SDTAState.shared.silentMode=v;} void apiclient_show_udid_guide(bool v){SDTAState.shared.showUDIDGuide=v;} void apiclient_set_window_mode(int v){SDTAState.shared.windowMode=v;}
void apiclient_paid(apiclient_callback cb){dispatch_async(dispatch_get_main_queue(),^{SDTAState.shared.paidCallback=[cb copy];SDTAState.shared.paidCallbackFired=NO;[SDTAState.shared ensureStableUDID];SDTAStartPaidFlow();});}
const char* apiclient_get_key(void){return SDTAState.shared.licenseKey.UTF8String ?: "";} const char* apiclient_get_udid(void){return [SDTAState.shared ensureStableUDID].UTF8String ?: "";} const char* apiclient_get_expired_at(void){return SDTAState.shared.expiredAt.UTF8String ?: "";} const char* apiclient_get_expired_at_local(void){return SDTAState.shared.expiredAtLocal.UTF8String ?: "";} const char* apiclient_get_device_model(void){return SDTAState.shared.deviceModel.UTF8String ?: "";} const char* apiclient_get_login_ip(void){return SDTAState.shared.loginIP.UTF8String ?: "";} const char* apiclient_get_package_name(void){return SDTAState.shared.packageName.UTF8String ?: "";}
const char* apiclient_get_package_data(const char* key){ static NSString *out; id v=SDTAState.shared.packageData[S(key)]; if([v isKindOfClass:NSString.class]) out=v; else if(v){ NSData*d=[NSJSONSerialization isValidJSONObject:v]?[NSJSONSerialization dataWithJSONObject:v options:0 error:nil]:nil; out=d?[[NSString alloc]initWithData:d encoding:NSUTF8StringEncoding]:[v description]; } else out=@""; return out.UTF8String ?: ""; }
void apiclient_on_check_package(apiclient_dict_callback success, apiclient_dict_callback failure){ SDTAHandlePackage(^(BOOL ok,NSError*e){NSDictionary*d=ok?@{ @"success":@YES,@"code":@200,@"data":SDTAState.shared.packageData?:@{} }:@{ @"success":@NO,@"error":e.localizedDescription?:@"unknown"}; NSString*j=SDTAJSONString(d); if(ok&&success)success(j.UTF8String); else if(!ok&&failure)failure(j.UTF8String);});}
void apiclient_on_check_device(apiclient_dict_callback success, apiclient_dict_callback failure){ SDTAHandleCredential(^(BOOL auth,BOOL login,NSError*e){NSDictionary*d=auth?@{@"success":@YES,@"code":@6200}:@{@"success":@NO,@"needsLogin":@(login),@"error":e.localizedDescription?:@""};NSString*j=SDTAJSONString(d);if(auth&&success)success(j.UTF8String);else if(!auth&&failure)failure(j.UTF8String);});}
void apiclient_on_login(const char* inputKey, apiclient_dict_callback success, apiclient_dict_callback failure){NSString*k=S(inputKey);SDTAHandleLogin(k,^(BOOL ok,NSError*e){NSDictionary*d=ok?@{@"success":@YES,@"code":@4200}:@{@"success":@NO,@"error":e.localizedDescription?:@"unknown"};NSString*j=SDTAJSONString(d);if(ok&&success)success(j.UTF8String);else if(!ok&&failure)failure(j.UTF8String);});}
}
