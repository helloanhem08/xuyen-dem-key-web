#ifndef APICLIENT_INTERNAL_H
#define APICLIENT_INTERNAL_H

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "../include/APIClient.h"
#import "../include/APIClientConfig.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, SDTAErrorKind) {
    SDTAErrorHTTP = 1,
    SDTAErrorTransport,
    SDTAErrorRSA,
    SDTAErrorSignature,
    SDTAErrorPayloadAES,
    SDTAErrorJSON,
    SDTAErrorBusiness
};

@interface SDTAError : NSError
+ (instancetype)errorWithKind:(SDTAErrorKind)kind message:(NSString *)message detail:(nullable NSString *)detail;
@end

@interface SDTACrypto : NSObject
+ (nullable NSData *)AES256ECBEncrypt:(NSData *)data error:(NSError **)error;
+ (nullable NSData *)AES256ECBDecrypt:(NSData *)data error:(NSError **)error;
+ (nullable NSDictionary *)decodeResponseBody:(NSData *)body error:(NSError **)error;
+ (nullable SecKeyRef)copyPublicKey CF_RETURNS_RETAINED;
@end

@interface SDTANetwork : NSObject
+ (instancetype)shared;
- (void)postPath:(NSString *)path json:(NSDictionary *)json completion:(void (^)(NSDictionary * _Nullable payload, NSError * _Nullable error, NSInteger httpStatus))completion;
- (void)getHealth:(void (^)(NSDictionary * _Nullable json, NSError * _Nullable error, NSInteger httpStatus))completion;
- (void)jsonGET:(NSString *)path completion:(void (^)(NSDictionary * _Nullable json, NSError * _Nullable error, NSInteger httpStatus))completion;
- (void)jsonPOST:(NSString *)path json:(NSDictionary *)json completion:(void (^)(NSDictionary * _Nullable json, NSError * _Nullable error, NSInteger httpStatus))completion;
@end

@class SDTAUI;

@interface SDTAState : NSObject
@property(nonatomic, copy) NSString *token;
@property(nonatomic, copy) NSString *udid;
@property(nonatomic, copy) NSString *language;
@property(nonatomic, copy) NSString *contactButtonTitle;
@property(nonatomic, copy) NSString *customDescription;
@property(nonatomic) BOOL hideUI;
@property(nonatomic) BOOL strictMode;
@property(nonatomic) BOOL silentMode;
@property(nonatomic) BOOL showUDIDGuide;
@property(nonatomic) NSInteger windowMode;
@property(nonatomic, copy) NSString *licenseKey;
@property(nonatomic, copy) NSString *expiredAt;
@property(nonatomic, copy) NSString *expiredAtLocal;
@property(nonatomic, copy) NSString *deviceModel;
@property(nonatomic, copy) NSString *loginIP;
@property(nonatomic, copy) NSString *packageName;
@property(nonatomic, copy) NSString *packageVersion;
@property(nonatomic, copy) NSString *enrollToken;
@property(nonatomic) BOOL requireUdid;
@property(nonatomic) BOOL allowManualUdid;
@property(nonatomic, copy) NSDictionary *packageData;
@property(nonatomic, copy, nullable) apiclient_callback paidCallback;
@property(nonatomic) BOOL paidCallbackFired;
@property(nonatomic, strong) SDTAUI *ui;
+ (instancetype)shared;
- (NSString *)ensureStableUDID;
- (NSDictionary *)baseRequest;
- (void)firePaidCallbackOnce;
@end

@interface SDTAUI : NSObject
- (void)showInitializing:(NSString *)text;
- (void)showErrorTitle:(NSString *)title message:(NSString *)message retry:(nullable dispatch_block_t)retry;
- (void)showLoginWithMessage:(nullable NSString *)message submit:(void (^)(NSString *key))submit;
- (void)showUDIDThen:(void (^)(void))next;
- (void)showManualUDID:(void (^)(void))next;
- (void)showSuccess;
- (void)dismiss;
@end

void SDTALog(NSString *format, ...) NS_FORMAT_FUNCTION(1,2);
NSString *SDTAJSONString(NSDictionary *dict);
NSString *SDTASafeString(id value);
NSInteger SDTAInteger(id value, NSInteger fallback);
BOOL SDTABool(id value, BOOL fallback);
NSString *SDTARedactedKey(NSString *key);
NSString *SDTABusinessMessage(NSInteger code, NSDictionary *payload);
void SDTAHandlePackage(void (^completion)(BOOL ok, NSError * _Nullable error));
void SDTAHandleCredential(void (^completion)(BOOL authenticated, BOOL needsLogin, NSError * _Nullable error));
void SDTAHandleLogin(NSString *key, void (^completion)(BOOL authenticated, NSError * _Nullable error));

NS_ASSUME_NONNULL_END
#endif
