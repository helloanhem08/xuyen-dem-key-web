#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "APIClient.h"

__attribute__((constructor))
static void ShopDTALoaderEntry(void) {
    @autoreleasepool {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            apiclient_set_token("shopdta");
            apiclient_set_language("vi");
            apiclient_strict_mode(false);
            apiclient_silent_mode(false);
            apiclient_show_udid_guide(true);
            apiclient_set_window_mode(0);
            apiclient_paid(^{
                NSLog(@"[ShopDTA] license OK");
            });
        });
    }
}
