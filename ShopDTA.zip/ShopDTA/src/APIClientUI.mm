#import "APIClientInternal.h"
#import <QuartzCore/QuartzCore.h>
#import <stdlib.h>

static const NSTimeInterval SDTACountdownSeconds = 59.0;
static UIColor *SDTAGold(void){ return [UIColor colorWithRed:0.84 green:0.78 blue:0.66 alpha:1]; }
static UIColor *SDTACream(void){ return [UIColor colorWithRed:0.94 green:0.91 blue:0.84 alpha:1]; }

@interface SDTAUI () <UITextFieldDelegate>
@property(nonatomic,strong) UIView *root;
@property(nonatomic,strong) UIView *card;
@property(nonatomic,strong) UIStackView *stack;
@property(nonatomic,strong) NSLayoutConstraint *cardBottom;
@property(nonatomic,strong) NSLayoutConstraint *cardWidth;
@property(nonatomic,strong) UILabel *kickerLabel;
@property(nonatomic,strong) UILabel *titleLabel;
@property(nonatomic,strong) UILabel *metaLabel;
@property(nonatomic,strong) UILabel *messageLabel;
@property(nonatomic,strong) UIActivityIndicatorView *spinner;
@property(nonatomic,strong) UITextField *keyField;
@property(nonatomic,strong) UIButton *primaryButton;
@property(nonatomic,strong) UIButton *secondaryButton;
@property(nonatomic,copy) dispatch_block_t retryBlock;
@property(nonatomic,copy) void (^submitBlock)(NSString *);
@property(nonatomic,copy) void (^udidNext)(void);
@property(nonatomic,strong) UILabel *countdownLabel;
@property(nonatomic,strong) UILabel *statusLabel;
@property(nonatomic) dispatch_source_t countdownTimer;
@property(nonatomic) dispatch_source_t pollTimer;
@property(nonatomic) NSTimeInterval countdownDeadline;
@property(nonatomic) BOOL backgrounded;
@property(nonatomic,copy) NSString *profileURL;
@property(nonatomic,copy) NSString *statusURL;
@property(nonatomic) BOOL udidEntryMode;
@property(nonatomic) CGFloat kbH;
@end

@implementation SDTAUI
- (void)ensureView {
    if (self.root.superview) return;
    UIWindow *w = nil;
    UIApplication *app = UIApplication.sharedApplication;
    for (UIScene *scene in app.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class]) continue;
        UIWindowScene *windowScene = (UIWindowScene *)scene;
        for (UIWindow *candidate in windowScene.windows) {
            if (candidate.isKeyWindow) { w = candidate; break; }
            if (!w && !candidate.hidden && candidate.alpha > 0.0) w = candidate;
        }
        if (w && w.isKeyWindow) break;
    }
    if (!w) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(0.35*NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ [self ensureView]; });
        return;
    }
    UIView *root=[UIView new];
    root.translatesAutoresizingMaskIntoConstraints=NO;
    root.backgroundColor=[UIColor colorWithWhite:0 alpha:0.55];
    UIView *card=[UIView new];
    card.translatesAutoresizingMaskIntoConstraints=NO;
    card.backgroundColor=[UIColor colorWithRed:0.04 green:0.04 blue:0.035 alpha:0.96];
    card.layer.cornerRadius=22;
    card.layer.borderWidth=1;
    card.layer.borderColor=SDTAGold().CGColor;
    card.clipsToBounds=YES;
    [root addSubview:card];
    [w addSubview:root];
    self.root=root; self.card=card;

    UILayoutGuide *safe=w.safeAreaLayoutGuide;
    self.cardBottom=[card.bottomAnchor constraintLessThanOrEqualToAnchor:root.bottomAnchor constant:-12];
    self.cardWidth=[card.widthAnchor constraintEqualToAnchor:root.widthAnchor constant:-24];
    self.cardWidth.priority=UILayoutPriorityDefaultHigh;
    NSLayoutConstraint *maxW=[card.widthAnchor constraintLessThanOrEqualToConstant:440];
    NSLayoutConstraint *minW=[card.widthAnchor constraintGreaterThanOrEqualToConstant:260];
    minW.priority=UILayoutPriorityDefaultLow;
    NSLayoutConstraint *centerY=[card.centerYAnchor constraintEqualToAnchor:root.centerYAnchor];
    centerY.priority=250;
    [NSLayoutConstraint activateConstraints:@[
        [root.topAnchor constraintEqualToAnchor:w.topAnchor],
        [root.leadingAnchor constraintEqualToAnchor:w.leadingAnchor],
        [root.trailingAnchor constraintEqualToAnchor:w.trailingAnchor],
        [root.bottomAnchor constraintEqualToAnchor:w.bottomAnchor],
        [card.centerXAnchor constraintEqualToAnchor:root.centerXAnchor],
        [card.leadingAnchor constraintGreaterThanOrEqualToAnchor:root.leadingAnchor constant:12],
        [card.trailingAnchor constraintLessThanOrEqualToAnchor:root.trailingAnchor constant:-12],
        [card.topAnchor constraintGreaterThanOrEqualToAnchor:safe.topAnchor constant:8],
        self.cardBottom, self.cardWidth, maxW, minW, centerY,
    ]];
    NSNotificationCenter *nc=NSNotificationCenter.defaultCenter;
    [nc addObserver:self selector:@selector(kb:) name:UIKeyboardWillChangeFrameNotification object:nil];
    [nc addObserver:self selector:@selector(kb:) name:UIKeyboardWillHideNotification object:nil];
    [self makeStack];
}
- (void)makeStack {
    for (UIView *v in self.card.subviews) [v removeFromSuperview];
    UIStackView *stack=[UIStackView new];
    stack.axis=UILayoutConstraintAxisVertical;
    stack.alignment=UIStackViewAlignmentFill;
    stack.spacing=10;
    stack.translatesAutoresizingMaskIntoConstraints=NO;
    [self.card addSubview:stack];
    self.stack=stack;
    [NSLayoutConstraint activateConstraints:@[
        [stack.topAnchor constraintEqualToAnchor:self.card.topAnchor constant:16],
        [stack.leadingAnchor constraintEqualToAnchor:self.card.leadingAnchor constant:16],
        [stack.trailingAnchor constraintEqualToAnchor:self.card.trailingAnchor constant:-16],
        [stack.bottomAnchor constraintEqualToAnchor:self.card.bottomAnchor constant:-16],
    ]];
}
- (void)kb:(NSNotification *)n {
    CGRect kf=[n.userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue];
    UIWindow *win=self.root.window;
    if (win) kf=[win convertRect:kf fromWindow:nil];
    CGFloat overlap=0;
    if (win) overlap=MAX(0, CGRectGetMaxY(win.bounds)-CGRectGetMinY(kf));
    if ([n.name isEqualToString:UIKeyboardWillHideNotification] || kf.origin.y >= CGRectGetMaxY(win.bounds)-1) overlap=0;
    self.kbH=MIN(overlap, win.bounds.size.height*0.72);
    self.cardBottom.constant=-(self.kbH>8 ? self.kbH+10 : 12);
    NSTimeInterval d=[n.userInfo[UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    UIViewAnimationOptions opt=[n.userInfo[UIKeyboardAnimationCurveUserInfoKey] integerValue]<<16;
    [UIView animateWithDuration:MAX(d,0.18) delay:0 options:opt|UIViewAnimationOptionBeginFromCurrentState animations:^{
        [self.root.superview layoutIfNeeded];
    } completion:nil];
}
- (UILabel *)label:(CGFloat)size bold:(BOOL)bold {
    UILabel *l=[UILabel new];
    l.translatesAutoresizingMaskIntoConstraints=NO;
    l.textColor=SDTACream(); l.textAlignment=NSTextAlignmentCenter; l.numberOfLines=0;
    l.font=bold?[UIFont systemFontOfSize:size weight:UIFontWeightSemibold]:[UIFont systemFontOfSize:size weight:UIFontWeightRegular];
    l.adjustsFontSizeToFitWidth=YES; l.minimumScaleFactor=0.8;
    [l setContentCompressionResistancePriority:UILayoutPriorityDefaultLow forAxis:UILayoutConstraintAxisVertical];
    [self.stack addArrangedSubview:l];
    return l;
}
- (UIButton *)button:(NSString *)title action:(SEL)action cream:(BOOL)cream {
    UIButton *b=[UIButton buttonWithType:UIButtonTypeSystem];
    b.translatesAutoresizingMaskIntoConstraints=NO;
    [b setTitle:title forState:UIControlStateNormal];
    b.titleLabel.font=[UIFont systemFontOfSize:15 weight:UIFontWeightSemibold];
    b.layer.cornerRadius=14;
    if (cream) {
        [b setTitleColor:[UIColor colorWithRed:.09 green:.08 blue:.07 alpha:1] forState:UIControlStateNormal];
        b.backgroundColor=SDTACream();
    } else {
        [b setTitleColor:SDTACream() forState:UIControlStateNormal];
        b.backgroundColor=[UIColor colorWithWhite:1 alpha:.08];
        b.layer.borderWidth=1; b.layer.borderColor=[UIColor colorWithWhite:1 alpha:.16].CGColor;
    }
    [b addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    [b.heightAnchor constraintEqualToConstant:44].active=YES;
    [b setContentCompressionResistancePriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisVertical];
    [b setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisVertical];
    [self.stack addArrangedSubview:b];
    return b;
}
- (UITextField *)field:(NSString *)placeholder {
    UITextField *f=[UITextField new];
    f.translatesAutoresizingMaskIntoConstraints=NO;
    f.delegate=self; f.placeholder=placeholder;
    f.textColor=SDTACream(); f.backgroundColor=[UIColor colorWithWhite:1 alpha:.07];
    f.layer.cornerRadius=12; f.layer.borderWidth=1; f.layer.borderColor=[UIColor colorWithWhite:1 alpha:.14].CGColor;
    f.autocapitalizationType=UITextAutocapitalizationTypeAllCharacters; f.autocorrectionType=UITextAutocorrectionTypeNo;
    f.clearButtonMode=UITextFieldViewModeWhileEditing;
    UIView *pad=[[UIView alloc]initWithFrame:CGRectMake(0,0,14,1)]; f.leftView=pad; f.leftViewMode=UITextFieldViewModeAlways;
    [f.heightAnchor constraintEqualToConstant:44].active=YES;
    [f setContentCompressionResistancePriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisVertical];
    [f setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisVertical];
    [self.stack addArrangedSubview:f];
    return f;
}
- (void)stopPoll {
    if (self.pollTimer) { dispatch_source_cancel(self.pollTimer); self.pollTimer=nil; }
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationDidBecomeActiveNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationWillEnterForegroundNotification object:nil];
}
- (void)resetCard {
    [self stopCountdown]; [self stopPoll]; [self ensureView];
    self.kickerLabel=self.titleLabel=self.metaLabel=self.messageLabel=self.countdownLabel=self.statusLabel=nil;
    self.spinner=nil; self.keyField=nil; self.primaryButton=self.secondaryButton=nil;
    self.retryBlock=nil; self.submitBlock=nil; self.udidEntryMode=NO;
    [self makeStack];
}
- (void)paintHeader {
    SDTAState *s=SDTAState.shared;
    self.kickerLabel=[self label:11 bold:YES];
    self.kickerLabel.textColor=SDTAGold();
    self.kickerLabel.text=@"SHOPDTA  ·  LICENSE";
    [self.kickerLabel setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisVertical];
    self.titleLabel=[self label:24 bold:YES];
    self.titleLabel.text=s.packageName.length?s.packageName:@"ShopDTA";
    [self.titleLabel setContentCompressionResistancePriority:UILayoutPriorityDefaultHigh forAxis:UILayoutConstraintAxisVertical];
    self.metaLabel=[self label:13 bold:NO];
    self.metaLabel.textColor=[UIColor colorWithWhite:.72 alpha:1];
    NSString *ver=s.packageVersion.length?s.packageVersion:SDTASafeString(s.packageData[@"version"]);
    NSString *bundle=NSBundle.mainBundle.bundleIdentifier ?: @"";
    self.metaLabel.text=ver.length ? [NSString stringWithFormat:@"v%@  ·  %@", ver, bundle] : bundle;
}
- (void)relayout {
    [self.root.superview layoutIfNeeded];
}
- (void)showInitializing:(NSString *)text { dispatch_async(dispatch_get_main_queue(), ^{
    if (SDTAState.shared.hideUI) return; [self resetCard]; [self paintHeader];
    self.spinner=[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleLarge];
    self.spinner.translatesAutoresizingMaskIntoConstraints=NO;
    self.spinner.color=SDTAGold();
    [self.spinner.heightAnchor constraintEqualToConstant:36].active=YES;
    [self.stack addArrangedSubview:self.spinner];
    [self.spinner startAnimating];
    self.messageLabel=[self label:15 bold:NO]; self.messageLabel.text=text ?: @"Đang kết nối ShopDTA…";
    [self relayout];
}); }
- (void)showErrorTitle:(NSString *)title message:(NSString *)message retry:(dispatch_block_t)retry { dispatch_async(dispatch_get_main_queue(), ^{
    if (SDTAState.shared.hideUI) return; [self resetCard]; [self paintHeader];
    self.titleLabel.textColor=[UIColor colorWithRed:0.93 green:0.45 blue:0.45 alpha:1];
    self.titleLabel.text=title.length?title:@"Không kết nối";
    self.messageLabel=[self label:14 bold:NO]; self.messageLabel.text=message ?: @"Đã xảy ra lỗi.";
    self.retryBlock=retry;
    if (retry) self.primaryButton=[self button:@"Thử lại" action:@selector(onRetry) cream:YES];
    [self relayout];
}); }
- (void)showLoginWithMessage:(NSString *)message submit:(void (^)(NSString *))submit { dispatch_async(dispatch_get_main_queue(), ^{
    if (SDTAState.shared.hideUI) return; [self resetCard]; [self paintHeader];
    self.countdownLabel=[self label:22 bold:YES];
    self.countdownLabel.font=[UIFont monospacedDigitSystemFontOfSize:22 weight:UIFontWeightSemibold];
    self.countdownLabel.textColor=SDTAGold();
    [self.countdownLabel setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisVertical];
    self.messageLabel=[self label:14 bold:NO];
    self.messageLabel.text=message.length?message:@"Nhập license key để xác thực thiết bị.";
    self.keyField=[self field:@"LICENSE-KEY"];
    self.submitBlock=submit;
    self.primaryButton=[self button:@"Xác thực key" action:@selector(onSubmit) cream:YES];
    self.statusLabel=[self label:12 bold:NO];
    self.statusLabel.textColor=[UIColor colorWithWhite:.55 alpha:1];
    NSString *ud=SDTAState.shared.udid ?: @"";
    self.statusLabel.text=ud.length?[NSString stringWithFormat:@"UDID  %@…%@", [ud substringToIndex:MIN(6,ud.length)], ud.length>8?[ud substringFromIndex:ud.length-4]:@""]:@"";
    [self relayout]; [self startCountdown];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(0.08*NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ [self.keyField becomeFirstResponder]; });
}); }
- (void)showUDIDThen:(void (^)(void))next { dispatch_async(dispatch_get_main_queue(), ^{
    if (SDTAState.shared.hideUI) { if (next) next(); return; }
    self.udidNext=next;
    [self resetCard]; [self paintHeader];
    self.spinner=[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleLarge];
    self.spinner.translatesAutoresizingMaskIntoConstraints=NO;
    self.spinner.color=SDTAGold();
    [self.spinner.heightAnchor constraintEqualToConstant:36].active=YES;
    [self.stack addArrangedSubview:self.spinner];
    [self.spinner startAnimating];
    self.messageLabel=[self label:14 bold:NO];
    self.messageLabel.text=@"Tạo phiên lấy UDID…";
    [self relayout];
    NSString *bundle=NSBundle.mainBundle.bundleIdentifier ?: @"";
    [[SDTANetwork shared] jsonGET:[NSString stringWithFormat:@"/udid/enroll?bundle=%@", [bundle stringByAddingPercentEncodingWithAllowedCharacters:NSCharacterSet.URLQueryAllowedCharacterSet]]
                       completion:^(NSDictionary *j, NSError *e, NSInteger st) {
        if (!j || (![j[@"token"] isKindOfClass:NSString.class])) {
            [self showErrorTitle:@"Không lấy được UDID" message:e.localizedDescription ?: @"Enroll thất bại" retry:^{ [self showUDIDThen:next]; }];
            return;
        }
        SDTAState.shared.enrollToken=j[@"token"];
        [[NSUserDefaults standardUserDefaults] setObject:j[@"token"] forKey:@"ShopDTA.enrollToken"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        self.profileURL=SDTASafeString(j[@"profileUrl"]);
        self.statusURL=SDTASafeString(j[@"statusUrl"]);
        [self paintUDIDWait];
    }];
}); }
- (void)paintUDIDWait {
    [self resetCard]; [self paintHeader];
    self.spinner=[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleLarge];
    self.spinner.translatesAutoresizingMaskIntoConstraints=NO;
    self.spinner.color=SDTAGold();
    [self.spinner.heightAnchor constraintEqualToConstant:36].active=YES;
    [self.stack addArrangedSubview:self.spinner];
    [self.spinner startAnimating];
    self.messageLabel=[self label:14 bold:NO];
    self.messageLabel.text=@"Cài cấu hình để lấy UDID iPhone.\nSau khi cài, quay lại app — tự nhận.";
    self.primaryButton=[self button:@"Tải cấu hình UDID" action:@selector(onOpenProfile) cream:YES];
    if (SDTAState.shared.allowManualUdid) {
        self.secondaryButton=[self button:@"Nhập UDID thủ công" action:@selector(onManualUDID) cream:NO];
    }
    self.statusLabel=[self label:12 bold:NO];
    self.statusLabel.textColor=SDTAGold();
    self.statusLabel.text=@"Đang chờ UDID từ server…";
    [self relayout];
    [self startPoll];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(pollNow) name:UIApplicationDidBecomeActiveNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(pollNow) name:UIApplicationWillEnterForegroundNotification object:nil];
}
- (void)onManualUDID { [self showManualUDID:self.udidNext]; }
- (void)showManualUDID:(void (^)(void))next { dispatch_async(dispatch_get_main_queue(), ^{
    if (SDTAState.shared.hideUI) { if (next) next(); return; }
    self.udidNext=next;
    [self resetCard]; [self paintHeader];
    self.udidEntryMode=YES;
    self.messageLabel=[self label:14 bold:NO];
    self.messageLabel.text=@"Dán UDID đã sao chép từ Safari / hồ sơ.";
    self.keyField=[self field:@"UDID"];
    NSString *pb=[UIPasteboard.generalPasteboard.string stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    if (pb.length>=25) self.keyField.text=pb;
    self.submitBlock=nil;
    self.primaryButton=[self button:@"Dùng UDID này" action:@selector(onSubmit) cream:YES];
    self.secondaryButton=[self button:@"Quay lại lấy hồ sơ" action:@selector(onBackProfile) cream:NO];
    [self relayout];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(0.08*NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ [self.keyField becomeFirstResponder]; });
}); }
- (void)onBackProfile { [self showUDIDThen:self.udidNext]; }
- (void)onOpenProfile {
    NSURL *u=[NSURL URLWithString:self.profileURL];
    if (u) [UIApplication.sharedApplication openURL:u options:@{} completionHandler:nil];
}
- (void)startPoll {
    [self stopPoll];
    self.pollTimer=dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER,0,0,dispatch_get_main_queue());
    dispatch_source_set_timer(self.pollTimer,dispatch_time(DISPATCH_TIME_NOW,2*NSEC_PER_SEC),2*NSEC_PER_SEC,NSEC_PER_MSEC*200);
    __weak SDTAUI *w=self;
    dispatch_source_set_event_handler(self.pollTimer,^{ [w pollNow]; });
    dispatch_resume(self.pollTimer);
}
- (void)pollNow {
    if (!self.statusURL.length) return;
    NSString *path=[self.statusURL hasPrefix:@"http"] ? [self.statusURL stringByReplacingOccurrencesOfString:APICLIENT_BASE_URL withString:@""] : self.statusURL;
    [[SDTANetwork shared] jsonGET:path completion:^(NSDictionary *j, NSError *e, NSInteger st) {
        if (![j[@"ready"] boolValue] && ![[j[@"status"] description] isEqualToString:@"CAPTURED"]) return;
        NSString *udid=SDTASafeString(j[@"udid"]);
        if (!udid.length) return;
        [self stopPoll];
        SDTAState.shared.udid=udid;
        [[NSUserDefaults standardUserDefaults] setObject:udid forKey:@"ShopDTA.enrolledUDID"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        self.statusLabel.text=[NSString stringWithFormat:@"Đã nhận UDID  %@", udid];
        void (^n)(void)=self.udidNext; self.udidNext=nil;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(0.4*NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ if(n) n(); });
    }];
}
- (void)showSuccess { dispatch_async(dispatch_get_main_queue(), ^{
    if (SDTAState.shared.hideUI) { [self dismiss]; return; }
    [self resetCard]; [self paintHeader];
    self.titleLabel.textColor=[UIColor colorWithRed:.55 green:.85 blue:.58 alpha:1];
    self.messageLabel=[self label:14 bold:NO]; self.messageLabel.text=@"Đã xác thực. Menu sẵn sàng.";
    self.statusLabel=[self label:13 bold:NO]; self.statusLabel.textColor=[UIColor colorWithRed:.55 green:.85 blue:.58 alpha:1];
    self.statusLabel.text=@"●  Đang hoạt động";
    self.primaryButton=[self button:@"Tiếp tục" action:@selector(onClose) cream:YES];
    [self relayout];
}); }
- (void)startCountdown {
    [self stopCountdown]; self.countdownDeadline=CACurrentMediaTime()+SDTACountdownSeconds;
    self.countdownTimer=dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER,0,0,dispatch_get_main_queue());
    dispatch_source_set_timer(self.countdownTimer,dispatch_time(DISPATCH_TIME_NOW,0),NSEC_PER_SEC,NSEC_PER_MSEC*100);
    __weak SDTAUI *weakSelf=self;
    dispatch_source_set_event_handler(self.countdownTimer,^{ [weakSelf updateCountdown]; });
    dispatch_resume(self.countdownTimer); [self updateCountdown];
}
- (void)stopCountdown { if (self.countdownTimer) { dispatch_source_cancel(self.countdownTimer); self.countdownTimer=nil; } }
- (void)updateCountdown {
    if (!self.countdownLabel) return;
    NSTimeInterval left=MAX(0,self.countdownDeadline-CACurrentMediaTime());
    NSInteger seconds=(NSInteger)ceil(left);
    self.countdownLabel.text=[NSString stringWithFormat:@"%02ld:%02ld",(long)(seconds/60),(long)(seconds%60)];
    if (seconds<=0) { [self stopCountdown]; if (self.keyField) exit(0); }
}
- (void)onRetry { if (self.retryBlock) self.retryBlock(); }
- (void)onSubmit {
    NSString *k=[self.keyField.text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    if (self.udidEntryMode) {
        k=[k uppercaseString];
        if (k.length<8) { self.messageLabel.text=@"UDID không hợp lệ."; return; }
        [self.keyField resignFirstResponder];
        SDTAState.shared.udid=k;
        [[NSUserDefaults standardUserDefaults] setObject:k forKey:@"ShopDTA.enrolledUDID"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        void (^n)(void)=self.udidNext; self.udidNext=nil; if (n) n();
        return;
    }
    if (!k.length) { self.messageLabel.text=@"Vui lòng nhập license key."; return; }
    [self.keyField resignFirstResponder];
    [self showInitializing:@"Đang xác thực license…"];
    if (self.submitBlock) self.submitBlock(k);
}
- (void)onClose { [self dismiss]; }
- (BOOL)textFieldShouldReturn:(UITextField *)textField { [self onSubmit]; return YES; }
- (void)dismiss { dispatch_async(dispatch_get_main_queue(), ^{ [self stopCountdown]; [self stopPoll]; [self.root removeFromSuperview]; self.root=nil; self.card=nil; self.stack=nil; self.cardBottom=nil; self.cardWidth=nil; }); }
- (void)dealloc { [self stopCountdown]; [self stopPoll]; }
@end
