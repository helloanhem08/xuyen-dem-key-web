#import "APIClientInternal.h"
#import <CommonCrypto/CommonHMAC.h>

@implementation SDTANetwork {
    NSURLSession *_session;
}
+ (instancetype)shared { static SDTANetwork *x; static dispatch_once_t once; dispatch_once(&once, ^{ x=[SDTANetwork new]; }); return x; }
- (instancetype)init {
    if ((self=[super init])) {
        NSURLSessionConfiguration *c = [NSURLSessionConfiguration ephemeralSessionConfiguration];
        c.timeoutIntervalForRequest = APICLIENT_TIMEOUT_SECONDS;
        c.timeoutIntervalForResource = APICLIENT_TIMEOUT_SECONDS + 5.0;
        c.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
        _session = [NSURLSession sessionWithConfiguration:c];
    }
    return self;
}
- (void)postPath:(NSString *)path json:(NSDictionary *)json completion:(void (^)(NSDictionary *, NSError *, NSInteger))completion {
    [self postPath:path json:json attempt:0 completion:completion];
}
- (void)postPath:(NSString *)path json:(NSDictionary *)json attempt:(NSInteger)attempt completion:(void (^)(NSDictionary *, NSError *, NSInteger))completion {
    NSMutableDictionary *signedJSON=[json mutableCopy] ?: [NSMutableDictionary dictionary];
    NSString *endpoint=[path.lastPathComponent stringByReplacingOccurrencesOfString:@"" withString:@""];
    NSString *canonical=[NSString stringWithFormat:@"%@|%@|%@|%@|%@|%@|%@", endpoint, SDTASafeString(signedJSON[@"timestamp"]), SDTASafeString(signedJSON[@"nonce"]), SDTASafeString(signedJSON[@"data"]), SDTASafeString(signedJSON[@"udid"]), SDTASafeString(signedJSON[@"key"]), SDTASafeString(signedJSON[@"bundle_id"] )];
    NSData *hmacKey=[APICLIENT_TRANSPORT_KEY dataUsingEncoding:NSASCIIStringEncoding], *message=[canonical dataUsingEncoding:NSUTF8StringEncoding]; unsigned char digest[CC_SHA256_DIGEST_LENGTH]; CCHmac(kCCHmacAlgSHA256,hmacKey.bytes,hmacKey.length,message.bytes,message.length,digest); NSMutableString *hex=[NSMutableString stringWithCapacity:64]; for(NSUInteger i=0;i<sizeof(digest);i++) [hex appendFormat:@"%02x",digest[i]]; signedJSON[@"request_signature"]=hex;
    NSError *err=nil;
    NSData *plain=[NSJSONSerialization dataWithJSONObject:signedJSON options:0 error:&err];
    NSData *cipher=plain ? [SDTACrypto AES256ECBEncrypt:plain error:&err] : nil;
    if (!cipher) { dispatch_async(dispatch_get_main_queue(), ^{ completion(nil, err, 0); }); return; }
    NSData *body=[cipher base64EncodedDataWithOptions:0];
    NSURL *url=[NSURL URLWithString:[APICLIENT_BASE_URL stringByAppendingString:path]];
    NSMutableURLRequest *r=[NSMutableURLRequest requestWithURL:url];
    r.HTTPMethod=@"POST"; r.HTTPBody=body; r.timeoutInterval=APICLIENT_TIMEOUT_SECONDS;
    [r setValue:@"text/plain" forHTTPHeaderField:@"Content-Type"];
    [r setValue:@"text/plain" forHTTPHeaderField:@"Accept"];
    SDTALog(@"POST %@ request=%@", path, [path isEqualToString:APICLIENT_KEY_PATH] ? @"<redacted license request>" : SDTAJSONString(signedJSON));
    [[_session dataTaskWithRequest:r completionHandler:^(NSData *data, NSURLResponse *resp, NSError *netErr) {
        NSInteger status=[(NSHTTPURLResponse *)resp statusCode];
        if (netErr && attempt < APICLIENT_RETRY_COUNT) {
            SDTALog(@"POST %@ retry after network error: %@", path, netErr.localizedDescription);
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.6*NSEC_PER_SEC)), dispatch_get_global_queue(QOS_CLASS_UTILITY,0), ^{ [self postPath:path json:json attempt:attempt+1 completion:completion]; });
            return;
        }
        if (netErr) {
            NSError *e=[SDTAError errorWithKind:SDTAErrorHTTP message:@"Không thể kết nối máy chủ." detail:netErr.localizedDescription];
            dispatch_async(dispatch_get_main_queue(), ^{ completion(nil,e,status); }); return;
        }
        SDTALog(@"POST %@ HTTP %ld bytes=%lu", path,(long)status,(unsigned long)data.length);
        if (status < 200 || status >= 300) {
            NSError *e=[SDTAError errorWithKind:SDTAErrorHTTP message:[NSString stringWithFormat:@"Máy chủ trả HTTP %ld.",(long)status] detail:nil];
            dispatch_async(dispatch_get_main_queue(), ^{ completion(nil,e,status); }); return;
        }
        NSError *decodeErr=nil; NSDictionary *payload=[SDTACrypto decodeResponseBody:data error:&decodeErr];
        if (!payload) SDTALog(@"POST %@ decode error: %@ / %@",path,decodeErr.localizedDescription,decodeErr.userInfo[@"detail"] ?: @"");
        dispatch_async(dispatch_get_main_queue(), ^{ completion(payload,decodeErr,status); });
    }] resume];
}
- (void)getHealth:(void (^)(NSDictionary *, NSError *, NSInteger))completion {
    [self jsonGET:APICLIENT_HEALTH_PATH completion:completion];
}
- (void)jsonGET:(NSString *)path completion:(void (^)(NSDictionary *, NSError *, NSInteger))completion {
    NSURL *url=[path hasPrefix:@"http"] ? [NSURL URLWithString:path] : [NSURL URLWithString:[APICLIENT_BASE_URL stringByAppendingString:path]];
    NSMutableURLRequest *r=[NSMutableURLRequest requestWithURL:url]; r.timeoutInterval=APICLIENT_TIMEOUT_SECONDS;
    [r setValue:@"application/json" forHTTPHeaderField:@"Accept"];
    [[_session dataTaskWithRequest:r completionHandler:^(NSData *d, NSURLResponse *resp, NSError *e) {
        NSInteger status=[(NSHTTPURLResponse *)resp statusCode]; id j=d ? [NSJSONSerialization JSONObjectWithData:d options:0 error:nil] : nil;
        dispatch_async(dispatch_get_main_queue(), ^{ completion([j isKindOfClass:NSDictionary.class]?j:nil,e,status); });
    }] resume];
}
- (void)jsonPOST:(NSString *)path json:(NSDictionary *)json completion:(void (^)(NSDictionary *, NSError *, NSInteger))completion {
    NSURL *url=[NSURL URLWithString:[APICLIENT_BASE_URL stringByAppendingString:path]];
    NSMutableURLRequest *r=[NSMutableURLRequest requestWithURL:url];
    r.HTTPMethod=@"POST"; r.timeoutInterval=APICLIENT_TIMEOUT_SECONDS;
    r.HTTPBody=[NSJSONSerialization dataWithJSONObject:json?:@{} options:0 error:nil];
    [r setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [r setValue:@"application/json" forHTTPHeaderField:@"Accept"];
    [[_session dataTaskWithRequest:r completionHandler:^(NSData *d, NSURLResponse *resp, NSError *e) {
        NSInteger status=[(NSHTTPURLResponse *)resp statusCode]; id j=d ? [NSJSONSerialization JSONObjectWithData:d options:0 error:nil] : nil;
        dispatch_async(dispatch_get_main_queue(), ^{ completion([j isKindOfClass:NSDictionary.class]?j:nil,e,status); });
    }] resume];
}
@end
