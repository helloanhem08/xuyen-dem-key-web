#ifndef APICLIENT_CONFIG_H
#define APICLIENT_CONFIG_H

#import <Foundation/Foundation.h>

#define APICLIENT_BASE_URL @"https://shopdta.site"
#define APICLIENT_PACKAGE_PATH @"/v4/client/package-v3"
#define APICLIENT_CREDENTIAL_PATH @"/v4/client/credential-v3"
#define APICLIENT_KEY_PATH @"/v4/client/key-v3"
#define APICLIENT_HEALTH_PATH @"/health.php"

#define APICLIENT_VERSION @"6.1.0"
#define APICLIENT_PACKAGE_TOKEN @"shopdta"
#define APICLIENT_TRANSPORT_KEY @"h4HQn0A7kFN6xpydECEVp3H5oCc1kF6p"
#define APICLIENT_TIMEOUT_SECONDS 15.0
#define APICLIENT_RETRY_COUNT 1
#define APICLIENT_UDID_DEFAULTS_KEY @"ShopDTA.APIClient.StableUDID"

#define APICLIENT_RSA_PUBLIC_KEY_PEM @"-----BEGIN PUBLIC KEY-----\n" \
@"MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA0pd2Il2Upblk9zoMHoox\n" \
@"8Y61yDqaoI36N7CkbcBitxERm0BwQuG1A9seUmOxdkIalKzjVfBUSNySqj0xErCU\n" \
@"q4V9smMl7eHAKRfrhamZAhNvN2gBcfY6EBjuICKbREm7XIjGavwJE+ScrGdsdOQD\n" \
@"FbvMSykUhs27vh8YcIZfCQjhKOr2ntHpeF8f2uDNZ9THMhoBGRWHQoMpj5CAc/5r\n" \
@"sWOYpITt4R9LuhjCNsGErvzexdObyl73rM/4r+/ys5iQWh2lp7zNgBhIU8LPpzx6\n" \
@"cj9Nov0G7GDAf9/Z98B0xJUBqbJzn7T3BP2oaZbkarRqecq334iQRT9D+e9UKTeh\n" \
@"FwIDAQAB\n" \
@"-----END PUBLIC KEY-----"

#define APICLIENT_RSA_PUBLIC_KEY_SHA256 @"d1b7960925d565d4a36429c5614f951148f3b7c56c54f146fae3fa9412ea14a9"

#endif
